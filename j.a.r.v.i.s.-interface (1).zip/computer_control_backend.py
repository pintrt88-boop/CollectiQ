#!/usr/bin/env python3
"""
MUKE Computer Control Local Backend
Provides local OS automation (mouse, keyboard, apps, files, browser)
via HTTP API bound strictly to 127.0.0.1 for security.
"""

import os
import sys
import json
import time
import queue
import logging
import platform
import threading
import subprocess
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

# Optional GUI automation libraries with graceful fallbacks
PYAUTOGUI_AVAILABLE = False
PYNPUT_AVAILABLE = False

try:
    import pyautogui
    pyautogui.FAILSAFE = True  # Moving mouse to screen corner aborts automation
    pyautogui.PAUSE = 0.05
    PYAUTOGUI_AVAILABLE = True
except Exception as e:
    print(f"[MUKE Backend] pyautogui not loaded ({e}). Operating in native subprocess mode.")

try:
    from pynput import keyboard
    PYNPUT_AVAILABLE = True
except Exception as e:
    print(f"[MUKE Backend] pynput not loaded ({e}).")

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "computer_control_config.json")
LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "computer_control.log")

# Setup action logging
logging.basicConfig(
    filename=LOG_PATH,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger("MUKE_ComputerControl")

def log_action(action_type, details, status="SUCCESS"):
    msg = f"ACTION: {action_type} | STATUS: {status} | DETAILS: {json.dumps(details)}"
    print(f"[MUKE Log] {msg}")
    logger.info(msg)

# Default timing configuration
DEFAULT_CONFIG = {
    "wakeWordCooldownSeconds": 2.0,
    "commandListeningTimeoutSeconds": 10.0,
    "delayBetweenActionsSeconds": 0.5,
    "typingSpeedSecondsPerChar": 0.05,
    "clickSpeedSeconds": 0.1
}

def load_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                return {**DEFAULT_CONFIG, **cfg}
        except Exception as e:
            print(f"[MUKE Backend] Failed to load config: {e}")
    return DEFAULT_CONFIG.copy()

def save_config(cfg):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
        log_action("UPDATE_CONFIG", cfg, "SUCCESS")
        return True
    except Exception as e:
        log_action("UPDATE_CONFIG", {"error": str(e)}, "ERROR")
        return False

# Global state and queues
action_queue = queue.Queue()
is_running = True
current_action_cancel_event = threading.Event()
esc_press_start_time = None
esc_lock = threading.Lock()

def abort_all_actions(reason="STOP_REQUESTED"):
    """Emergency stop function: clear action queue, signal current action to stop"""
    print(f"[MUKE Backend] *** EMERGENCY STOP TRIGGERED: {reason} ***")
    current_action_cancel_event.set()
    # Drain the queue
    while not action_queue.empty():
        try:
            action_queue.get_nowait()
            action_queue.task_done()
        except queue.Empty:
            break
    log_action("EMERGENCY_STOP", {"reason": reason}, "ABORTED")
    time.sleep(0.1)
    current_action_cancel_event.clear()

# Keyboard Emergency Stop Listener (Esc held for 2 seconds)
def setup_esc_emergency_listener():
    if not PYNPUT_AVAILABLE:
        return

    def on_press(key):
        global esc_press_start_time
        if key == keyboard.Key.esc:
            with esc_lock:
                if esc_press_start_time is None:
                    esc_press_start_time = time.time()
                elif time.time() - esc_press_start_time >= 2.0:
                    abort_all_actions(reason="ESC_KEY_HELD_2_SECONDS")
                    esc_press_start_time = None

    def on_release(key):
        global esc_press_start_time
        if key == keyboard.Key.esc:
            with esc_lock:
                esc_press_start_time = None

    try:
        listener = keyboard.Listener(on_press=on_press, on_release=on_release)
        listener.daemon = True
        listener.start()
        print("[MUKE Backend] Keyboard emergency stop listener active (Hold Esc for 2 seconds).")
    except Exception as e:
        print(f"[MUKE Backend] Could not start keyboard listener: {e}")

# Executor thread for sequential queued actions
def action_worker():
    while is_running:
        try:
            item = action_queue.get(timeout=0.5)
        except queue.Empty:
            continue

        if item is None:
            break

        action_data, result_holder = item
        if current_action_cancel_event.is_set():
            result_holder["status"] = "CANCELLED"
            result_holder["message"] = "Action cancelled before start"
            action_queue.task_done()
            continue

        cfg = load_config()
        delay = float(cfg.get("delayBetweenActionsSeconds", 0.5))
        if delay > 0:
            time.sleep(delay)

        try:
            res = execute_single_action(action_data, cfg)
            result_holder.update(res)
        except pyautogui.FailSafeException if PYAUTOGUI_AVAILABLE else Exception as fe:
            abort_all_actions(reason="MOUSE_CORNER_FAILSAFE_TRIGGERED")
            result_holder["status"] = "ABORTED"
            result_holder["message"] = "Automation aborted by mouse corner failsafe"
        except Exception as e:
            result_holder["status"] = "ERROR"
            result_holder["message"] = str(e)
            log_action(action_data.get("action", "UNKNOWN"), {"error": str(e)}, "ERROR")
        finally:
            action_queue.task_done()

def execute_single_action(data, cfg):
    action = data.get("action", "").lower().strip()
    system_os = platform.system()

    # 1. MOUSE CONTROL
    if action == "mouse_move":
        x = int(data.get("x", 0))
        y = int(data.get("y", 0))
        duration = float(data.get("duration", cfg.get("clickSpeedSeconds", 0.1)))
        if PYAUTOGUI_AVAILABLE:
            pyautogui.moveTo(x, y, duration=duration)
        log_action("MOUSE_MOVE", {"x": x, "y": y})
        return {"status": "SUCCESS", "action": action, "x": x, "y": y}

    elif action in ["mouse_click", "click"]:
        button = data.get("button", "left").lower()
        clicks = int(data.get("clicks", 1))
        x = data.get("x")
        y = data.get("y")
        if PYAUTOGUI_AVAILABLE:
            if x is not None and y is not None:
                pyautogui.click(x=int(x), y=int(y), clicks=clicks, button=button)
            else:
                pyautogui.click(clicks=clicks, button=button)
        log_action("MOUSE_CLICK", {"button": button, "clicks": clicks, "x": x, "y": y})
        return {"status": "SUCCESS", "action": action}

    elif action == "mouse_double_click":
        if PYAUTOGUI_AVAILABLE:
            x = data.get("x")
            y = data.get("y")
            if x is not None and y is not None:
                pyautogui.doubleClick(x=int(x), y=int(y))
            else:
                pyautogui.doubleClick()
        log_action("MOUSE_DOUBLE_CLICK", data)
        return {"status": "SUCCESS", "action": action}

    elif action == "mouse_right_click":
        if PYAUTOGUI_AVAILABLE:
            x = data.get("x")
            y = data.get("y")
            if x is not None and y is not None:
                pyautogui.rightClick(x=int(x), y=int(y))
            else:
                pyautogui.rightClick()
        log_action("MOUSE_RIGHT_CLICK", data)
        return {"status": "SUCCESS", "action": action}

    elif action == "mouse_scroll":
        amount = int(data.get("amount", data.get("clicks", 5)))
        if PYAUTOGUI_AVAILABLE:
            pyautogui.scroll(amount)
        log_action("MOUSE_SCROLL", {"amount": amount})
        return {"status": "SUCCESS", "action": action, "amount": amount}

    elif action == "mouse_drag":
        x = int(data.get("x", 0))
        y = int(data.get("y", 0))
        duration = float(data.get("duration", 0.5))
        if PYAUTOGUI_AVAILABLE:
            pyautogui.dragTo(x, y, duration=duration)
        log_action("MOUSE_DRAG", {"x": x, "y": y, "duration": duration})
        return {"status": "SUCCESS", "action": action}

    # 2. KEYBOARD CONTROL
    elif action in ["type_text", "type"]:
        text = str(data.get("text", ""))
        speed = float(data.get("speed", cfg.get("typingSpeedSecondsPerChar", 0.05)))
        if PYAUTOGUI_AVAILABLE:
            pyautogui.write(text, interval=speed)
        log_action("TYPE_TEXT", {"text_length": len(text)})
        return {"status": "SUCCESS", "action": action, "characters": len(text)}

    elif action in ["press_key", "key"]:
        key = str(data.get("key", "enter")).lower()
        if PYAUTOGUI_AVAILABLE:
            pyautogui.press(key)
        log_action("PRESS_KEY", {"key": key})
        return {"status": "SUCCESS", "action": action, "key": key}

    elif action in ["hotkey", "shortcut"]:
        keys = data.get("keys", [])
        if isinstance(keys, str):
            keys = [k.strip().lower() for k in keys.split("+")]
        if PYAUTOGUI_AVAILABLE and keys:
            pyautogui.hotkey(*keys)
        log_action("HOTKEY", {"keys": keys})
        return {"status": "SUCCESS", "action": action, "keys": keys}

    # 3. WEB SEARCH & URLS
    elif action in ["web_search", "search"]:
        query = data.get("query", "")
        search_url = f"https://www.google.com/search?q={query}"
        webbrowser.open(search_url)
        log_action("WEB_SEARCH", {"query": query, "url": search_url})
        return {"status": "SUCCESS", "action": action, "query": query}

    elif action in ["open_url", "open_website"]:
        url = data.get("url", "")
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        webbrowser.open(url)
        log_action("OPEN_URL", {"url": url})
        return {"status": "SUCCESS", "action": action, "url": url}

    # 4. FILES AND FOLDERS
    elif action == "create_folder":
        folder_path = os.path.expanduser(data.get("path", ""))
        os.makedirs(folder_path, exist_ok=True)
        log_action("CREATE_FOLDER", {"path": folder_path})
        return {"status": "SUCCESS", "action": action, "path": folder_path}

    elif action == "create_file":
        file_path = os.path.expanduser(data.get("path", ""))
        content = data.get("content", "")
        parent_dir = os.path.dirname(file_path)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)
        log_action("CREATE_FILE", {"path": file_path, "bytes": len(content)})
        return {"status": "SUCCESS", "action": action, "path": file_path}

    elif action in ["open_file", "open_folder"]:
        target_path = os.path.expanduser(data.get("path", ""))
        if system_os == "Windows":
            os.startfile(target_path)
        elif system_os == "Darwin":
            subprocess.Popen(["open", target_path])
        else:
            subprocess.Popen(["xdg-open", target_path])
        log_action("OPEN_PATH", {"path": target_path})
        return {"status": "SUCCESS", "action": action, "path": target_path}

    # 5. APPS
    elif action == "open_app":
        app_name = data.get("app_name", "").strip()
        cmd = None
        if system_os == "Windows":
            cmd = f"start {app_name}"
            subprocess.Popen(cmd, shell=True)
        elif system_os == "Darwin":
            subprocess.Popen(["open", "-a", app_name])
        else:
            subprocess.Popen([app_name], shell=True)
        log_action("OPEN_APP", {"app_name": app_name})
        return {"status": "SUCCESS", "action": action, "app_name": app_name}

    elif action == "close_app":
        app_name = data.get("app_name", "").strip()
        if system_os == "Windows":
            subprocess.run(f"taskkill /IM {app_name}* /F", shell=True)
        elif system_os == "Darwin":
            subprocess.run(["pkill", "-f", app_name])
        else:
            subprocess.run(["pkill", "-f", app_name])
        log_action("CLOSE_APP", {"app_name": app_name})
        return {"status": "SUCCESS", "action": action, "app_name": app_name}

    # 6. WINDOWS AND TABS
    elif action == "close_window":
        if PYAUTOGUI_AVAILABLE:
            if system_os == "Darwin":
                pyautogui.hotkey("command", "w")
            else:
                pyautogui.hotkey("alt", "f4")
        log_action("CLOSE_WINDOW", {})
        return {"status": "SUCCESS", "action": action}

    elif action == "close_tab":
        if PYAUTOGUI_AVAILABLE:
            if system_os == "Darwin":
                pyautogui.hotkey("command", "w")
            else:
                pyautogui.hotkey("ctrl", "w")
        log_action("CLOSE_TAB", {})
        return {"status": "SUCCESS", "action": action}

    elif action == "switch_window":
        if PYAUTOGUI_AVAILABLE:
            if system_os == "Darwin":
                pyautogui.hotkey("command", "tab")
            else:
                pyautogui.hotkey("alt", "tab")
        log_action("SWITCH_WINDOW", {})
        return {"status": "SUCCESS", "action": action}

    else:
        return {"status": "UNKNOWN_ACTION", "action": action}

# HTTP Handler bound strictly to 127.0.0.1
class ComputerControlHTTPHandler(BaseHTTPRequestHandler):
    def _send_json(self, status_code, data):
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode("utf-8"))

    def do_OPTIONS(self):
        self._send_json(200, {"status": "OK"})

    def do_GET(self):
        client_ip = self.client_address[0]
        if client_ip not in ["127.0.0.1", "::1", "localhost"]:
            self._send_json(403, {"error": "Forbidden. Only localhost connections accepted."})
            return

        parsed = urlparse(self.path)
        if parsed.path == "/status":
            self._send_json(200, {
                "running": True,
                "pyautogui": PYAUTOGUI_AVAILABLE,
                "pynput": PYNPUT_AVAILABLE,
                "os": platform.system(),
                "queueLength": action_queue.qsize()
            })
        elif parsed.path == "/settings":
            self._send_json(200, load_config())
        elif parsed.path == "/logs":
            logs = []
            if os.path.exists(LOG_PATH):
                with open(LOG_PATH, "r", encoding="utf-8") as f:
                    logs = f.readlines()[-50:]
            self._send_json(200, {"logs": logs})
        else:
            self._send_json(404, {"error": "Not found"})

    def do_POST(self):
        client_ip = self.client_address[0]
        if client_ip not in ["127.0.0.1", "::1", "localhost"]:
            self._send_json(403, {"error": "Forbidden. Only localhost connections accepted."})
            return

        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)
        try:
            data = json.loads(body.decode("utf-8")) if body else {}
        except Exception:
            self._send_json(400, {"error": "Invalid JSON"})
            return

        parsed = urlparse(self.path)

        # Emergency STOP Endpoint
        if parsed.path == "/stop":
            abort_all_actions(reason="VOICE_OR_USER_STOP_COMMAND")
            self._send_json(200, {"status": "STOPPED", "message": "All current and queued actions aborted"})
            return

        # Settings update endpoint
        elif parsed.path == "/settings":
            current = load_config()
            current.update(data)
            save_config(current)
            self._send_json(200, {"status": "UPDATED", "config": current})
            return

        # Action execution endpoint
        elif parsed.path in ["/execute", "/api/computer-control/execute"]:
            result_holder = {}
            action_queue.put((data, result_holder))
            
            # Wait for execution or stop
            start_t = time.time()
            while "status" not in result_holder and time.time() - start_t < 15.0:
                time.sleep(0.05)
            
            if "status" not in result_holder:
                self._send_json(202, {"status": "QUEUED", "message": "Action queued for execution"})
            else:
                self._send_json(200, result_holder)
            return

        else:
            self._send_json(404, {"error": "Endpoint not found"})

def run_backend(port=5005):
    setup_esc_emergency_listener()
    worker_thread = threading.Thread(target=action_worker, daemon=True)
    worker_thread.start()

    server_address = ("127.0.0.1", port)
    httpd = HTTPServer(server_address, ComputerControlHTTPHandler)
    print(f"[MUKE Backend] Listening exclusively on 127.0.0.1:{port}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()

if __name__ == "__main__":
    port = 5005
    if len(sys.argv) > 1:
        port = int(sys.argv[1])
    run_backend(port)
