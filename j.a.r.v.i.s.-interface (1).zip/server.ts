import express, { Request, Response } from 'express';
import http from 'http';
import fs from 'fs';
import path from 'path';
import { spawn, exec } from 'child_process';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const HOST = '0.0.0.0';

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

const CONFIG_PATH = path.resolve(process.cwd(), 'computer_control_config.json');
const LOG_PATH = path.resolve(process.cwd(), 'computer_control.log');

// Action logging
function logAction(action: string, details: any, status: string = 'SUCCESS') {
  const timestamp = new Date().toISOString();
  const logLine = `${timestamp} [INFO] ACTION: ${action} | STATUS: ${status} | DETAILS: ${JSON.stringify(details)}\n`;
  try {
    fs.appendFileSync(LOG_PATH, logLine, 'utf8');
  } catch (err) {
    console.error('Failed to write action log:', err);
  }
}

// Load / Save Config
const DEFAULT_CONFIG = {
  wakeWordCooldownSeconds: 2.0,
  commandListeningTimeoutSeconds: 10.0,
  delayBetweenActionsSeconds: 0.5,
  typingSpeedSecondsPerChar: 0.05,
  clickSpeedSeconds: 0.1,
};

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
      return { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
    }
  } catch (e) {
    console.error('Error reading config:', e);
  }
  return { ...DEFAULT_CONFIG };
}

function saveConfig(cfg: any) {
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2), 'utf8');
    logAction('UPDATE_CONFIG', cfg, 'SUCCESS');
    return true;
  } catch (e) {
    logAction('UPDATE_CONFIG', { error: String(e) }, 'ERROR');
    return false;
  }
}

// Global active action cancellation token
let isStopRequested = false;

// Attempt to start Python background worker if available
let pythonBackendProcess: any = null;
try {
  const pythonScript = path.resolve(process.cwd(), 'computer_control_backend.py');
  if (fs.existsSync(pythonScript)) {
    pythonBackendProcess = spawn('python3', [pythonScript, '5005'], {
      stdio: 'ignore',
      detached: true,
    });
    pythonBackendProcess.unref();
  }
} catch (e) {
  // Python backend optional or already running
}

// Verify local request middleware (Allow 127.0.0.1, localhost, or same-origin)
function requireLocalAccess(req: Request, res: Response, next: () => void) {
  const ip = req.ip || req.socket.remoteAddress || '';
  const host = req.headers.host || '';
  const isLocal =
    ip.includes('127.0.0.1') ||
    ip.includes('::1') ||
    ip === '::ffff:127.0.0.1' ||
    host.includes('localhost') ||
    host.includes('127.0.0.1') ||
    process.env.NODE_ENV !== 'production';

  if (!isLocal) {
    return res.status(403).json({ error: 'Access forbidden. Localhost only.' });
  }
  next();
}

// Stop endpoint
app.post('/api/computer-control/stop', requireLocalAccess, async (req: Request, res: Response) => {
  isStopRequested = true;
  logAction('STOP_COMMAND', { trigger: 'USER_STOP_VOICE_OR_EMERGENCY' }, 'ABORTED');

  // Try notifying python backend on 5005 if running
  try {
    await fetch('http://127.0.0.1:5005/stop', { method: 'POST', signal: AbortSignal.timeout(500) }).catch(() => {});
  } catch {
    // ignore
  }

  setTimeout(() => {
    isStopRequested = false;
  }, 1000);

  res.json({ status: 'STOPPED', message: 'All actions and queued operations stopped immediately.' });
});

// Settings endpoints
app.get('/api/computer-control/settings', requireLocalAccess, (req: Request, res: Response) => {
  res.json(loadConfig());
});

app.post('/api/computer-control/settings', requireLocalAccess, (req: Request, res: Response) => {
  const current = loadConfig();
  const updated = { ...current, ...req.body };
  saveConfig(updated);
  res.json({ status: 'UPDATED', config: updated });
});

// Action Execution endpoint
app.post('/api/computer-control/execute', requireLocalAccess, async (req: Request, res: Response) => {
  const { action, confirmed, ...params } = req.body;

  if (isStopRequested) {
    return res.json({ status: 'ABORTED', message: 'Stop was requested' });
  }

  // Safety confirmation check
  const destructiveActions = ['delete_file', 'delete_folder', 'shutdown', 'reboot'];
  const isDestructive = destructiveActions.includes(action) || (action === 'create_file' && params.overwrite);
  const isCloseApp = action === 'close_app';

  if ((isDestructive || isCloseApp) && !confirmed) {
    const promptMessage = isCloseApp
      ? `Are you sure you want to close ${params.appName || 'the app'}? Any unsaved work might be lost.`
      : `Are you sure you want to perform this destructive action: ${action}?`;
    return res.json({
      status: 'CONFIRMATION_REQUIRED',
      requireConfirmation: true,
      message: promptMessage,
      actionPayload: req.body,
    });
  }

  // Try Python backend first
  try {
    const pyResp = await fetch('http://127.0.0.1:5005/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...params }),
      signal: AbortSignal.timeout(3000),
    });
    if (pyResp.ok) {
      const data = await pyResp.json();
      return res.json(data);
    }
  } catch {
    // Fall back to Node.js local execution
  }

  // Native Node.js execution fallback
  try {
    const result = await executeNativeAction(action, params);
    logAction(action, params, 'SUCCESS');
    return res.json({ status: 'SUCCESS', action, result });
  } catch (err: any) {
    logAction(action, { ...params, error: err.message }, 'ERROR');
    return res.status(500).json({ status: 'ERROR', message: err.message });
  }
});

// Helper for native node execution
async function executeNativeAction(action: string, params: any) {
  switch (action) {
    case 'web_search': {
      const query = encodeURIComponent(params.query || '');
      const url = `https://www.google.com/search?q=${query}`;
      openUrlNative(url);
      return { searched: params.query, url };
    }
    case 'open_url': {
      let url = params.url || '';
      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url;
      }
      openUrlNative(url);
      return { opened: url };
    }
    case 'create_folder': {
      const folderPath = path.resolve(process.cwd(), params.path || 'New_Folder');
      fs.mkdirSync(folderPath, { recursive: true });
      return { createdFolder: folderPath };
    }
    case 'create_file': {
      const filePath = path.resolve(process.cwd(), params.path || 'new_file.txt');
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(filePath, params.content || '', 'utf8');
      return { createdFile: filePath };
    }
    case 'delete_file': {
      const filePath = path.resolve(process.cwd(), params.path);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        return { deletedFile: filePath };
      }
      return { error: 'File does not exist' };
    }
    case 'delete_folder': {
      const folderPath = path.resolve(process.cwd(), params.path);
      if (fs.existsSync(folderPath)) {
        fs.rmSync(folderPath, { recursive: true, force: true });
        return { deletedFolder: folderPath };
      }
      return { error: 'Folder does not exist' };
    }
    case 'open_app': {
      const appName = params.appName || '';
      if (process.platform === 'win32') {
        exec(`start ${appName}`);
      } else if (process.platform === 'darwin') {
        exec(`open -a "${appName}"`);
      } else {
        exec(`${appName} || xdg-open "${appName}"`);
      }
      return { openedApp: appName };
    }
    case 'close_app': {
      const appName = params.appName || '';
      if (process.platform === 'win32') {
        exec(`taskkill /IM ${appName}* /F`);
      } else {
        exec(`pkill -f "${appName}"`);
      }
      return { closedApp: appName };
    }
    default:
      return { simulated: true, action, params };
  }
}

function openUrlNative(url: string) {
  if (process.platform === 'win32') {
    exec(`start "" "${url}"`);
  } else if (process.platform === 'darwin') {
    exec(`open "${url}"`);
  } else {
    exec(`xdg-open "${url}"`);
  }
}

// Weather Forecast Endpoint (Open-Meteo with fallback)
app.get('/api/weather', async (req: Request, res: Response) => {
  try {
    const lat = req.query.lat ? String(req.query.lat) : '28.6139';
    const lon = req.query.lon ? String(req.query.lon) : '77.2090';
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min&timezone=auto`;
    const response = await fetch(url, { signal: AbortSignal.timeout(4000) });
    if (response.ok) {
      const data = await response.json();
      return res.json({ status: 'SUCCESS', data });
    }
    return res.json({
      status: 'FALLBACK',
      data: {
        current: { temperature_2m: 24, apparent_temperature: 24, weather_code: 0, relative_humidity_2m: 50, wind_speed_10m: 8 },
        daily: { temperature_2m_max: [28], temperature_2m_min: [19] }
      }
    });
  } catch (err: any) {
    return res.json({
      status: 'FALLBACK',
      data: {
        current: { temperature_2m: 24, apparent_temperature: 24, weather_code: 0, relative_humidity_2m: 50, wind_speed_10m: 8 },
        daily: { temperature_2m_max: [28], temperature_2m_min: [19] }
      }
    });
  }
});

// Vision Analysis Endpoint (Gemini 2.5 Flash Multimodal Vision)
app.post('/api/vision/analyze', async (req: Request, res: Response) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', prompt = 'Analyze what you see in this snapshot', language = 'en' } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'imageBase64 is required' });
    }

    const cleanBase64 = String(imageBase64).replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '');

    const ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    const langInstruction = language === 'hi'
      ? 'CRITICAL: The user speaks Hindi (हिन्दी). Provide your spoken summary and main insights in Hindi.'
      : language === 'ur'
      ? 'CRITICAL: The user speaks Urdu (اردو). Provide your spoken summary and main insights in Urdu.'
      : 'CRITICAL: The user speaks English. Provide your spoken summary and explanation in English.';

    const systemInstruction = `You are MUKE, a world-class AI vision intelligence assistant created by Asad.
You are inspecting a live screen capture or camera snapshot presented by the user.
${langInstruction}
- If code is shown on screen: accurately detect the programming language, locate bugs or errors, explain the fix concisely, and give the corrected code.
- If a math or scientific problem is shown: solve it step-by-step with clear reasoning and the final solution.
- If handwritten notes or text in any language are shown: transcribe and translate accurately.
- If physical objects, devices, or scenes are shown: identify them and provide practical, direct commentary.
- FORMAT REQUIREMENT:
  Start your response with:
  [SPOKEN_SUMMARY: Write a 1-to-2 sentence direct, punchy answer for the text-to-speech voice to immediately read aloud]
  Followed by your clean, well-formatted Markdown explanation with headers, bullet points, and code blocks as appropriate.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType || 'image/jpeg',
              data: cleanBase64,
            }
          },
          {
            text: prompt || 'Analyze this snapshot thoroughly and explain what you see.',
          }
        ]
      },
      config: {
        systemInstruction,
      }
    });

    const fullText = response.text || '';
    let spokenSummary = '';
    let formattedText = fullText;

    const summaryMatch = fullText.match(/\[SPOKEN_SUMMARY:\s*([\s\S]*?)\]/);
    if (summaryMatch) {
      spokenSummary = summaryMatch[1].trim();
      formattedText = fullText.replace(/\[SPOKEN_SUMMARY:\s*[\s\S]*?\]/, '').trim();
    } else {
      const firstSentence = fullText.split(/[.!?\n]/).filter(Boolean)[0] || '';
      spokenSummary = firstSentence.slice(0, 160).trim();
    }

    logAction('VISION_ANALYZE', { prompt, language }, 'SUCCESS');

    return res.json({
      status: 'SUCCESS',
      text: formattedText,
      spokenSummary: spokenSummary || formattedText.slice(0, 160)
    });
  } catch (err: any) {
    console.error('Vision analysis failure:', err);
    logAction('VISION_ANALYZE', { error: err.message }, 'ERROR');
    return res.status(500).json({ error: err.message || 'Vision analysis failed' });
  }
});

// Daily Morning Briefing Endpoint
app.post('/api/briefing/generate', async (req: Request, res: Response) => {
  try {
    const { userName = 'Asad', language = 'en', timeStr = new Date().toLocaleString(), weatherDesc = 'Pleasant & clear, 24°C', pendingTasks = [] } = req.body;

    const ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    const langInstruction = language === 'hi'
      ? 'The user speaks Hindi (हिन्दी). Generate the entire morning greeting, briefing, and energizing quote in Hindi (हिन्दी).'
      : language === 'ur'
      ? 'The user speaks Urdu (اردو). Generate the entire morning greeting, briefing, and energizing quote in Urdu (اردو).'
      : 'The user speaks English. Generate the morning greeting, briefing, and energizing quote in English.';

    const systemInstruction = `You are MUKE, an intelligent personal AI assistant and advisor created by Asad.
You are delivering the official Daily Morning Briefing.
${langInstruction}
Requirements:
1. Warm greeting addressing ${userName} by name (e.g., "Good morning ${userName}!" / "सुप्रभात ${userName}!" / "صبح بخیر ${userName}!").
2. Time and weather mention (${timeStr}, ${weatherDesc}).
3. Task rundown: summarize pending tasks (${pendingTasks.length > 0 ? `${pendingTasks.length} pending tasks: ${pendingTasks.slice(0, 3).map((t: any) => t.title).join(', ')}` : 'All tasks cleared for today'}).
4. Inspiring high-performance quote or productivity spark for the day in the selected language.
5. Offer to start morning focus music or stream latest news on YouTube.
FORMAT REQUIREMENT:
Start your response with:
[SPOKEN_BRIEFING: A concise, highly energizing 2-to-3 sentence spoken voice summary to be spoken aloud right now via TTS]
Followed by the clean Markdown briefing card text with emoji bullets, bold stats, and an inspirational quote block.`;

    const prompt = `Generate the daily morning briefing for ${userName}.
Current Time: ${timeStr}
Current Weather: ${weatherDesc}
Pending Tasks: ${JSON.stringify(pendingTasks)}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction,
      }
    });

    const fullText = response.text || '';
    let spokenBriefing = '';
    let cardText = fullText;

    const briefingMatch = fullText.match(/\[SPOKEN_BRIEFING:\s*([\s\S]*?)\]/);
    if (briefingMatch) {
      spokenBriefing = briefingMatch[1].trim();
      cardText = fullText.replace(/\[SPOKEN_BRIEFING:\s*[\s\S]*?\]/, '').trim();
    } else {
      spokenBriefing = fullText.slice(0, 200).trim();
    }

    logAction('DAILY_BRIEFING', { userName, language }, 'SUCCESS');

    return res.json({
      status: 'SUCCESS',
      text: cardText,
      spokenBriefing: spokenBriefing || cardText.slice(0, 200)
    });
  } catch (err: any) {
    console.error('Briefing error:', err);
    logAction('DAILY_BRIEFING', { error: err.message }, 'ERROR');
    return res.status(500).json({ error: err.message || 'Briefing generation failed' });
  }
});

// Start dev server with Vite middleware or static dist
async function startServer() {
  if (process.env.NODE_ENV === 'production' && fs.existsSync(path.resolve(process.cwd(), 'dist'))) {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(process.cwd(), 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const server = http.createServer(app);
  server.listen(PORT, HOST, () => {
    console.log(`MUKE full-stack server running on http://${HOST}:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
