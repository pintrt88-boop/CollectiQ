/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import LiveAudioCore from './components/LiveAudioCore';

export default function App() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans flex items-center justify-center">
      <LiveAudioCore />
    </div>
  );
}
