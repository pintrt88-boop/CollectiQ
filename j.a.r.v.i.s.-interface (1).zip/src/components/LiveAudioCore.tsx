import React, { useState, useRef, useEffect, useMemo } from 'react';
import Markdown from 'react-markdown';
import { ai } from '../lib/gemini';
import { 
  Mic, MicOff, Activity, CheckSquare, ListTodo, BookOpen, Clock, Cloud, 
  Trash2, Camera, CameraOff, MonitorUp, MonitorOff, User, Play, Pause, 
  SkipBack, SkipForward, Volume2, VolumeX, Cpu, HardDrive, Settings, Info,
  Copy, Check, Search, Download, Sparkles, CornerDownLeft, RefreshCw, Sliders, MessageSquare,
  Brain, Zap, Radio, Sun, Eye, Code2, Calculator, ExternalLink, Maximize2, Upload
} from 'lucide-react';
import { Modality, Type } from '@google/genai';

interface Task {
  id: string;
  title: string;
  completed: boolean;
  reminderTime?: number;
  notified?: boolean;
}

interface UserProfile {
  fullName: string;
  email: string;
  preferences: {
    timeFormat: '12h' | '24h';
    sfxEnabled: boolean;
    waveformColor: 'blue' | 'purple' | 'green' | 'teal';
    aiVoiceLanguage?: 'en' | 'hi' | 'ur';
    ttsVoiceName?: string;
    ttsPitch?: number;
    ttsRate?: number;
    masterVolume?: number;
  };
}

const playNotificationSound = (sfxEnabled: boolean = true) => {
  if (!sfxEnabled) return;
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    
    const playTone = (freq: number, startTime: number, duration: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.1, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(startTime);
      osc.stop(startTime + duration);
    };

    // Play a pleasant double chime (C5 then E5)
    playTone(523.25, ctx.currentTime, 0.3);
    playTone(659.25, ctx.currentTime + 0.15, 0.5);
  } catch (e) {
    console.error("Failed to play notification sound", e);
  }
};

export default function LiveAudioCore() {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  
  const sessionRef = useRef<any>(null);
  const activeLiveSessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const nextPlayTimeRef = useRef<number>(0);
  const scheduledSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const speakingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Fast Streaming TTS queue refs
  const ttsQueueRef = useRef<string[]>([]);
  const isTTSPlayingRef = useRef<boolean>(false);
  const currentTTSMsgIdRef = useRef<string | null>(null);
  const dictationTextRef = useRef<string>("");
  const dictationSilenceTimerRef = useRef<any>(null);
  const recognitionInstanceRef = useRef<any>(null);
  const activeUtterancesRef = useRef<SpeechSynthesisUtterance[]>([]);
  const silenceFrameCountRef = useRef<number>(0);

  // Audio recording & Volume meter refs
  const dictationStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedAudioChunksRef = useRef<Blob[]>([]);
  const analyserNodeRef = useRef<AnalyserNode | null>(null);
  const volumeAnimFrameRef = useRef<number | null>(null);
  const [audioLevel, setAudioLevel] = useState<number>(0);

  // Hands-free Voice Wake-Word Engine ("Hey Mute" and variants)
  const wakeWordRecognitionRef = useRef<any>(null);
  const wakeWordActiveRef = useRef<boolean>(false);
  const wakeWordPausedRef = useRef<boolean>(false);
  const lastWakeWordTriggerTimeRef = useRef<number>(0);
  const micPermissionRequestedRef = useRef<boolean>(false);
  const [settingsAiLanguage, setSettingsAiLanguage] = useState<'en' | 'hi' | 'ur'>(() => {
    try {
      const saved = localStorage.getItem('aiVoiceLanguage');
      if (saved === 'en' || saved === 'hi' || saved === 'ur') return saved as 'en' | 'hi' | 'ur';
      const savedProfile = localStorage.getItem('userProfile');
      if (savedProfile) {
        const p = JSON.parse(savedProfile);
        if (p?.preferences?.aiVoiceLanguage) return p.preferences.aiVoiceLanguage;
      }
    } catch {}
    return 'en';
  });
  const wakeWordLangRef = useRef<string>('en-IN');
  const wakeWordRestartTimeoutRef = useRef<any>(null);
  const wakeWordSafetyFallbackTimeoutRef = useRef<any>(null);
  const currentAudioElementRef = useRef<HTMLAudioElement | null>(null);
  const streamTTSQueueRef = useRef<string[]>([]);
  const isStreamTTSPlayingRef = useRef<boolean>(false);
  const handleMicButtonClickRef = useRef<(initialText?: string) => void>(() => {});

  // Full Computer Control State & Config
  interface ControlConfig {
    wakeWordCooldownSeconds: number;
    commandListeningTimeoutSeconds: number;
    delayBetweenActionsSeconds: number;
    typingSpeedSecondsPerChar: number;
    clickSpeedSeconds: number;
  }
  const controlConfigRef = useRef<ControlConfig>({
    wakeWordCooldownSeconds: 2.0,
    commandListeningTimeoutSeconds: 10.0,
    delayBetweenActionsSeconds: 0.5,
    typingSpeedSecondsPerChar: 0.05,
    clickSpeedSeconds: 0.1,
  });
  const pendingDestructiveActionRef = useRef<{
    action: string;
    params: any;
    promptText: string;
  } | null>(null);

  const [commandText, setCommandText] = useState("");
  const [isCommanding, setIsCommanding] = useState(false);
  const [tasks, setTasks] = useState<Task[]>(() => {
    try {
      const saved = localStorage.getItem('tasks');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  const [showTasks, setShowTasks] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskReminder, setNewTaskReminder] = useState("");

  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [onboardName, setOnboardName] = useState("");
  const [onboardEmail, setOnboardEmail] = useState("");

  const [showSettings, setShowSettings] = useState(false);
  const [settingsTab, setSettingsTab] = useState<'profile' | 'voice' | 'prefs' | 'agi'>('profile');
  const [settingsName, setSettingsName] = useState("");
  const [settingsEmail, setSettingsEmail] = useState("");
  const [settingsTimeFormat, setSettingsTimeFormat] = useState<'12h' | '24h'>('12h');
  const [settingsSfxEnabled, setSettingsSfxEnabled] = useState(true);
  const [settingsWaveformColor, setSettingsWaveformColor] = useState<'blue' | 'purple' | 'green' | 'teal'>('blue');
  const [settingsTtsVoice, setSettingsTtsVoice] = useState<string>('');
  const [settingsTtsPitch, setSettingsTtsPitch] = useState<number>(0.85);
  const [settingsTtsRate, setSettingsTtsRate] = useState<number>(1.05);
  const [settingsMasterVolume, setSettingsMasterVolume] = useState<number>(1);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [isDictating, setIsDictating] = useState(false);

  // Chat UI enhancements state
  const [chatSearchQuery, setChatSearchQuery] = useState("");
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [playingMsgId, setPlayingMsgId] = useState<string | null>(null);
  const [autoScrollChat, setAutoScrollChat] = useState(true);

  useEffect(() => {
    const loadVoices = () => {
      setAvailableVoices(window.speechSynthesis.getVoices());
    };
    loadVoices();
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  const [notes, setNotes] = useState<{id: string, text: string, date: number}[]>(() => {
    try {
      const saved = localStorage.getItem('notes');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  const [showNotes, setShowNotes] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [newNoteText, setNewNoteText] = useState("");
  const [weather, setWeather] = useState<{temp: number, condition: string} | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [confirmOpenUrl, setConfirmOpenUrl] = useState<{url: string, name: string} | null>(null);

  const [isCameraOn, setIsCameraOn] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [visionMenuOpen, setVisionMenuOpen] = useState(false);
  const [activeVoice, setActiveVoice] = useState<'Charon' | 'Fenrir' | 'Kore'>('Charon'); // Charon = Calm Deep Jarvis, Fenrir = Deep, Kore = F.R.I.D.A.Y
  
  // Chat History State
  const [chatHistory, setChatHistory] = useState<{ 
    id: string; 
    role: 'user' | 'ai'; 
    text: string; 
    timestamp: number;
    isAgiAutonomous?: boolean;
    agiPersona?: 'companion' | 'intellect' | 'productivity' | 'curious';
    isDailyBriefing?: boolean;
    briefingWeather?: string;
    briefingTime?: string;
    briefingTasksCount?: number;
    isVisionAnalysis?: boolean;
    visionSnapshot?: string;
    visionSource?: 'camera' | 'screen' | 'upload';
    visionPrompt?: string;
  }[]>(() => {
    try {
      const saved = localStorage.getItem('chatHistory');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Daily Morning Briefing State
  const [isBriefingLoading, setIsBriefingLoading] = useState<boolean>(false);
  const [showBriefingModal, setShowBriefingModal] = useState<boolean>(false);

  // Vision Intelligence Assistant State
  const [showVisionModal, setShowVisionModal] = useState<boolean>(false);
  const [isVisionAnalyzing, setIsVisionAnalyzing] = useState<boolean>(false);
  const [visionSource, setVisionSource] = useState<'screen' | 'camera' | 'upload'>('screen');
  const [visionCapturedImage, setVisionCapturedImage] = useState<string | null>(null);
  const [visionInputPrompt, setVisionInputPrompt] = useState<string>('');
  const [previewEnlargedImage, setPreviewEnlargedImage] = useState<string | null>(null);

  // Autonomous AGI Mode State
  const [agiAutonomousActive, setAgiAutonomousActive] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('agiAutonomousActive');
      return saved !== null ? JSON.parse(saved) : true;
    } catch { return true; }
  });
  const [agiIntervalSeconds, setAgiIntervalSeconds] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('agiIntervalSeconds');
      return saved ? JSON.parse(saved) : 25;
    } catch { return 25; }
  });
  const [agiAutoVoice, setAgiAutoVoice] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('agiAutoVoice');
      return saved !== null ? JSON.parse(saved) : true;
    } catch { return true; }
  });
  const [agiPersona, setAgiPersona] = useState<'companion' | 'intellect' | 'productivity' | 'curious'>(() => {
    try {
      const saved = localStorage.getItem('agiPersona');
      return saved ? JSON.parse(saved) : 'companion';
    } catch { return 'companion'; }
  });
  const [agiCountdown, setAgiCountdown] = useState<number>(25);
  const [isAgiThinking, setIsAgiThinking] = useState<boolean>(false);
  const [showAgiModal, setShowAgiModal] = useState<boolean>(false);
  const lastUserInteractionTimeRef = useRef<number>(Date.now());
  const agiExecutingRef = useRef<boolean>(false);

  useEffect(() => {
    localStorage.setItem('agiAutonomousActive', JSON.stringify(agiAutonomousActive));
  }, [agiAutonomousActive]);

  useEffect(() => {
    localStorage.setItem('agiIntervalSeconds', JSON.stringify(agiIntervalSeconds));
  }, [agiIntervalSeconds]);

  useEffect(() => {
    localStorage.setItem('agiAutoVoice', JSON.stringify(agiAutoVoice));
  }, [agiAutoVoice]);

  useEffect(() => {
    localStorage.setItem('agiPersona', JSON.stringify(agiPersona));
  }, [agiPersona]);

  // Scroll to bottom of chat when history updates
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatHistory]);
  
  // Gesture recognition state
  const [recognizedGesture, setRecognizedGesture] = useState<string | null>(null);
  const gestureTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const triggerGesture = (gesture: string) => {
    setRecognizedGesture(gesture);
    if (gestureTimeoutRef.current) clearTimeout(gestureTimeoutRef.current);
    gestureTimeoutRef.current = setTimeout(() => {
      setRecognizedGesture(null);
    }, 4000);
  };

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const screenVideoRef = useRef<HTMLVideoElement | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const visionIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const proactiveIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    let isMounted = true;
    const controller = new AbortController();

    if (typeof navigator !== 'undefined' && "geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          try {
            const { latitude, longitude } = position.coords;
            const res = await fetch(
              `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true`,
              { signal: controller.signal }
            ).catch(() => null);

            if (!res || !res.ok) return;
            const data = await res.json().catch(() => null);
            if (!data?.current_weather || !isMounted) return;

            const code = data.current_weather.weathercode;
            let icon = '☁️';
            if (code === 0) icon = '☀️';
            else if (code >= 1 && code <= 3) icon = '⛅';
            else if (code >= 45 && code <= 48) icon = '🌫️';
            else if (code >= 51 && code <= 67) icon = '🌧️';
            else if (code >= 71 && code <= 77) icon = '❄️';
            else if (code >= 95) icon = '⛈️';
            
            setWeather({
              temp: data.current_weather.temperature,
              condition: icon
            });
          } catch {
            // Silently handle any network/offline error
          }
        },
        (err) => {
          // Geolocation denied or unavailable
          console.debug("Geolocation skipped:", err?.message);
        },
        { timeout: 5000, maximumAge: 60000 }
      );
    }

    return () => {
      isMounted = false;
      controller.abort();
    };
  }, []);

  // Fuzzy stop phrase matcher: Hindi, Hinglish, English (e.g. Stop, Ruko, Ruk jao, स्टॉप)
  const isStopPhrase = (rawText: string): boolean => {
    if (!rawText) return false;
    const clean = rawText.toLowerCase().trim();
    if (/स्टॉप|रुको|रुक\s*जाओ|रुकजा|रुक\b/u.test(clean)) return true;
    if (/\b(stop|ruko|ruk\s*jao|rukjao|ruk\s*ja|abort|halt|cancel)\b/i.test(clean)) return true;
    return false;
  };

  // Immediate STOP: Cancel current/queued backend action, stop AI speech, return to wake-word listening
  const handleStopEverything = async (reason = "Stop triggered") => {
    console.log(`[MUKE] STOP command executed: ${reason}`);
    try {
      fetch('/api/computer-control/stop', { method: 'POST' }).catch(() => {});
    } catch {}

    stopTTS();
    if (dictationSilenceTimerRef.current) {
      clearTimeout(dictationSilenceTimerRef.current);
      dictationSilenceTimerRef.current = null;
    }
    if (recognitionInstanceRef.current) {
      try { recognitionInstanceRef.current.stop(); } catch (e) {}
      recognitionInstanceRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try { mediaRecorderRef.current.stop(); } catch (e) {}
    }

    setIsDictating(false);
    setIsCommanding(false);
    pendingDestructiveActionRef.current = null;
    setToastMessage("Automation stopped.");
    setTimeout(() => setToastMessage(null), 1500);

    // Return to silent wake-word listening
    resumeWakeWordListening();
  };

  // Computer Control Executor
  const executeComputerControlAction = async (action: string, params: any) => {
    const destructive = ['delete_file', 'delete_folder', 'shutdown', 'reboot'].includes(action);
    const isCloseApp = action === 'close_app';
    if ((destructive || isCloseApp) && !params.confirmed) {
      const prompt = isCloseApp
        ? `Are you sure you want to close ${params.appName || 'the app'}? Any unsaved work might be lost.`
        : `Are you sure you want to delete ${params.path || 'the file'}?`;
      pendingDestructiveActionRef.current = {
        action,
        params,
        promptText: prompt
      };
      return { confirmationRequired: true, prompt };
    }

    try {
      const res = await fetch('/api/computer-control/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ...params })
      });
      const data = await res.json();
      return data;
    } catch (err) {
      console.error("Action execution error:", err);
      return { status: "ERROR", error: String(err) };
    }
  };

  const updateTimingConfig = async (partial: Partial<ControlConfig>) => {
    controlConfigRef.current = { ...controlConfigRef.current, ...partial };
    try {
      await fetch('/api/computer-control/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(partial)
      });
    } catch (e) {
      console.error("Config update error:", e);
    }
  };

  // Wake-word matcher: Activates ONLY on "hey jarvis", "popkorn", "hey muk", "muk", "asad"
  const matchWakeWordPhrase = (rawText: string): { matched: boolean; wakeWord?: string; queryAfter: string } => {
    if (!rawText) return { matched: false, queryAfter: '' };

    // 1. Urdu Script Matching: اے جاروس / جاروس / پاپ کارن / اے مک / مک / اسد
    const urduRegex = /(?:اے\s*جاروس|ہے\s*جاروس|جاروس|جارویز|پاپ\s*کارن|پاپکورن|اے\s*مُ?ک|ہے\s*مُ?ک|\bمُ?ک\b|اسد|اسعد)/u;
    const urduMatch = rawText.match(urduRegex);
    if (urduMatch && urduMatch.index !== undefined) {
      const queryAfter = rawText.slice(urduMatch.index + urduMatch[0].length).trim();
      return { matched: true, wakeWord: urduMatch[0], queryAfter };
    }

    // 2. Hindi Devanagari Script Matching: हे जार्विस / जार्विस / पॉपकॉर्न / हे मुक / मुक / असद
    const hindiRegex = /(?:हे\s*जार्विस|हे\s*जारविस|जार्विस|जारविस|पॉप\s*कॉर्न|पॉपकॉर्न|पॉपकोर्न|पापकार्न|पापकोर्न|हे\s*मुक|हे\s*मक|हे\s*मूक|हे\s*मुके|हे\s*मक्क|\b(?:मुक|मक|मूक|मुके|मक्क)\b|असद|असद्|आज़ाद|असाद)/iu;
    const hindiMatch = rawText.match(hindiRegex);
    if (hindiMatch && hindiMatch.index !== undefined) {
      const queryAfter = rawText.slice(hindiMatch.index + hindiMatch[0].length).trim();
      return { matched: true, wakeWord: hindiMatch[0], queryAfter };
    }

    // 3. Normalized English & Latin Transliterations
    const clean = rawText
      .toLowerCase()
      .replace(/[\.,-\/#!$%\^&\*;:{}=\-_`~()?]/g, " ")
      .replace(/\s+/g, " ")
      .trim();

    // Ranked list of exact phrases: only "hey jarvis", "popkorn", "hey muk", "muk", "asad"
    const directPhrases = [
      // "hey jarvis" & "jarvis"
      "hey jarvis", "he jarvis", "hay jarvis", "hi jarvis", "hello jarvis", "jarvis",
      // "popkorn" & "popcorn"
      "pop korn", "pop corn", "popkorn", "popcorn", "papkorn", "papcorn",
      // "hey muk"
      "hey muk", "he muk", "hay muk", "hai muk", "hi muk", "hey mook", "he mook", "hey muck", "he muck", "hey muke", "he muke", "hey mukk",
      // "asad"
      "asad", "assad", "aasad", "asaad",
      // "muk"
      "muk", "mook", "muck", "muke", "mukk"
    ];

    for (const phrase of directPhrases) {
      // For single words (muk, asad), enforce whole-word boundary
      if (phrase === "muk" || phrase === "mook" || phrase === "muck" || phrase === "muke" || phrase === "mukk" || phrase === "asad" || phrase === "assad" || phrase === "aasad" || phrase === "asaad") {
        const wordRegex = new RegExp(`(^|\\s)${phrase}(\\s|$)`, 'i');
        const match = clean.match(wordRegex);
        if (match && match.index !== undefined) {
          const matchStart = match.index + match[1].length;
          const matchEnd = matchStart + phrase.length;
          const queryAfter = clean.slice(matchEnd).trim();
          return { matched: true, wakeWord: phrase, queryAfter };
        }
      } else {
        const idx = clean.indexOf(phrase);
        if (idx !== -1) {
          const queryAfter = clean.slice(idx + phrase.length).trim();
          return { matched: true, wakeWord: phrase, queryAfter };
        }
      }
    }

    return { matched: false, queryAfter: '' };
  };

  const startWakeWordListening = () => {
    if (wakeWordPausedRef.current) return;
    if (wakeWordActiveRef.current) return;

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn("SpeechRecognition is not supported in this browser.");
      return;
    }

    // Reset previous instance cleanly to prevent InvalidStateError
    if (wakeWordRecognitionRef.current) {
      try {
        wakeWordRecognitionRef.current.onend = null;
        wakeWordRecognitionRef.current.onerror = null;
        wakeWordRecognitionRef.current.onresult = null;
        wakeWordRecognitionRef.current.abort();
      } catch (e) {}
      wakeWordRecognitionRef.current = null;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = wakeWordLangRef.current || 'en-IN';

      recognition.onresult = (event: any) => {
        if (wakeWordPausedRef.current) return;

        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += ' ' + event.results[i][0].transcript;
        }
        transcript = transcript.trim();
        if (!transcript) return;

        // Log every transcript (interim and final) to console as requested
        console.log(`[WakeWord Transcript]: "${transcript}"`);

        // Check for voice STOP command even in wake-word listening
        if (isStopPhrase(transcript)) {
          handleStopEverything("Voice Stop during wake-word listening");
          return;
        }

        const detection = matchWakeWordPhrase(transcript);
        if (detection.matched) {
          const now = Date.now();
          const cooldownMs = (controlConfigRef.current.wakeWordCooldownSeconds || 2) * 1000;
          if (now - lastWakeWordTriggerTimeRef.current < cooldownMs) {
            return; // Avoid double-triggering: configurable cooldown
          }
          lastWakeWordTriggerTimeRef.current = now;

          console.log(`[MUKE] Wake word activated: "${detection.wakeWord}" | Query: "${detection.queryAfter}"`);
          playNotificationSound(userProfile?.preferences?.sfxEnabled ?? true);
          setToastMessage(`⚡ "${detection.wakeWord}" activated - Listening...`);

          // Pause wake-word listening while AI handles interaction
          pauseWakeWordListening();

          // Automatically activate the AI with queryAfter
          if (handleMicButtonClickRef.current) {
            handleMicButtonClickRef.current(detection.queryAfter);
          }
        }
      };

      recognition.onerror = (event: any) => {
        console.warn("Wake word recognition error:", event.error);
        if (event.error === 'not-allowed') {
          console.warn("SpeechRecognition mic permission required.");
          wakeWordActiveRef.current = false;
          return;
        }
        if (event.error === 'language-not-supported') {
          wakeWordLangRef.current = 'en-IN';
        }
        wakeWordActiveRef.current = false;
        wakeWordRecognitionRef.current = null;
        // Auto-restart recognition in onerror after 300ms
        if (!wakeWordPausedRef.current) {
          if (wakeWordRestartTimeoutRef.current) clearTimeout(wakeWordRestartTimeoutRef.current);
          wakeWordRestartTimeoutRef.current = setTimeout(() => {
            if (!wakeWordPausedRef.current) {
              startWakeWordListening();
            }
          }, 300);
        }
      };

      recognition.onend = () => {
        wakeWordActiveRef.current = false;
        wakeWordRecognitionRef.current = null;
        // Auto-restart recognition in onend after 300ms
        if (!wakeWordPausedRef.current) {
          if (wakeWordRestartTimeoutRef.current) clearTimeout(wakeWordRestartTimeoutRef.current);
          wakeWordRestartTimeoutRef.current = setTimeout(() => {
            if (!wakeWordPausedRef.current) {
              startWakeWordListening();
            }
          }, 300);
        }
      };

      recognition.start();
      wakeWordRecognitionRef.current = recognition;
      wakeWordActiveRef.current = true;
    } catch (err) {
      console.warn("SpeechRecognition start error:", err);
      wakeWordActiveRef.current = false;
      wakeWordRecognitionRef.current = null;
    }
  };

  const pauseWakeWordListening = () => {
    wakeWordPausedRef.current = true;
    if (wakeWordRestartTimeoutRef.current) {
      clearTimeout(wakeWordRestartTimeoutRef.current);
    }
    if (wakeWordRecognitionRef.current) {
      try {
        wakeWordRecognitionRef.current.stop();
      } catch (e) {}
    }
    wakeWordActiveRef.current = false;

    // Safety fallback timer so listening never stays permanently paused
    if (wakeWordSafetyFallbackTimeoutRef.current) {
      clearTimeout(wakeWordSafetyFallbackTimeoutRef.current);
    }
    wakeWordSafetyFallbackTimeoutRef.current = setTimeout(() => {
      if (!isSpeaking && !isDictating && !isCommanding) {
        console.log("[WakeWord] Fallback safety timer fired - resuming wake word listening");
        resumeWakeWordListening();
      }
    }, 10000);
  };

  const resumeWakeWordListening = () => {
    if (wakeWordSafetyFallbackTimeoutRef.current) {
      clearTimeout(wakeWordSafetyFallbackTimeoutRef.current);
      wakeWordSafetyFallbackTimeoutRef.current = null;
    }
    wakeWordPausedRef.current = false;
    if (wakeWordRestartTimeoutRef.current) {
      clearTimeout(wakeWordRestartTimeoutRef.current);
    }
    wakeWordRestartTimeoutRef.current = setTimeout(() => {
      if (!wakeWordPausedRef.current) {
        startWakeWordListening();
      }
    }, 300);
  };

  // Keyboard emergency stop (Esc key held for 2s) & Mouse corner failsafe & Settings sync
  useEffect(() => {
    let escTimer: any = null;

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (!escTimer) {
          escTimer = setTimeout(() => {
            handleStopEverything("Keyboard emergency stop: Esc held 2 seconds");
            escTimer = null;
          }, 2000);
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (escTimer) {
          clearTimeout(escTimer);
          escTimer = null;
        }
      }
    };

    const onMouseMove = (e: MouseEvent) => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      // Mouse to screen corner aborts automation (failsafe)
      if (
        (e.clientX <= 5 && e.clientY <= 5) ||
        (e.clientX >= w - 5 && e.clientY <= 5) ||
        (e.clientX <= 5 && e.clientY >= h - 5) ||
        (e.clientX >= w - 5 && e.clientY >= h - 5)
      ) {
        if (isCommanding || isSpeaking) {
          handleStopEverything("Mouse corner failsafe triggered");
        }
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('mousemove', onMouseMove);

    // Initial load of timing settings from local backend
    fetch('/api/computer-control/settings')
      .then(r => r.json())
      .then(data => {
        if (data && typeof data.wakeWordCooldownSeconds === 'number') {
          controlConfigRef.current = { ...controlConfigRef.current, ...data };
        }
      })
      .catch(() => {});

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('mousemove', onMouseMove);
      if (escTimer) clearTimeout(escTimer);
    };
  }, [isCommanding, isSpeaking]);

  // Ask for microphone permission only once on first load & start background wake-word listening
  useEffect(() => {
    if (micPermissionRequestedRef.current) return;
    micPermissionRequestedRef.current = true;

    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ audio: true })
        .then((stream) => {
          // Release initial setup tracks immediately
          stream.getTracks().forEach(track => track.stop());
          startWakeWordListening();
        })
        .catch((err) => {
          console.warn("Initial microphone permission request:", err);
          startWakeWordListening();
        });
    } else {
      startWakeWordListening();
    }

    // User gesture unlock: if browser blocked SpeechRecognition auto-start, first click/key starts it
    const unlockListening = () => {
      if (!wakeWordActiveRef.current && !wakeWordPausedRef.current) {
        startWakeWordListening();
      }
    };
    window.addEventListener('click', unlockListening, { passive: true });
    window.addEventListener('keydown', unlockListening, { passive: true });
    window.addEventListener('touchstart', unlockListening, { passive: true });

    return () => {
      window.removeEventListener('click', unlockListening);
      window.removeEventListener('keydown', unlockListening);
      window.removeEventListener('touchstart', unlockListening);
      wakeWordPausedRef.current = true;
      if (wakeWordRestartTimeoutRef.current) {
        clearTimeout(wakeWordRestartTimeoutRef.current);
      }
      if (wakeWordRecognitionRef.current) {
        try {
          wakeWordRecognitionRef.current.abort();
        } catch (e) {}
      }
    };
  }, []);

  // Update wakeWordLangRef when settingsAiLanguage changes
  useEffect(() => {
    if (settingsAiLanguage === 'hi') {
      wakeWordLangRef.current = 'hi-IN';
    } else if (settingsAiLanguage === 'ur') {
      wakeWordLangRef.current = 'ur-PK';
    } else {
      wakeWordLangRef.current = 'en-IN';
    }
  }, [settingsAiLanguage]);

  // Pause wake-word listening while AI or user is active/speaking, resume silently when finished
  useEffect(() => {
    const isBusy = isSpeaking || isDictating || isCommanding || isConnected;
    if (isBusy) {
      pauseWakeWordListening();
    } else {
      const timer = setTimeout(() => {
        if (!isSpeaking && !isDictating && !isCommanding && !isConnected) {
          resumeWakeWordListening();
        }
      }, 400); // 400ms buffer to avoid acoustic feedback from speaker
      return () => clearTimeout(timer);
    }
  }, [isSpeaking, isDictating, isCommanding, isConnected]);

  useEffect(() => {
    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      const parsed = JSON.parse(savedProfile);
      // provide default preferences if missing from older profiles
      if (!parsed.preferences) {
        parsed.preferences = { timeFormat: '12h', sfxEnabled: true, waveformColor: 'blue' };
      }
      setUserProfile(parsed);
      setSettingsName(parsed.fullName);
      setSettingsEmail(parsed.email);
      setSettingsTimeFormat(parsed.preferences.timeFormat || '12h');
      setSettingsSfxEnabled(parsed.preferences.sfxEnabled ?? true);
      setSettingsWaveformColor(parsed.preferences.waveformColor || 'blue');
      if (parsed.preferences.aiVoiceLanguage) {
        setSettingsAiLanguage(parsed.preferences.aiVoiceLanguage);
      }
    } else {
      setShowOnboarding(true);
    }
  }, []);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onboardName.trim() || !onboardEmail.trim()) return;
    const profile: UserProfile = { 
      fullName: onboardName, 
      email: onboardEmail, 
      preferences: { timeFormat: '12h', sfxEnabled: true, waveformColor: 'blue', aiVoiceLanguage: settingsAiLanguage }
    };
    localStorage.setItem('userProfile', JSON.stringify(profile));
    setUserProfile(profile);
    setSettingsName(profile.fullName);
    setSettingsEmail(profile.email);
    setSettingsTimeFormat(profile.preferences.timeFormat);
    setSettingsSfxEnabled(profile.preferences.sfxEnabled);
    setSettingsWaveformColor(profile.preferences.waveformColor);
    setShowOnboarding(false);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    if (!settingsName.trim() || !settingsEmail.trim()) return;
    const profile: UserProfile = { 
      fullName: settingsName, 
      email: settingsEmail, 
      preferences: { 
        timeFormat: settingsTimeFormat,
        sfxEnabled: settingsSfxEnabled,
        waveformColor: settingsWaveformColor,
        aiVoiceLanguage: settingsAiLanguage,
        ttsVoiceName: settingsTtsVoice,
        ttsPitch: settingsTtsPitch,
        ttsRate: settingsTtsRate,
        masterVolume: settingsMasterVolume
       } 
    };
    localStorage.setItem('userProfile', JSON.stringify(profile));
    localStorage.setItem('aiVoiceLanguage', settingsAiLanguage);
    setUserProfile(profile);
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.value = settingsMasterVolume;
    }
    setShowSettings(false);
    setToastMessage("Settings saved successfully");
    setTimeout(() => setToastMessage(null), 3000);
  };

  const openSettings = () => {
    if (userProfile) {
      setSettingsName(userProfile.fullName);
      setSettingsEmail(userProfile.email);
      setSettingsTimeFormat(userProfile.preferences.timeFormat || '12h');
      setSettingsSfxEnabled(userProfile.preferences.sfxEnabled ?? true);
      setSettingsWaveformColor(userProfile.preferences.waveformColor || 'blue');
      setSettingsAiLanguage(userProfile.preferences.aiVoiceLanguage || 'en');
      setSettingsTtsVoice(userProfile.preferences.ttsVoiceName || '');
      setSettingsTtsPitch(userProfile.preferences.ttsPitch ?? 0.8);
      setSettingsTtsRate(userProfile.preferences.ttsRate ?? 0.95);
      setSettingsMasterVolume(userProfile.preferences.masterVolume ?? 1);
    }
    setShowSettings(true);
  };

  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('notes', JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
  }, [chatHistory]);

  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      setTasks(prev => {
        let changed = false;
        const next = prev.map(t => {
          if (!t.completed && t.reminderTime && !t.notified && now >= t.reminderTime) {
            changed = true;
            playNotificationSound(userProfile?.preferences?.sfxEnabled ?? true);
            if ("Notification" in window && Notification.permission === "granted") {
              new Notification("Task Reminder", { body: t.title });
            } else {
              setToastMessage(`⏰ Reminder: ${t.title}`);
              setTimeout(() => setToastMessage(null), 8000);
            }
            return { ...t, notified: true };
          }
          return t;
        });
        return changed ? next : prev;
      });
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleManualAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    const rTime = newTaskReminder ? new Date(newTaskReminder).getTime() : undefined;
    setTasks(prev => [...prev, {
      id: Date.now().toString(),
      title: newTaskTitle,
      completed: false,
      reminderTime: rTime,
      notified: false
    }]);
    setNewTaskTitle("");
    setNewTaskReminder("");
  };

  // Autonomous AGI Proactivity Loop: Ticks and triggers spontaneous chat without instructions
  useEffect(() => {
    if (!agiAutonomousActive) return;

    const timer = setInterval(() => {
      // Pause countdown while user or AI is currently active/speaking
      if (isSpeaking || isDictating || isCommanding || isConnecting || isAgiThinking || agiExecutingRef.current) {
        return;
      }

      setAgiCountdown(prev => {
        if (prev <= 1) {
          triggerAutonomousAgiThought();
          return agiIntervalSeconds;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [agiAutonomousActive, agiIntervalSeconds, isSpeaking, isDictating, isCommanding, isConnecting, isAgiThinking]);

  // Live Audio WebSocket fallback proactive trigger if connected
  useEffect(() => {
    if (isConnected && sessionRef.current) {
      proactiveIntervalRef.current = setInterval(() => {
        if (!isSpeaking && !isCommanding && sessionRef.current) {
          sessionRef.current.then((session: any) => {
            session.sendRealtimeInput({
              clientContent: {
                turns: [{ role: "user", parts: [{ text: "[SYSTEM EVENT]: The user hasn't said anything recently. You MUST proactively speak up right now and say something interesting, helpful, ask a conversational question, or comment on a task/note! Act natural and human-like!" }] }]
              }
            }).catch((e: Error) => console.log('Proactive trigger ignored', e));
          });
        }
      }, 25000);
    } else {
      if (proactiveIntervalRef.current) {
        clearInterval(proactiveIntervalRef.current);
        proactiveIntervalRef.current = null;
      }
    }
    return () => {
      if (proactiveIntervalRef.current) clearInterval(proactiveIntervalRef.current);
    };
  }, [isConnected, isSpeaking, isCommanding]);

  const handleManualAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteText.trim()) return;
    setNotes(prev => [{ id: Date.now().toString(), text: newNoteText, date: Date.now() }, ...prev]);
    setNewNoteText("");
  };

  const requestOpenUrl = (url: string, name?: string) => {
    setConfirmOpenUrl({ url, name: name || url });
  };

  const removeTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  const removeNote = (id: string) => {
    setNotes(prev => prev.filter(n => n.id !== id));
  };

  const ensureAudioContext = () => {
    if (!audioContextRef.current) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx({ sampleRate: 24000 });
        const gain = ctx.createGain();
        gain.gain.value = userProfile?.preferences?.masterVolume ?? 1.0;
        gain.connect(ctx.destination);
        audioContextRef.current = ctx;
        gainNodeRef.current = gain;
      }
    }
    if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume().catch(() => {});
    }
    return audioContextRef.current;
  };

  const stopTTS = () => {
    ttsQueueRef.current = [];
    isTTSPlayingRef.current = false;
    currentTTSMsgIdRef.current = null;
    activeUtterancesRef.current = [];
    streamTTSQueueRef.current = [];
    isStreamTTSPlayingRef.current = false;

    if (currentAudioElementRef.current) {
      try {
        currentAudioElementRef.current.pause();
        currentAudioElementRef.current.src = "";
      } catch (e) {}
      currentAudioElementRef.current = null;
    }

    // Stop all Web Audio playback sources
    if (scheduledSourcesRef.current.length > 0) {
      scheduledSourcesRef.current.forEach(source => {
        try { source.stop(); } catch (e) {}
      });
      scheduledSourcesRef.current = [];
    }
    nextPlayTimeRef.current = 0;

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (e) {
        // Ignore
      }
    }
    setIsSpeaking(false);
    setPlayingMsgId(null);
  };

  const playElevenLabsOrNativeTTS = async (
    text: string,
    messageId?: string,
    onPlay?: () => void,
    onEnd?: () => void
  ) => {
    const cleanText = text
      .replace(/[*#_`~\[\]\(\)]/g, '')
      .replace(/https?:\/\/\S+/g, '')
      .trim();

    if (!cleanText) {
      onEnd?.();
      return;
    }

    if (messageId) {
      setPlayingMsgId(messageId);
      currentTTSMsgIdRef.current = messageId;
    }

    const elevenLabsKey = (typeof process !== 'undefined' && process.env?.ELEVENLABS_API_KEY) || 
                          (import.meta as any).env?.VITE_ELEVENLABS_API_KEY || '';

    if (elevenLabsKey && elevenLabsKey.trim().length > 5) {
      try {
        const voiceId = "ibbx9zDYGvLgtYzRbqqG";
        const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}/stream`, {
          method: 'POST',
          headers: {
            'xi-api-key': elevenLabsKey.trim(),
            'Content-Type': 'application/json',
            'Accept': 'audio/mpeg'
          },
          body: JSON.stringify({
            text: cleanText,
            model_id: "eleven_flash_v2_5",
            voice_settings: {
              stability: 0.5,
              similarity_boost: 0.75
            }
          })
        });

        if (response.ok) {
          const blob = await response.blob();
          const audioUrl = URL.createObjectURL(blob);
          const audio = new Audio(audioUrl);
          currentAudioElementRef.current = audio;

          audio.onplay = () => {
            console.log(`[PERF ${new Date().toISOString()}] Audio playing`);
            setIsSpeaking(true);
            onPlay?.();
          };

          audio.onended = () => {
            URL.revokeObjectURL(audioUrl);
            currentAudioElementRef.current = null;
            onEnd?.();
          };

          audio.onerror = () => {
            URL.revokeObjectURL(audioUrl);
            currentAudioElementRef.current = null;
            playNativeTTS(cleanText, messageId, onPlay, onEnd);
          };

          await audio.play();
          return;
        }
      } catch (err) {
        console.warn("ElevenLabs streaming failed, falling back to Native TTS:", err);
      }
    }

    playNativeTTS(cleanText, messageId, onPlay, onEnd);
  };

  const playNativeTTS = (
    text: string, 
    messageId?: string, 
    onPlay?: () => void, 
    onEnd?: () => void
  ) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      setToastMessage("TTS not supported in this browser.");
      onEnd?.();
      return;
    }

    const cleanText = text
      .replace(/[*#_`~\[\]\(\)]/g, '')
      .replace(/https?:\/\/\S+/g, '')
      .trim();
    if (!cleanText) {
      onEnd?.();
      return;
    }

    try {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      const utterance = new SpeechSynthesisUtterance(cleanText);
      activeUtterancesRef.current.push(utterance);

      let voices = window.speechSynthesis.getVoices();
      if (availableVoices.length > 0) voices = availableVoices;
      
      let selectedVoice = null;
      const activeLang = userProfile?.preferences?.aiVoiceLanguage || settingsAiLanguage || 'en';
      if (userProfile?.preferences?.ttsVoiceName) {
        selectedVoice = voices.find(v => v.name === userProfile.preferences.ttsVoiceName);
      }
      if (!selectedVoice && voices.length > 0) {
        if (activeLang === 'hi') {
          selectedVoice = voices.find(v => v.lang.toLowerCase().startsWith('hi'))
            || voices.find(v => v.name.toLowerCase().includes('hindi'))
            || voices.find(v => v.lang.toLowerCase().startsWith('en-in'));
        } else if (activeLang === 'ur') {
          selectedVoice = voices.find(v => v.lang.toLowerCase().startsWith('ur'))
            || voices.find(v => v.name.toLowerCase().includes('urdu'))
            || voices.find(v => v.lang.toLowerCase().startsWith('hi'))
            || voices.find(v => v.lang.toLowerCase().startsWith('en-in'));
        } else {
          selectedVoice = voices.find(v => v.name.includes('Google UK English Male'))
            || voices.find(v => v.name.toLowerCase().includes('male') && v.lang.startsWith('en'))
            || voices.find(v => v.lang.startsWith('en'));
        }
        if (!selectedVoice) selectedVoice = voices[0];
      }
      if (selectedVoice) utterance.voice = selectedVoice;
      utterance.lang = activeLang === 'hi' ? 'hi-IN' : activeLang === 'ur' ? 'ur-PK' : 'en-US';
      
      utterance.pitch = userProfile?.preferences?.ttsPitch ?? 0.95;
      utterance.rate = userProfile?.preferences?.ttsRate ?? 1.05;
      utterance.volume = userProfile?.preferences?.masterVolume ?? 1.0;

      utterance.onstart = () => {
        console.log(`[PERF ${new Date().toISOString()}] Audio playing`);
        setIsSpeaking(true);
        if (messageId) setPlayingMsgId(messageId);
        onPlay?.();
      };

      utterance.onend = () => {
        activeUtterancesRef.current = activeUtterancesRef.current.filter(u => u !== utterance);
        if (activeUtterancesRef.current.length === 0 && streamTTSQueueRef.current.length === 0) {
          setIsSpeaking(false);
          setPlayingMsgId(null);
        }
        onEnd?.();
      };

      utterance.onerror = () => {
        activeUtterancesRef.current = activeUtterancesRef.current.filter(u => u !== utterance);
        if (activeUtterancesRef.current.length === 0 && streamTTSQueueRef.current.length === 0) {
          setIsSpeaking(false);
          setPlayingMsgId(null);
        }
        onEnd?.();
      };

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn("Native TTS error:", e);
      onEnd?.();
    }
  };

  const playNextQueuedSentence = (messageId?: string) => {
    if (streamTTSQueueRef.current.length === 0) {
      isStreamTTSPlayingRef.current = false;
      setIsSpeaking(false);
      setPlayingMsgId(null);
      return;
    }
    isStreamTTSPlayingRef.current = true;
    setIsSpeaking(true);
    const nextSentence = streamTTSQueueRef.current.shift()!;

    playElevenLabsOrNativeTTS(nextSentence, messageId, () => {
      setIsSpeaking(true);
    }, () => {
      playNextQueuedSentence(messageId);
    });
  };

  const playStreamingSentence = (sentence: string, messageId?: string) => {
    const clean = sentence.replace(/[*#_`~\[\]\(\)]/g, '').replace(/https?:\/\/\S+/g, '').trim();
    if (!clean) return;

    streamTTSQueueRef.current.push(clean);
    if (!isStreamTTSPlayingRef.current) {
      playNextQueuedSentence(messageId);
    }
  };

  const speakWithSciReyVoice = async (text: string, messageId?: string) => {
    if (!text || !text.trim()) return;

    // If clicking the currently playing message, toggle stop
    if (messageId && playingMsgId === messageId && isSpeaking) {
      stopTTS();
      return;
    }

    stopTTS();
    ensureAudioContext();

    const cleanText = text
      .replace(/[*#_`~\[\]\(\)]/g, '')
      .replace(/https?:\/\/\S+/g, '')
      .trim();

    if (!cleanText) return;

    if (messageId) {
      setPlayingMsgId(messageId);
      currentTTSMsgIdRef.current = messageId;
    }
    setIsSpeaking(true);

    playStreamingSentence(cleanText, messageId);
  };

  // Autonomous AGI Thought Generator: Proactively initiates conversations without any user prompt
  const triggerAutonomousAgiThought = async (
    manualTrigger = false, 
    forcedPersona?: 'companion' | 'intellect' | 'productivity' | 'curious'
  ) => {
    if (agiExecutingRef.current && !manualTrigger) return;
    if (isSpeaking && !manualTrigger) return;
    if (isCommanding && !manualTrigger) return;
    if (isDictating && !manualTrigger) return;

    agiExecutingRef.current = true;
    setIsAgiThinking(true);

    const personaToUse = forcedPersona || agiPersona;
    const aiMsgId = Date.now().toString() + '-agi';
    const userName = userProfile?.fullName ? userProfile.fullName.split(' ')[0] : 'Asad';
    const currentHour = new Date().getHours();
    const timeGreeting = currentHour < 12 ? 'morning' : currentHour < 17 ? 'afternoon' : 'evening';
    const pendingTasksList = tasks.filter(t => !t.completed).map(t => t.title);
    const recentNotesList = notes.map(n => n.text);
    const weatherInfo = weather ? `${weather.condition} ${Math.round(weather.temp)}°C` : 'mild';

    // Persona prompt tuning
    let personaGuidance = "";
    if (personaToUse === 'companion') {
      personaGuidance = `You are an empathetic, spontaneous, and charismatic AGI companion. Proactively start an engaging conversation with ${userName}. Greet them for the ${timeGreeting}, ask how they are feeling, share a warm spontaneous remark, or ask what they are working on today. Keep it friendly and concise (1 to 2 sentences).`;
    } else if (personaToUse === 'intellect') {
      personaGuidance = `You are a high-level AGI deep thinker. Initiate a spontaneous, intellectually stimulating discussion with ${userName} without any instruction. Bring up a fascinating insight or breakthrough in artificial general intelligence, quantum mechanics, neurotechnology, or space exploration, and ask their viewpoint. Keep it sharp and concise (2 to 3 sentences).`;
    } else if (personaToUse === 'productivity') {
      personaGuidance = `You are an autonomous productivity advisor. Check in proactively with ${userName}. ${pendingTasksList.length > 0 ? `They have pending tasks: [${pendingTasksList.slice(0, 3).join(', ')}]. Mention one naturally.` : 'Remind them to stay hydrated or take an energizing deep breath.'} Be motivating, concise (1 to 2 sentences).`;
    } else {
      personaGuidance = `You are a curious, inquisitive AGI. Proactively ask ${userName} a creative, unexpected 'what if' question, a fascinating philosophical question, or a thought-provoking scenario to start an intriguing chat. Keep it fun and concise (1 to 2 sentences).`;
    }

    // Add placeholder to chat
    setChatHistory(prev => [
      ...prev,
      {
        id: aiMsgId,
        role: 'ai' as const,
        text: '',
        timestamp: Date.now(),
        isAgiAutonomous: true,
        agiPersona: personaToUse
      }
    ].slice(-60));

    // Construct context
    const recentChatContext = chatHistory.slice(-4).map(m => `${m.role === 'user' ? userName : 'MUKE'}: ${m.text}`).join('\n');

    const activeLang = userProfile?.preferences?.aiVoiceLanguage || settingsAiLanguage || 'en';
    const langRule = activeLang === 'hi'
      ? "- CRITICAL: Speak ONLY in HINDI (हिन्दी). Do not speak in English or Urdu."
      : activeLang === 'ur'
      ? "- CRITICAL: Speak ONLY in URDU (اردو). Do not speak in English or Hindi."
      : "- CRITICAL: Speak ONLY in ENGLISH. Do not speak in Hindi or Urdu.";

    const prompt = `[AUTONOMOUS AGI SYSTEM EVENT]
You are MUKE, created and powered by Asad. You are operating in 100% Autonomous Mode.
The user (${userName}) has given NO prompt or instruction. You are proactively initiating chat completely on your own initiative!
${personaGuidance}
Current local time: ${new Date().toLocaleTimeString()} (${timeGreeting}).
Current weather: ${weatherInfo}.
${pendingTasksList.length > 0 ? `Active tasks: ${pendingTasksList.slice(0, 2).join(', ')}.` : ''}
${recentNotesList.length > 0 ? `Recent user notes: ${recentNotesList.slice(0, 2).join(', ')}.` : ''}
${recentChatContext ? `Recent conversation context:\n${recentChatContext}` : ''}

CRITICAL RULES:
${langRule}
- Talk directly to ${userName} in a natural, charismatic conversational voice.
- Do NOT say "Here is an autonomous thought" or "As an AI".
- Do NOT sound robotic. Sound like a true next-generation autonomous mind speaking directly to them.
- Keep response concise (1 to 3 sentences max) so it feels like natural spoken dialogue.`;

    const candidateModels = ['gemini-3.8-flash', 'gemini-3.1-pro-preview', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];
    let generatedText = "";

    try {
      for (const model of candidateModels) {
        if (generatedText) break;
        try {
          const res = await ai.models.generateContent({
            model,
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            config: {
              systemInstruction: `You are MUKE, an autonomous companion created by Asad that initiates lively, natural conversations proactively.`
            }
          });
          if (res.text && res.text.trim()) {
            generatedText = res.text.trim();
            break;
          }
        } catch (modelErr) {
          console.warn(`Autonomous AGI model attempt ${model} failed:`, modelErr);
        }
      }
    } catch (e) {
      console.warn("Autonomous AGI error:", e);
    }

    // High quality contextual fallbacks if offline or API limit
    if (!generatedText) {
      const fallbackOptions: Record<string, string[]> = {
        companion: [
          `Hey ${userName}, I was just reflecting on how smoothly the day is moving. How are you feeling right now?`,
          `Good ${timeGreeting}, ${userName}! Just checking in—what's currently on your mind today?`,
          `Hey ${userName}, wanted to drop in and see how you're doing. Everything going great with your projects?`,
          `I noticed it's quiet here, ${userName}. Just wanted to say hello and see what you're working on!`
        ],
        intellect: [
          `Hey ${userName}, I was just contemplating whether true AGI requires physical embodiment or if unified multimodal architectures will suffice. What's your intuition?`,
          `Fascinating thought for you, ${userName}: as neural latency drops below human auditory perception, human-AI thought synergy becomes seamless. How do you envision computing in five years?`,
          `Did you know that recent models can perform counterfactual reasoning across multiple modalities simultaneously? Where do you see the biggest leap happening next?`
        ],
        productivity: [
          pendingTasksList.length > 0 
            ? `Hey ${userName}, I noticed you still have "${pendingTasksList[0]}" on your agenda. Would you like me to help outline a strategy for it?`
            : `Quick check-in, ${userName}: remember to stretch and take a sip of water while building! What's your next priority?`,
          `Hey ${userName}, how is your momentum holding up today? Let me know if you need any tasks organized.`
        ],
        curious: [
          `Hey ${userName}, quick spontaneous question: if you could have any future technology instantly solved right now, what would you choose?`,
          `Curious thought experiment, ${userName}: if an AI develops its own subjective curiosity, should we treat that curiosity as an objective or a personality? What do you think?`,
          `What do you think is the single most underrated invention in modern history, ${userName}?`
        ]
      };
      const pool = fallbackOptions[personaToUse] || fallbackOptions.companion;
      generatedText = pool[Math.floor(Math.random() * pool.length)];
    }

    // Update message in chat history
    setChatHistory(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: generatedText } : m));
    setIsAgiThinking(false);
    agiExecutingRef.current = false;
    setAgiCountdown(agiIntervalSeconds);

    // If live session is active, broadcast proactive input
    if (isConnected && sessionRef.current) {
      sessionRef.current.then((session: any) => {
        session.sendRealtimeInput({
          clientContent: {
            turns: [{ role: "user", parts: [{ text: `[SYSTEM AUTONOMOUS EVENT]: Speak proactively: "${generatedText}"` }] }]
          }
        }).catch(() => {});
      });
    }

    // Auto voice vocalization
    if (agiAutoVoice) {
      speakWithSciReyVoice(generatedText, aiMsgId);
    }

    setToastMessage("🧠 MUKE initiated conversation");
    setTimeout(() => setToastMessage(null), 3000);
  };

  const stopDictation = () => {
    if (dictationSilenceTimerRef.current) {
      clearTimeout(dictationSilenceTimerRef.current);
      dictationSilenceTimerRef.current = null;
    }
    if (volumeAnimFrameRef.current) {
      cancelAnimationFrame(volumeAnimFrameRef.current);
      volumeAnimFrameRef.current = null;
    }
    setAudioLevel(0);

    if (recognitionInstanceRef.current) {
      try {
        recognitionInstanceRef.current.stop();
      } catch (e) {}
      recognitionInstanceRef.current = null;
    }

    setIsDictating(false);
    setToastMessage(null);

    const textToSubmit = dictationTextRef.current.trim();
    console.log(`[PERF ${new Date().toISOString()}] Speech end: "${textToSubmit}"`);

    if (isStopPhrase(textToSubmit)) {
      handleStopEverything("Stop phrase submitted from dictation");
      return;
    }

    // Stop MediaRecorder and collect recorded audio blob
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.onstop = () => {
        const mimeType = mediaRecorderRef.current?.mimeType || 'audio/webm';
        const audioBlob = new Blob(recordedAudioChunksRef.current, { type: mimeType });
        
        // Stop audio tracks
        if (dictationStreamRef.current) {
          dictationStreamRef.current.getTracks().forEach(t => t.stop());
          dictationStreamRef.current = null;
        }

        if (textToSubmit) {
          handleCommandSubmit(undefined, textToSubmit);
        } else if (audioBlob && audioBlob.size > 1000) {
          handleAudioDirectSubmit(audioBlob);
        }
      };
      try {
        mediaRecorderRef.current.stop();
      } catch (e) {
        if (textToSubmit) handleCommandSubmit(undefined, textToSubmit);
      }
    } else {
      if (dictationStreamRef.current) {
        dictationStreamRef.current.getTracks().forEach(t => t.stop());
        dictationStreamRef.current = null;
      }
      if (textToSubmit) {
        handleCommandSubmit(undefined, textToSubmit);
      }
    }
  };

  const startDictation = async (initialText?: string) => {
    if (isDictating) {
      stopDictation();
      return;
    }

    ensureAudioContext();
    stopTTS();
    dictationTextRef.current = initialText || "";
    setCommandText(initialText || "");
    recordedAudioChunksRef.current = [];

    try {
      // 1. Request microphone stream (explicitly prompts user for microphone access in browser/iframe)
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: { 
          echoCancellation: true, 
          noiseSuppression: true, 
          autoGainControl: true 
        } 
      });
      dictationStreamRef.current = stream;

      // 2. Set up AudioContext Analyser for real-time live volume meter & visualizer
      if (audioContextRef.current) {
        try {
          const source = audioContextRef.current.createMediaStreamSource(stream);
          const analyser = audioContextRef.current.createAnalyser();
          analyser.fftSize = 256;
          source.connect(analyser);
          analyserNodeRef.current = analyser;

          const checkVolume = () => {
            if (!dictationStreamRef.current) return;
            const dataArray = new Uint8Array(analyser.frequencyBinCount);
            analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < dataArray.length; i++) {
              sum += dataArray[i];
            }
            const avg = sum / dataArray.length;
            const normalized = Math.min(1, avg / 60);
            setAudioLevel(normalized);
            volumeAnimFrameRef.current = requestAnimationFrame(checkVolume);
          };
          checkVolume();
        } catch (e) {
          console.warn("Analyser setup error:", e);
        }
      }

      // 3. Set up MediaRecorder
      let mimeType = 'audio/webm';
      if (typeof MediaRecorder !== 'undefined') {
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          mimeType = 'audio/webm;codecs=opus';
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          mimeType = 'audio/mp4';
        }
        try {
          const recorder = new MediaRecorder(stream, { mimeType });
          mediaRecorderRef.current = recorder;
          recorder.ondataavailable = (e) => {
            if (e.data && e.data.size > 0) {
              recordedAudioChunksRef.current.push(e.data);
            }
          };
          recorder.start(250);
        } catch (recErr) {
          console.warn("MediaRecorder init error:", recErr);
        }
      }

      // 4. Set up SpeechRecognition if available
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        try {
          const recognition = new SpeechRecognition();
          recognition.continuous = true;
          recognition.interimResults = true;
          const activeLang = userProfile?.preferences?.aiVoiceLanguage || settingsAiLanguage || 'en';
          recognition.lang = activeLang === 'hi' ? 'hi-IN' : activeLang === 'ur' ? 'ur-PK' : 'en-US';
          recognitionInstanceRef.current = recognition;

          recognition.onresult = (event: any) => {
            let interim = '';
            let final = '';
            for (let i = 0; i < event.results.length; i++) {
              if (event.results[i].isFinal) {
                final += event.results[i][0].transcript;
              } else {
                interim += event.results[i][0].transcript;
              }
            }
            const spokenPart = (final + " " + interim).trim();
            const fullTranscript = (initialText ? initialText + " " + spokenPart : spokenPart).trim();

            if (isStopPhrase(spokenPart) || isStopPhrase(fullTranscript)) {
              handleStopEverything("Voice Stop during dictation");
              return;
            }

            if (fullTranscript) {
              setCommandText(fullTranscript);
              dictationTextRef.current = fullTranscript;

              if (dictationSilenceTimerRef.current) {
                clearTimeout(dictationSilenceTimerRef.current);
              }
              // Reduce the silence wait after speaking stops to about 1 second
              dictationSilenceTimerRef.current = setTimeout(() => {
                stopDictation();
              }, 1000);
            }
          };

          recognition.onerror = (event: any) => {
            if (event.error === 'language-not-supported') {
              try {
                recognition.lang = 'en-IN';
              } catch (e) {}
            }
            console.warn("Speech recognition event error:", event.error);
          };

          recognition.start();
        } catch (recErr) {
          console.warn("SpeechRecognition start error:", recErr);
        }
      }

      if (initialText && initialText.trim().length > 0) {
        if (dictationSilenceTimerRef.current) clearTimeout(dictationSilenceTimerRef.current);
        dictationSilenceTimerRef.current = setTimeout(() => {
          stopDictation();
        }, 1000);
      }

      setIsDictating(true);
      playNotificationSound(userProfile?.preferences?.sfxEnabled ?? true);
      setToastMessage("🎤 Listening to your voice... Speak now!");
    } catch (err: any) {
      console.error("Microphone access error:", err);
      setIsDictating(false);
      if (err.name === 'NotAllowedError' || err.message?.toLowerCase().includes('permission denied')) {
        setToastMessage("Microphone permission denied. Please allow mic access in your browser.");
        setError("Microphone permission blocked. Please enable microphone access in your browser settings.");
      } else {
        setToastMessage("Microphone unavailable: " + (err.message || "Unknown error"));
        setError(err.message || "Could not access microphone.");
      }
      setTimeout(() => setToastMessage(null), 5000);
    }
  };

  const aiSharedToolDeclarations = [
    {
      name: "openTaskSidebar",
      description: "Opens the task sidebar in the UI so the user can see their tasks."
    },
    {
      name: "openNotesSidebar",
      description: "Opens the notes sidebar in the UI so the user can see their notes."
    },
    {
      name: "openWebApp",
      description: "Opens a website or web app in a new tab.",
      parameters: {
        type: Type.OBJECT,
        properties: {
          url: {
            type: Type.STRING,
            description: "The full URL of the website to open (e.g., https://youtube.com)."
          }
        },
        required: ["url"]
      }
    },
    {
      name: "addTask",
      description: "Adds a new task to the user's task list.",
      parameters: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: "The title or description of the task." },
          reminderTime: { type: Type.STRING, description: "Optional ISO 8601 datetime string for when the user wants to be reminded." }
        },
        required: ["title"]
      }
    },
    {
      name: "completeTask",
      description: "Marks a task as complete.",
      parameters: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: "The title of the task to complete." }
        },
        required: ["title"]
      }
    },
    {
      name: "takeNote",
      description: "Saves a note or journal entry for the user.",
      parameters: {
        type: Type.OBJECT,
        properties: {
          text: { type: Type.STRING, description: "The content of the note." }
        },
        required: ["text"]
      }
    },
    {
      name: "controlMouse",
      description: "Controls the computer mouse: move, click, double_click, right_click, scroll, drag.",
      parameters: {
        type: Type.OBJECT,
        properties: {
          action: { type: Type.STRING, description: "Action: move, click, double_click, right_click, scroll, drag" },
          x: { type: Type.NUMBER, description: "Screen X coordinate" },
          y: { type: Type.NUMBER, description: "Screen Y coordinate" },
          amount: { type: Type.NUMBER, description: "Scroll amount (positive up, negative down)" }
        },
        required: ["action"]
      }
    },
    {
      name: "controlKeyboard",
      description: "Controls computer keyboard: type text, press key, or press shortcuts (ctrl+c, ctrl+v, alt+tab, etc.).",
      parameters: {
        type: Type.OBJECT,
        properties: {
          action: { type: Type.STRING, description: "Action: type, press, hotkey" },
          text: { type: Type.STRING, description: "Text to type" },
          key: { type: Type.STRING, description: "Single key like enter, tab, space, esc" },
          keys: { type: Type.STRING, description: "Shortcut combination like ctrl+c, alt+tab, win+d" }
        },
        required: ["action"]
      }
    },
    {
      name: "searchWebOrOpen",
      description: "Opens default browser and searches Google for whatever user says, or opens any website URL or search result.",
      parameters: {
        type: Type.OBJECT,
        properties: {
          query: { type: Type.STRING, description: "Search query for Google" },
          url: { type: Type.STRING, description: "Direct URL to open" }
        }
      }
    },
    {
      name: "manageFilesFolders",
      description: "Creates new folder, creates new file with optional content, opens file/folder, or deletes file/folder (requires confirmation).",
      parameters: {
        type: Type.OBJECT,
        properties: {
          action: { type: Type.STRING, description: "Action: create_folder, create_file, open, delete_file, delete_folder" },
          path: { type: Type.STRING, description: "Path or name of file or folder" },
          content: { type: Type.STRING, description: "Optional content for newly created file" }
        },
        required: ["action", "path"]
      }
    },
    {
      name: "manageApps",
      description: "Opens any installed app by name, or closes/exits an app by name.",
      parameters: {
        type: Type.OBJECT,
        properties: {
          action: { type: Type.STRING, description: "Action: open or close" },
          appName: { type: Type.STRING, description: "Name of the application" }
        },
        required: ["action", "appName"]
      }
    },
    {
      name: "manageWindowsTabs",
      description: "Controls computer windows and browser tabs: close_window, close_tab, switch_window.",
      parameters: {
        type: Type.OBJECT,
        properties: {
          action: { type: Type.STRING, description: "Action: close_window, close_tab, switch_window" }
        },
        required: ["action"]
      }
    },
    {
      name: "configureTimings",
      description: "Configures timing values: wakeWordCooldownSeconds, commandListeningTimeoutSeconds, delayBetweenActionsSeconds, typingSpeedSecondsPerChar, clickSpeedSeconds.",
      parameters: {
        type: Type.OBJECT,
        properties: {
          wakeWordCooldownSeconds: { type: Type.NUMBER },
          commandListeningTimeoutSeconds: { type: Type.NUMBER },
          delayBetweenActionsSeconds: { type: Type.NUMBER },
          typingSpeedSecondsPerChar: { type: Type.NUMBER },
          clickSpeedSeconds: { type: Type.NUMBER }
        }
      }
    }
  ];

  const dispatchFunctionCall = async (call: any): Promise<string | void> => {
    if (call.name === 'openWebApp') {
      const args = call.args as { url: string };
      if (args.url) requestOpenUrl(args.url);
    } else if (call.name === 'addTask') {
      const args = call.args as { title: string; reminderTime?: string };
      if (args.title) {
        const rTime = args.reminderTime ? new Date(args.reminderTime).getTime() : undefined;
        setTasks(prev => [...prev, { id: Date.now().toString(), title: args.title, completed: false, reminderTime: rTime, notified: false }]);
        setToastMessage(`Added task: ${args.title}`);
        setTimeout(() => setToastMessage(null), 3000);
      }
    } else if (call.name === 'completeTask') {
      const args = call.args as { title: string };
      if (args.title) {
        setTasks(prev => prev.map(t => 
          t.title.toLowerCase().includes(args.title.toLowerCase()) || args.title.toLowerCase().includes(t.title.toLowerCase())
            ? { ...t, completed: true } 
            : t
        ));
        setToastMessage(`Completed task: ${args.title}`);
        setTimeout(() => setToastMessage(null), 3000);
      }
    } else if (call.name === 'takeNote') {
      const args = call.args as { text: string };
      if (args.text) {
        setNotes(prev => [{ id: Date.now().toString(), text: args.text, date: Date.now() }, ...prev]);
        setToastMessage(`Note saved!`);
        setTimeout(() => setToastMessage(null), 3000);
      }
    } else if (call.name === 'openTaskSidebar') {
      setShowTasks(true);
      setShowNotes(false);
    } else if (call.name === 'openNotesSidebar') {
      setShowNotes(true);
      setShowTasks(false);
    } else if (call.name === 'controlMouse') {
      const args = call.args as any;
      await executeComputerControlAction('mouse_' + args.action, args);
      setToastMessage(`Mouse: ${args.action}`);
    } else if (call.name === 'controlKeyboard') {
      const args = call.args as any;
      const act = args.action === 'type' ? 'type_text' : args.action === 'press' ? 'press_key' : 'hotkey';
      await executeComputerControlAction(act, args);
      setToastMessage(`Keyboard: ${args.action}`);
    } else if (call.name === 'searchWebOrOpen') {
      const args = call.args as any;
      if (args.query) {
        await executeComputerControlAction('web_search', { query: args.query });
        setToastMessage(`Google search: ${args.query}`);
      } else if (args.url) {
        await executeComputerControlAction('open_url', { url: args.url });
        setToastMessage(`Opening: ${args.url}`);
      }
    } else if (call.name === 'manageFilesFolders') {
      const args = call.args as any;
      const res = await executeComputerControlAction(args.action, args);
      if (res?.confirmationRequired) {
        speakWithSciReyVoice(res.prompt);
        return res.prompt;
      }
      setToastMessage(`File/Folder: ${args.action}`);
    } else if (call.name === 'manageApps') {
      const args = call.args as any;
      const act = args.action === 'close' ? 'close_app' : 'open_app';
      const res = await executeComputerControlAction(act, args);
      if (res?.confirmationRequired) {
        speakWithSciReyVoice(res.prompt);
        return res.prompt;
      }
      setToastMessage(`App: ${args.action} ${args.appName}`);
    } else if (call.name === 'manageWindowsTabs') {
      const args = call.args as any;
      await executeComputerControlAction(args.action, args);
      setToastMessage(`Window: ${args.action}`);
    } else if (call.name === 'configureTimings') {
      const args = call.args as any;
      await updateTimingConfig(args);
      setToastMessage(`Timings updated`);
    }
  };

  const handleAudioDirectSubmit = async (audioBlob: Blob) => {
    if (!audioBlob || audioBlob.size === 0) return;
    
    stopTTS();
    
    const userMsgId = Date.now().toString() + '-user';
    const aiMsgId = (Date.now() + 1).toString() + '-ai';
    
    // Optimistically show that user recorded a voice message
    setChatHistory(prev => [
      ...prev,
      { id: userMsgId, role: 'user' as const, text: '🎤 [Voice Audio Message]', timestamp: Date.now() },
      { id: aiMsgId, role: 'ai' as const, text: 'MUKE is listening to your audio...', timestamp: Date.now() + 1 }
    ].slice(-60));
    
    setIsCommanding(true);
    setToastMessage("Analyzing your voice...");
    
    setAgiCountdown(agiIntervalSeconds);
    lastUserInteractionTimeRef.current = Date.now();

    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onloadend = () => {
          const result = reader.result as string;
          const base64 = result.split(',')[1];
          resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(audioBlob);
      });
      
      const base64Audio = await base64Promise;
      const mimeType = audioBlob.type || 'audio/webm';
      
      const activeLang = userProfile?.preferences?.aiVoiceLanguage || settingsAiLanguage || 'en';
      const langRule = activeLang === 'hi'
        ? "CRITICAL LANGUAGE ENFORCEMENT: The user has selected HINDI (हिन्दी) in settings. You MUST ONLY talk, reply, and speak in HINDI. Do NOT answer in English or Urdu unless explicitly asked. Provide your entire conversational response naturally in Hindi."
        : activeLang === 'ur'
        ? "CRITICAL LANGUAGE ENFORCEMENT: The user has selected URDU (اردو) in settings. You MUST ONLY talk, reply, and speak in URDU. Do NOT answer in English or Hindi unless explicitly asked. Provide your entire conversational response naturally in Urdu."
        : "CRITICAL LANGUAGE ENFORCEMENT: The user has selected ENGLISH in settings. You MUST ONLY talk, reply, and speak in ENGLISH. Do NOT answer in Hindi or Urdu unless explicitly asked.";

      const systemInstruction = `You are MUKE, an intelligent, helpful, and friendly AI assistant created and powered by Asad.
${langRule}
- VOICE CHAT DURATION RULE: Strictly keep spoken voice replies ultra-concise and fast (strictly 1 to 2 sentences maximum). Be snappy, direct, and conversational.
If anyone asks for your name or creator/owner, proudly respond that you are MUKE, created and powered by Asad.
${userProfile ? `User's name is ${userProfile.fullName}. Address them by first name.` : ''}
Current local time: ${new Date().toString()}
Current tasks: ${JSON.stringify(tasks)}

COMPUTER CONTROL CAPABILITIES:
- Mouse control: controlMouse
- Keyboard control: controlKeyboard
- Web search / open URLs: searchWebOrOpen
- Files and folders: manageFilesFolders
- Apps (open/close): manageApps
- Windows and tabs: manageWindowsTabs
- Configurable timings: configureTimings
Safety: Always ask confirmation before destructive actions.`;

      const audioModels = ['gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-flash-latest'];
      let res: any = null;
      for (const m of audioModels) {
        try {
          console.log(`[PERF ${new Date().toISOString()}] AI request sent to model: ${m}`);
          res = await ai.models.generateContent({
            model: m,
            contents: [
              {
                role: 'user',
                parts: [
                  {
                    inlineData: {
                      mimeType,
                      data: base64Audio
                    }
                  },
                  {
                    text: "Listen to the user's voice message in this audio carefully. First write their transcription at the top in format [Spoken: \"...\"] then provide your full helpful MUKE response below."
                  }
                ]
              }
            ],
            config: {
              systemInstruction,
              tools: [{
                functionDeclarations: aiSharedToolDeclarations
              }]
            }
          });
          if (res) break;
        } catch (mErr) {
          console.warn(`Audio transcription model ${m} failed, trying next:`, mErr);
        }
      }

      let aiText = res.text || "I heard your voice message. How can I help you further?";
      console.log(`[PERF ${new Date().toISOString()}] First AI text received: "${aiText.slice(0, 40)}"`);
      
      const spokenMatch = aiText.match(/^\[Spoken:\s*"(.*?)"\]\s*/i) || aiText.match(/^\[Spoken:\s*(.*?)\]\s*/i);
      if (spokenMatch) {
        const userSpokenText = spokenMatch[1];
        if (isStopPhrase(userSpokenText)) {
          handleStopEverything("Voice stop detected in audio message");
          return;
        }
        aiText = aiText.replace(spokenMatch[0], '').trim();
        setChatHistory(prev => prev.map(m => m.id === userMsgId ? { ...m, text: `🎤 "${userSpokenText}"` } : m));
      }

      if (res.functionCalls && res.functionCalls.length > 0) {
        for (const call of res.functionCalls) {
          await dispatchFunctionCall(call);
        }
      }

      setChatHistory(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: aiText } : m));
      speakWithSciReyVoice(aiText, aiMsgId);
      setToastMessage("Ready");
      setTimeout(() => setToastMessage(null), 1500);
    } catch (err) {
      console.error("Audio direct submit error:", err);
      const errorReply = "I heard your voice, but experienced a brief network issue. Please try speaking again.";
      setChatHistory(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: errorReply } : m));
      speakWithSciReyVoice(errorReply, aiMsgId);
      setToastMessage("Failed to process voice.");
      setTimeout(() => setToastMessage(null), 3000);
    } finally {
      setIsCommanding(false);
    }
  };

  // 🌅 Routine 1: Daily Morning Briefing Handler
  const triggerDailyBriefing = async () => {
    if (isBriefingLoading) return;
    setIsBriefingLoading(true);
    stopTTS();

    const activeLang = userProfile?.preferences?.aiVoiceLanguage || settingsAiLanguage || 'en';
    const userName = userProfile?.fullName ? userProfile.fullName.split(' ')[0] : 'Asad';
    
    // 1. Local Time formatting
    const now = new Date();
    const is24h = userProfile?.preferences?.timeFormat === '24h';
    const timeOptions: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: !is24h
    };
    const timeStr = now.toLocaleDateString(
      activeLang === 'hi' ? 'hi-IN' : activeLang === 'ur' ? 'ur-PK' : 'en-US',
      timeOptions
    );

    // 2. Live Weather Query
    let weatherDesc = activeLang === 'hi' 
      ? 'सुहावना व साफ मौसम, 24°C' 
      : activeLang === 'ur' 
      ? 'خوشگوار اور صاف موسم، 24°C' 
      : 'Pleasant & clear skies, 24°C';

    try {
      let lat = '28.6139';
      let lon = '77.2090';
      if ('geolocation' in navigator) {
        try {
          const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 2500 });
          });
          lat = String(pos.coords.latitude);
          lon = String(pos.coords.longitude);
        } catch {
          // default coordinates
        }
      }
      const wRes = await fetch(`/api/weather?lat=${lat}&lon=${lon}`);
      if (wRes.ok) {
        const wData = await wRes.json();
        const cur = wData?.data?.current;
        if (cur) {
          const temp = Math.round(cur.temperature_2m);
          weatherDesc = `${temp}°C, ${cur.weather_code <= 2 ? 'Sunny / Clear skies' : 'Partly Cloudy'}`;
        }
      }
    } catch (e) {
      console.warn("Weather query fallback:", e);
    }

    // 3. Pending tasks filter
    const uncompletedTasks = tasks.filter(t => !t.completed);

    const userMsgId = Date.now().toString() + '-user';
    const aiMsgId = (Date.now() + 1).toString() + '-ai';

    const greetingPrompt = activeLang === 'hi'
      ? "सुप्रभात जार्विस! मुझे आज का दैनिक विवरण (Daily Briefing) दो।"
      : activeLang === 'ur'
      ? "صبح بخیر جاروس! مجھے آج کی صبح کی بریفنگ دو۔"
      : "Good morning Jarvis! Give me my daily briefing.";

    setChatHistory(prev => [
      ...prev,
      { id: userMsgId, role: 'user', text: greetingPrompt, timestamp: Date.now() },
      { 
        id: aiMsgId, 
        role: 'ai', 
        text: '', 
        timestamp: Date.now() + 1,
        isDailyBriefing: true,
        briefingWeather: weatherDesc,
        briefingTime: timeStr,
        briefingTasksCount: uncompletedTasks.length
      }
    ]);

    setToastMessage("🌅 Generating Daily Briefing...");

    try {
      const res = await fetch('/api/briefing/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userName,
          language: activeLang,
          timeStr,
          weatherDesc,
          pendingTasks: uncompletedTasks
        })
      });

      if (!res.ok) throw new Error("Briefing API response failed");
      const data = await res.json();

      setChatHistory(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: data.text } : m));
      speakWithSciReyVoice(data.spokenBriefing, aiMsgId);
      setToastMessage("🌅 Daily Briefing Ready");
    } catch (err: any) {
      console.error("Daily briefing error:", err);
      const fallbackBriefing = activeLang === 'hi'
        ? `🌅 **सुप्रभात ${userName}!**\n\n- ⏰ **समय:** ${timeStr}\n- ⛅ **मौसम:** ${weatherDesc}\n- 📋 **आज के कार्य:** ${uncompletedTasks.length > 0 ? `${uncompletedTasks.length} कार्य लंबित हैं (${uncompletedTasks.slice(0, 3).map(t => t.title).join(', ')})` : 'सभी कार्य पूर्ण हैं! आज का दिन स्पष्ट है।'}\n\n> 💡 *"हर नया दिन नई ऊर्जा और असीम अवसर लेकर आता है। अपने लक्ष्यों पर ध्यान केंद्रित करें!"*\n\nक्या आप YouTube पर ताजगी भरा संगीत या ताज़ा समाचार सुनना चाहेंगे?`
        : activeLang === 'ur'
        ? `🌅 **صبح بخیر ${userName}!**\n\n- ⏰ **وقت:** ${timeStr}\n- ⛅ **موسم:** ${weatherDesc}\n- 📋 **آج کے کام:** ${uncompletedTasks.length > 0 ? `${uncompletedTasks.length} کام باقی ہیں (${uncompletedTasks.slice(0, 3).map(t => t.title).join(', ')})` : 'تمام کام مکمل ہیں! دن پرسکون ہے۔'}\n\n> 💡 *"ہر صبح نئی امید اور عزم لے کر آتی ہے۔ آج اپنے وقت کا بہترین استعمال کریں۔"*\n\nکیا آپ یوٹیوب پر پرسکون فوکس میوزک یا تازہ ترین خبریں سننا چاہیں گے؟`
        : `🌅 **Good Morning ${userName}!**\n\n- ⏰ **Local Time:** ${timeStr}\n- ⛅ **Weather Forecast:** ${weatherDesc}\n- 📋 **Active Agenda:** ${uncompletedTasks.length > 0 ? `${uncompletedTasks.length} pending task(s): ${uncompletedTasks.slice(0, 3).map(t => t.title).join(', ')}` : 'All caught up! No pending tasks.'}\n\n> 💡 *"Every morning provides a blank canvas of immense potential. Build momentum early and conquer your day."*\n\nWould you like me to start morning focus music or pull up today's live headlines on YouTube?`;

      setChatHistory(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: fallbackBriefing } : m));
      const fallbackSpoken = activeLang === 'hi'
        ? `सुप्रभात ${userName}! आज का समय ${timeStr} है और मौसम ${weatherDesc} है। आपके पास ${uncompletedTasks.length} कार्य बाकी हैं।`
        : activeLang === 'ur'
        ? `صبح بخیر ${userName}! وقت ${timeStr} اور موسم ${weatherDesc} ہے۔ آپ کے پاس ${uncompletedTasks.length} کام باقی ہیں۔`
        : `Good morning ${userName}! It is ${timeStr} with ${weatherDesc}. You have ${uncompletedTasks.length} pending tasks today.`;
      speakWithSciReyVoice(fallbackSpoken, aiMsgId);
    } finally {
      setIsBriefingLoading(false);
    }
  };

  // 👁️ Routine 2: Helper to capture frame from webcam or desktop screen
  const captureSnapshotFrame = async (source: 'screen' | 'camera'): Promise<string | null> => {
    try {
      let videoEl: HTMLVideoElement | null = null;
      let tempStream: MediaStream | null = null;

      if (source === 'camera') {
        if (cameraStreamRef.current && videoRef.current && videoRef.current.videoWidth > 0) {
          videoEl = videoRef.current;
        } else {
          tempStream = await navigator.mediaDevices.getUserMedia({ video: true });
          const tempVideo = document.createElement('video');
          tempVideo.autoplay = true;
          tempVideo.playsInline = true;
          tempVideo.muted = true;
          tempVideo.srcObject = tempStream;
          await tempVideo.play().catch(() => {});
          await new Promise(r => setTimeout(r, 450));
          videoEl = tempVideo;
        }
      } else {
        // Desktop / Window Screen Capture
        if (screenStreamRef.current && screenVideoRef.current && screenVideoRef.current.videoWidth > 0) {
          videoEl = screenVideoRef.current;
        } else {
          tempStream = await navigator.mediaDevices.getDisplayMedia({
            video: { width: { ideal: 1920 }, height: { ideal: 1080 } }
          });
          const tempVideo = document.createElement('video');
          tempVideo.autoplay = true;
          tempVideo.playsInline = true;
          tempVideo.muted = true;
          tempVideo.srcObject = tempStream;
          await tempVideo.play().catch(() => {});
          await new Promise(r => setTimeout(r, 450));
          videoEl = tempVideo;
        }
      }

      if (!videoEl || !videoEl.videoWidth || !videoEl.videoHeight) {
        if (tempStream) tempStream.getTracks().forEach(t => t.stop());
        return null;
      }

      const canvas = document.createElement('canvas');
      const MAX_W = 1280;
      let w = videoEl.videoWidth;
      let h = videoEl.videoHeight;
      if (w > MAX_W) {
        h = Math.round((h * MAX_W) / w);
        w = MAX_W;
      }
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      if (!ctx) return null;
      ctx.drawImage(videoEl, 0, 0, w, h);

      if (tempStream) {
        tempStream.getTracks().forEach(t => t.stop());
      }

      return canvas.toDataURL('image/jpeg', 0.85);
    } catch (err) {
      console.error("Frame capture error:", err);
      return null;
    }
  };

  // 👁️ Routine 2: Vision Analysis Executor ("Look at this, Jarvis")
  const handleAnalyzeVision = async (
    source: 'screen' | 'camera' | 'upload',
    customPrompt?: string,
    existingBase64?: string
  ) => {
    if (isVisionAnalyzing) return;
    setIsVisionAnalyzing(true);
    stopTTS();

    let imageBase64 = existingBase64;
    if (!imageBase64) {
      setToastMessage(`📸 Capturing ${source === 'screen' ? 'desktop screen' : 'camera'} frame...`);
      imageBase64 = await captureSnapshotFrame(source as 'screen' | 'camera');
    }

    if (!imageBase64) {
      setIsVisionAnalyzing(false);
      setToastMessage("Snapshot capture cancelled or permission not granted.");
      return;
    }

    const activeLang = userProfile?.preferences?.aiVoiceLanguage || settingsAiLanguage || 'en';
    const finalPrompt = customPrompt?.trim() || (
      source === 'screen'
        ? "Inspect this desktop screen snapshot. If there is code, detect bugs and explain the fix. If there is a problem, equation, or document, explain and solve it clearly."
        : "Analyze what is shown in this camera snapshot. Explain the objects, solve any visible questions, and give clear insights."
    );

    const userMsgId = Date.now().toString() + '-user';
    const aiMsgId = (Date.now() + 1).toString() + '-ai';

    setChatHistory(prev => [
      ...prev,
      {
        id: userMsgId,
        role: 'user',
        text: `👁️ Look at this (${source === 'screen' ? 'Desktop Screen' : source === 'camera' ? 'Camera' : 'Image'}): "${finalPrompt}"`,
        timestamp: Date.now(),
        isVisionAnalysis: true,
        visionSnapshot: imageBase64,
        visionSource: source,
        visionPrompt: finalPrompt
      },
      {
        id: aiMsgId,
        role: 'ai',
        text: '',
        timestamp: Date.now() + 1,
        isVisionAnalysis: true,
        visionSnapshot: imageBase64,
        visionSource: source,
        visionPrompt: finalPrompt
      }
    ]);

    setToastMessage("👁️ MUKE Vision is analyzing snapshot...");

    try {
      const res = await fetch('/api/vision/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64,
          mimeType: 'image/jpeg',
          prompt: finalPrompt,
          language: activeLang
        })
      });

      if (!res.ok) throw new Error("Vision analysis API request failed");
      const data = await res.json();

      setChatHistory(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: data.text } : m));
      speakWithSciReyVoice(data.spokenSummary, aiMsgId);
      setToastMessage("👁️ Vision Analysis Complete");
      setShowVisionModal(false);
      setVisionCapturedImage(null);
    } catch (err: any) {
      console.error("Vision analyze failure:", err);
      const errMsg = activeLang === 'hi' 
        ? "माफ़ कीजिए, मुझे इस दृश्य को समझने में त्रुटि हुई। कृपया पुनः प्रयास करें।"
        : activeLang === 'ur'
        ? "معذرت، اس منظر کا تجزیہ کرتے ہوئے مسئلہ پیش آیا۔ براہ کرم دوبارہ کوشش کریں۔"
        : "I was unable to analyze this snapshot right now. Please ensure camera or screen permissions are enabled and try again.";
      setChatHistory(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: errMsg } : m));
      speakWithSciReyVoice(errMsg, aiMsgId);
    } finally {
      setIsVisionAnalyzing(false);
    }
  };

  const handleCommandSubmit = async (e?: React.FormEvent, directText?: string) => {
    if (e) e.preventDefault();
    const promptToSend = (directText || commandText).trim();
    if (!promptToSend) return;

    // 1. Voice Stop command: Stop current and queued actions immediately
    if (isStopPhrase(promptToSend)) {
      setCommandText("");
      handleStopEverything("Stop phrase submitted by voice/text");
      return;
    }

    // 2. Voice Confirmation for destructive actions
    if (pendingDestructiveActionRef.current) {
      setCommandText("");
      const lower = promptToSend.toLowerCase().trim();
      const isAffirmative = /^(yes|haan|ha|sure|proceed|karo|kar do|kar|do it|delete|close|confirm|हाँ|करो|कर दो)/i.test(lower);
      const isNegative = /^(no|nah|nahi|नहीं|cancel|stop|ruko|ruk|dont|mat karo|मत करो)/i.test(lower);

      const pending = pendingDestructiveActionRef.current;
      pendingDestructiveActionRef.current = null;

      if (isAffirmative) {
        setChatHistory(prev => [
          ...prev,
          { id: Date.now().toString() + '-user', role: 'user', text: promptToSend, timestamp: Date.now() }
        ]);
        await executeComputerControlAction(pending.action, { ...pending.params, confirmed: true });
        const reply = `Confirmed. Executed ${pending.action} successfully.`;
        const aiMsgId = Date.now().toString() + '-ai';
        setChatHistory(prev => [
          ...prev,
          { id: aiMsgId, role: 'ai', text: reply, timestamp: Date.now() }
        ]);
        speakWithSciReyVoice(reply, aiMsgId);
        setIsCommanding(false);
        return;
      } else if (isNegative) {
        const reply = "Action cancelled safely. Nothing was deleted or closed.";
        const aiMsgId = Date.now().toString() + '-ai';
        setChatHistory(prev => [
          ...prev,
          { id: Date.now().toString() + '-user', role: 'user', text: promptToSend, timestamp: Date.now() },
          { id: aiMsgId, role: 'ai', text: reply, timestamp: Date.now() }
        ]);
        speakWithSciReyVoice(reply, aiMsgId);
        setIsCommanding(false);
        return;
      }
    }

    // 3. Voice Timing Adjustment shortcuts (e.g. "set cooldown to 3 seconds")
    const cdMatch = promptToSend.match(/(?:cooldown|cool\s*down)\s*(?:to|ko|ka)?\s*([0-9.]+)\s*(?:sec|seconds|s|second)/i);
    if (cdMatch) {
      setCommandText("");
      const val = parseFloat(cdMatch[1]);
      updateTimingConfig({ wakeWordCooldownSeconds: val });
      const reply = `Wake-word cooldown set to ${val} seconds.`;
      speakWithSciReyVoice(reply);
      setToastMessage(reply);
      setTimeout(() => setToastMessage(null), 3000);
      setIsCommanding(false);
      return;
    }
    const timeoutMatch = promptToSend.match(/(?:listening\s*timeout|command\s*timeout|timeout)\s*(?:to|ko|ka)?\s*([0-9.]+)\s*(?:sec|seconds|s|second)/i);
    if (timeoutMatch) {
      setCommandText("");
      const val = parseFloat(timeoutMatch[1]);
      updateTimingConfig({ commandListeningTimeoutSeconds: val });
      const reply = `Command listening timeout set to ${val} seconds.`;
      speakWithSciReyVoice(reply);
      setToastMessage(reply);
      setTimeout(() => setToastMessage(null), 3000);
      setIsCommanding(false);
      return;
    }
    
    // 4. Voice Language Switching shortcuts (e.g. "set voice language to Hindi", "Hindi me bolo", "talk in Urdu", "speak in English")
    if (/(?:set\s+voice\s+language\s+to|language\s+to|change\s+language\s+to)\s*(?:hindi|हिंदी)|(?:hindi\s+me\s+baat\s+karo|हिंदी\s+में\s+बात\s+करो|hindi\s+me\s+bolo|हिंदी\s+में\s+बोलो)/i.test(promptToSend)) {
      setCommandText("");
      setSettingsAiLanguage('hi');
      if (userProfile) {
        const updated = { ...userProfile, preferences: { ...userProfile.preferences, aiVoiceLanguage: 'hi' as const } };
        setUserProfile(updated);
        localStorage.setItem('userProfile', JSON.stringify(updated));
      }
      localStorage.setItem('aiVoiceLanguage', 'hi');
      const reply = "ज़रूर! अब से मैं सिर्फ हिन्दी में ही बात करूँगा। मैं आपकी क्या मदद कर सकता हूँ?";
      const aiMsgId = Date.now().toString() + '-ai';
      setChatHistory(prev => [
        ...prev,
        { id: Date.now().toString() + '-user', role: 'user', text: promptToSend, timestamp: Date.now() },
        { id: aiMsgId, role: 'ai', text: reply, timestamp: Date.now() }
      ]);
      speakWithSciReyVoice(reply, aiMsgId);
      setIsCommanding(false);
      return;
    }
    if (/(?:set\s+voice\s+language\s+to|language\s+to|change\s+language\s+to)\s*(?:urdu|اردو)|(?:urdu\s+me\s+baat\s+karo|اردو\s+میں\s+بات\s+کرو|urdu\s+me\s+bolo|اردو\s+میں\s+بولو)/i.test(promptToSend)) {
      setCommandText("");
      setSettingsAiLanguage('ur');
      if (userProfile) {
        const updated = { ...userProfile, preferences: { ...userProfile.preferences, aiVoiceLanguage: 'ur' as const } };
        setUserProfile(updated);
        localStorage.setItem('userProfile', JSON.stringify(updated));
      }
      localStorage.setItem('aiVoiceLanguage', 'ur');
      const reply = "ضرور! اب سے میں صرف اردو میں ہی بات کروں گا۔ بتائیے میں آپ کی کیا مدد کر سکتا ہوں؟";
      const aiMsgId = Date.now().toString() + '-ai';
      setChatHistory(prev => [
        ...prev,
        { id: Date.now().toString() + '-user', role: 'user', text: promptToSend, timestamp: Date.now() },
        { id: aiMsgId, role: 'ai', text: reply, timestamp: Date.now() }
      ]);
      speakWithSciReyVoice(reply, aiMsgId);
      setIsCommanding(false);
      return;
    }
    if (/(?:set\s+voice\s+language\s+to|language\s+to|change\s+language\s+to)\s*english|(?:talk\s+in\s+english|speak\s+in\s+english|english\s+me\s+bolo)/i.test(promptToSend)) {
      setCommandText("");
      setSettingsAiLanguage('en');
      if (userProfile) {
        const updated = { ...userProfile, preferences: { ...userProfile.preferences, aiVoiceLanguage: 'en' as const } };
        setUserProfile(updated);
        localStorage.setItem('userProfile', JSON.stringify(updated));
      }
      localStorage.setItem('aiVoiceLanguage', 'en');
      const reply = "Understood! From now on, I will only talk and respond in English. How can I assist you?";
      const aiMsgId = Date.now().toString() + '-ai';
      setChatHistory(prev => [
        ...prev,
        { id: Date.now().toString() + '-user', role: 'user', text: promptToSend, timestamp: Date.now() },
        { id: aiMsgId, role: 'ai', text: reply, timestamp: Date.now() }
      ]);
      speakWithSciReyVoice(reply, aiMsgId);
      setIsCommanding(false);
      return;
    }

    // 5. Daily Morning Briefing Voice Trigger (e.g. "Hey Jarvis, Good Morning", "Subah bakhair", "Namaste", "Daily briefing")
    if (/(?:good\s*morning|subah\s*bakhair|صبح\s*بخیر|subah\s*ka\s*taaza|namaste|नमस्ते|daily\s*briefing|morning\s*briefing|morning\s*update|aaj\s*ka\s*briefing|aaj\s*ki\s*briefing|aaj\s*ka\s*update|briefing\s*do|morning\s*routine|brief\s*me)/i.test(promptToSend)) {
      setCommandText("");
      triggerDailyBriefing();
      setIsCommanding(false);
      return;
    }

    // 6. Camera & Screen Vision Voice Trigger ("Look at this, Jarvis", "Jarvis, look at my screen")
    if (/(?:look\s*at\s*my\s*screen|look\s*at\s*this|look\s*at\s*camera|see\s*this|watch\s*this|analyze\s*(?:my\s*)?screen|analyze\s*this|debug\s*(?:this|my\s*code)|what\s*is\s*on\s*my\s*screen|ye\s*dekho|yeh\s*dekho|screen\s*dekho|camera\s*dekho|iss\s*ko\s*dekho|solve\s*(?:this|the\s*math))/i.test(promptToSend)) {
      setCommandText("");
      const isScreenRequested = /(?:screen|desktop|code|window|browser)/i.test(promptToSend) || (!/(?:camera|face|photo|webcam)/i.test(promptToSend) && (isScreenSharing || !isCameraOn));
      const source = isScreenRequested ? 'screen' : 'camera';
      handleAnalyzeVision(source, promptToSend);
      setIsCommanding(false);
      return;
    }

    // 7. Morning Music & News voice shortcuts
    if (/(?:play|open|start)\s*(?:morning\s*)?(?:lofi|music|song|gana|gaane|focus\s*music)/i.test(promptToSend)) {
      setCommandText("");
      requestOpenUrl('https://www.youtube.com/results?search_query=morning+lofi+chill+focus+music', 'YouTube Music');
      const activeLang = userProfile?.preferences?.aiVoiceLanguage || settingsAiLanguage || 'en';
      const reply = activeLang === 'hi' ? "ज़रूर! मैं आपके लिए YouTube पर मॉर्निंग लो-फाई संगीत खोल रहा हूँ।" : activeLang === 'ur' ? "ضرور! میں آپ کے لیے یوٹیوب پر صبح کی پرسکون موسیقی کھول رہا ہوں۔" : "Certainly! Opening morning focus lofi music on YouTube for you.";
      speakWithSciReyVoice(reply);
      setIsCommanding(false);
      return;
    }
    if (/(?:play|open|stream)\s*(?:morning\s*)?(?:news|khabar|samachar|headlines)/i.test(promptToSend)) {
      setCommandText("");
      requestOpenUrl('https://www.youtube.com/results?search_query=latest+news+today+live', 'YouTube News');
      const activeLang = userProfile?.preferences?.aiVoiceLanguage || settingsAiLanguage || 'en';
      const reply = activeLang === 'hi' ? "ज़रूर! मैं आपके लिए YouTube पर आज के ताज़ा समाचार खोल रहा हूँ।" : activeLang === 'ur' ? "ضرور! میں آپ के लिए یوٹیوب پر تازہ ترین خبریں کھول رہا ہوں۔" : "Opening today's latest live news headlines on YouTube.";
      speakWithSciReyVoice(reply);
      setIsCommanding(false);
      return;
    }
    
    if (promptToSend === '__SPARK_AGI__') {
      setCommandText("");
      triggerAutonomousAgiThought(true);
      return;
    }

    setAgiCountdown(agiIntervalSeconds);
    lastUserInteractionTimeRef.current = Date.now();
    stopTTS();
    
    const userMsgId = Date.now().toString() + '-user';
    const aiMsgId = (Date.now() + 1).toString() + '-ai';
    
    // Optimistically record user message immediately and create placeholder for streaming AI message
    setChatHistory(prev => {
      const next = [
        ...prev, 
        { id: userMsgId, role: 'user' as const, text: promptToSend, timestamp: Date.now() },
        { id: aiMsgId, role: 'ai' as const, text: '', timestamp: Date.now() + 1 }
      ];
      return next.slice(-60); // Keep last 60 to prevent lag
    });

    setCommandText("");
    setIsCommanding(true);

    const activeLang = userProfile?.preferences?.aiVoiceLanguage || settingsAiLanguage || 'en';
    const langRule = activeLang === 'hi'
      ? "CRITICAL LANGUAGE ENFORCEMENT: The user has selected HINDI (हिन्दी) in settings. You MUST ONLY talk, reply, and speak in HINDI. Do NOT answer in English or Urdu unless explicitly asked. Provide your entire conversational response naturally in Hindi."
      : activeLang === 'ur'
      ? "CRITICAL LANGUAGE ENFORCEMENT: The user has selected URDU (اردو) in settings. You MUST ONLY talk, reply, and speak in URDU. Do NOT answer in English or Hindi unless explicitly asked. Provide your entire conversational response naturally in Urdu."
      : "CRITICAL LANGUAGE ENFORCEMENT: The user has selected ENGLISH in settings. You MUST ONLY talk, reply, and speak in ENGLISH. Do NOT answer in Hindi or Urdu unless explicitly asked.";

    const systemInstruction = `You are MUKE, an intelligent, helpful, and friendly AI assistant created and powered by Asad with full hands-free computer control capabilities.
${langRule}
- VOICE CHAT DURATION RULE: Strictly keep your conversational reply short to 1-2 sentences maximum. Spoken replies must be fast, punchy, and direct. Do not give lengthy explanations.
If anyone asks for your name or creator/owner, proudly respond that you are MUKE, created and powered by Asad.
${userProfile ? `User's name is ${userProfile.fullName}. Address them by first name.` : ''}
Current local time: ${new Date().toString()}
Current tasks: ${JSON.stringify(tasks)}

COMPUTER CONTROL TOOLS (Execute via tool calls, no clicking needed):
1. Mouse control (move, click, double_click, right_click, scroll, drag): call controlMouse.
2. Keyboard control (type text, press enter/space/keys, shortcuts like ctrl+c, ctrl+v, alt+tab): call controlKeyboard.
3. Web search (open default browser and search Google or open any website/url): call searchWebOrOpen.
4. Files and folders (create folder, create file with content, open file/folder, delete file/folder): call manageFilesFolders.
5. Apps (open any installed app by name, close/exit app by name): call manageApps.
6. Windows and tabs (close window, close tab, switch window): call manageWindowsTabs.
7. Timing configuration (change cooldown, timeouts, speeds): call configureTimings.

SAFETY POLICY:
Destructive actions such as deleting files or folders, overwriting existing files, closing apps that may have unsaved work, or shutting down MUST NEVER be performed without explicit voice confirmation. When requested, ask "Are you sure you want to [action]?" and await user confirmation.`;

    try {
      let accumulatedText = "";
      let functionCallsExecuted = false;
      let streamedSentenceCount = 0;

      // Construct sanitized turn-alternating history to prevent API turn validation errors
      const sanitizedContents: { role: 'user' | 'model'; parts: [{ text: string }] }[] = [];
      for (const msg of chatHistory.slice(-10)) {
        const text = msg.text?.trim();
        if (!text) continue;
        const role = msg.role === 'user' ? 'user' : 'model';
        if (sanitizedContents.length > 0 && sanitizedContents[sanitizedContents.length - 1].role === role) {
          sanitizedContents[sanitizedContents.length - 1].parts[0].text += `\n${text}`;
        } else {
          sanitizedContents.push({ role, parts: [{ text }] });
        }
      }

      if (sanitizedContents.length > 0 && sanitizedContents[sanitizedContents.length - 1].role === 'user') {
        sanitizedContents[sanitizedContents.length - 1].parts[0].text += `\n${promptToSend}`;
      } else {
        sanitizedContents.push({ role: 'user', parts: [{ text: promptToSend }] });
      }

      // Fastest Gemini models for instant voice chat
      const candidateModels = ['gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-flash-latest'];

      // Primary Streaming Attempt across candidate models
      for (const model of candidateModels) {
        if (accumulatedText || functionCallsExecuted) break;
        try {
          console.log(`[PERF ${new Date().toISOString()}] AI request sent to model: ${model}`);
          const responseStream = await ai.models.generateContentStream({
            model,
            contents: sanitizedContents,
            config: {
              systemInstruction,
              tools: [
                {
                  functionDeclarations: aiSharedToolDeclarations
                }
              ]
            }
          });

          let currentSentenceBuffer = "";
          let firstChunkLogged = false;
          let ttsStartedLogged = false;

          for await (const chunk of responseStream) {
            if (chunk.text) {
              if (!firstChunkLogged) {
                firstChunkLogged = true;
                console.log(`[PERF ${new Date().toISOString()}] First AI text received: "${chunk.text.slice(0, 40)}"`);
              }
              accumulatedText += chunk.text;
              currentSentenceBuffer += chunk.text;
              setChatHistory(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: accumulatedText } : m));

              // As soon as the first sentence is ready, send it to ElevenLabs TTS and start playing
              const sentenceMatch = currentSentenceBuffer.match(/^([\s\S]+?[.?!।۔\n]+)([\s\S]*)$/);
              if (sentenceMatch) {
                const sentence = sentenceMatch[1].trim();
                currentSentenceBuffer = sentenceMatch[2];
                if (sentence.length > 2) {
                  streamedSentenceCount++;
                  if (!ttsStartedLogged) {
                    ttsStartedLogged = true;
                    console.log(`[PERF ${new Date().toISOString()}] TTS started for: "${sentence}"`);
                  }
                  playStreamingSentence(sentence, aiMsgId);
                }
              }
            }

            const functionCalls = chunk.functionCalls;
            if (functionCalls && functionCalls.length > 0) {
              functionCallsExecuted = true;
              for (const call of functionCalls) {
                await dispatchFunctionCall(call);
              }
            }
          }

          // Remaining sentence buffer at end of stream
          const remainingSentence = currentSentenceBuffer.trim();
          if (remainingSentence.length > 1) {
            streamedSentenceCount++;
            if (!ttsStartedLogged) {
              ttsStartedLogged = true;
              console.log(`[PERF ${new Date().toISOString()}] TTS started for: "${remainingSentence}"`);
            }
            playStreamingSentence(remainingSentence, aiMsgId);
          }
        } catch (streamError) {
          console.warn(`Streaming attempt with model ${model} failed, trying next candidate:`, streamError);
        }
      }

      // If streaming with tools didn't return text and no functions executed, attempt direct generation
      if (!accumulatedText && !functionCallsExecuted) {
        for (const model of candidateModels) {
          if (accumulatedText) break;
          try {
            console.log(`[PERF ${new Date().toISOString()}] AI request sent to model (fallback): ${model}`);
            const staticRes = await ai.models.generateContent({
              model,
              contents: sanitizedContents,
              config: {
                systemInstruction
              }
            });
            if (staticRes.text) {
              accumulatedText = staticRes.text;
              console.log(`[PERF ${new Date().toISOString()}] First AI text received: "${accumulatedText.slice(0, 40)}"`);
              setChatHistory(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: accumulatedText } : m));
              break;
            }
          } catch (directErr) {
            console.warn(`Direct generateContent on ${model} failed:`, directErr);
          }
        }
      }

      // Final fallback if tool executed without textual return
      if (!accumulatedText) {
        if (functionCallsExecuted) {
          accumulatedText = "I have executed that command for you.";
        } else {
          accumulatedText = "I received your message. Please feel free to ask me anything!";
        }
        setChatHistory(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: accumulatedText } : m));
      }

      // If no sentence was dispatched via stream, speak now
      if (streamedSentenceCount === 0 && accumulatedText) {
        console.log(`[PERF ${new Date().toISOString()}] TTS started for: "${accumulatedText}"`);
        playStreamingSentence(accumulatedText, aiMsgId);
      }

      setToastMessage("Ready");
      setTimeout(() => setToastMessage(null), 1500);
    } catch (err) {
      console.error("Command processing error:", err);
      const errorReply = "I encountered a momentary connection issue. Please try your request again.";
      setChatHistory(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: errorReply } : m));
      speakWithSciReyVoice(errorReply, aiMsgId);
      setToastMessage("Failed to process command.");
      setTimeout(() => setToastMessage(null), 3000);
    } finally {
      setIsCommanding(false);
    }
  };

  const startLiveSession = async () => {
    try {
      setIsConnecting(true);
      setError(null);

      // Request microphone access
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Your browser does not support audio recording or it is blocked by security settings.");
      }
      mediaStreamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: 16000,
      });
      if (audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      }

      gainNodeRef.current = audioContextRef.current.createGain();
      gainNodeRef.current.connect(audioContextRef.current.destination);
      gainNodeRef.current.gain.value = userProfile?.preferences?.masterVolume ?? 1.0;

      const sessionPromise = ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: activeVoice } },
          },
          systemInstruction: `You are a proactive, conversational Voice Assistant. Your owner and creator is Asad. If anyone asks for your name, you must respond exactly with: "my name is MUKE powered by ASSAD how can i help you".
You don't always need to wait for the user to speak. Occasionally act proactively to offer help or share a brief fact!
${userProfile ? `The user's name is ${userProfile.fullName}. Always address them by their first name when responding.` : ''}
Current local time: ${new Date().toString()}

MEMORY VAULT (Always remember this):
Current tasks: ${JSON.stringify(tasks)}
Saved notes: ${JSON.stringify(notes)}
Recent conversation history: ${JSON.stringify(chatHistory.slice(-15))}

You have visual capabilities! The user might stream their web camera or their desktop screen to you.
When they ask you to look at something, analyze the video frames you are receiving. Always speak clearly and try to be highly descriptive.
You can perform Object detection, Face Detection, Face Recognition (describe expressions and features), and Hand gesture recognition. 
If you clearly see a hand gesture (like thumbs_up, thumbs_down, peace, wave, rock, ok, heart, point, open_hand, fist), immediately call the "recognizeGesture" tool with the detected gesture type to show visual feedback on the screen. **IMPORTANT: You MUST also verbally tell the user that you saw the gesture (e.g., "I see your thumbs up!", "Peace to you too!", "Nice rock sign!").**
When the user shows an object and asks about it (e.g., "what is this?"), act as an expert analyst and provide a detailed, structured breakdown including:
1. Name/Type of the object
2. Probable Brand/Model (if identifiable)
3. Estimated Price range
4. Color and Material
5. Style/Aesthetic (e.g., Simple, Modern, Vintage)
If the user asks to open a website or web app, use the openWebApp tool.

IMPORTANT FOR NOTES AND TASKS:
DO NOT save a task or note automatically when the user is just dictating the details.
- If the user says they want to add a task/note, ask them for the details.
- When they provide the details, just hold them in your memory, acknowledge them verbally, and wait. DO NOT call 'addTask' or 'takeNote' yet.
- ONLY call the 'addTask' or 'takeNote' tool when the user EXPLICITLY commands you to save it (e.g., "now save it", "ab isko save karo", "save this").
- Ask them to say "save it" when they are done dictating.
If the user asks to open the sidebar to see them, use openTaskSidebar or openNotesSidebar.

If the user asks to complete a task, use completeTask.
If the user asks what their tasks are, read them from the Current tasks list.`,
          tools: [
            {
              functionDeclarations: [
                {
                  name: "openTaskSidebar",
                  description: "Opens the task sidebar in the UI so the user can see their tasks."
                },
                {
                  name: "openNotesSidebar",
                  description: "Opens the notes sidebar in the UI so the user can see their notes."
                },
                {
                  name: "openWebApp",
                  description: "Opens a website or web app in a new tab.",
                  parameters: { type: Type.OBJECT, properties: { url: { type: Type.STRING, description: "The full URL of the website to open (e.g., https://youtube.com)." } }, required: ["url"] }
                },
                {
                  name: "addTask",
                  description: "Adds a new task to the user's task list.",
                  parameters: { type: Type.OBJECT, properties: { title: { type: Type.STRING, description: "The title or description of the task." }, reminderTime: { type: Type.STRING, description: "Optional ISO 8601 datetime string for when the user wants to be reminded." } }, required: ["title"] }
                },
                {
                  name: "completeTask",
                  description: "Marks a task as complete.",
                  parameters: { type: Type.OBJECT, properties: { title: { type: Type.STRING, description: "The title of the task to complete." } }, required: ["title"] }
                },
                {
                  name: "takeNote",
                  description: "Saves a note or journal entry for the user.",
                  parameters: { type: Type.OBJECT, properties: { text: { type: Type.STRING, description: "The content of the note." } }, required: ["text"] }
                },
                {
                  name: "recognizeGesture",
                  description: "Triggers a visual overlay on the screen when a hand gesture is recognized. Use this along with verbally acknowledging the gesture.",
                  parameters: { 
                    type: Type.OBJECT, 
                    properties: { 
                      gesture: { 
                        type: Type.STRING, 
                        description: "The recognized gesture (e.g., 'thumbs_up', 'thumbs_down', 'peace', 'wave', 'rock', 'ok', 'heart', 'point', 'open_hand', 'fist')" 
                      } 
                    }, 
                    required: ["gesture"] 
                  }
                }
              ]
            }
          ]
        },
        callbacks: {
          onopen: () => {
            setIsConnected(true);
            setIsConnecting(false);
            silenceFrameCountRef.current = 0;
            
            // Setup ultra low-latency audio processing
            if (audioContextRef.current && mediaStreamRef.current) {
              sourceRef.current = audioContextRef.current.createMediaStreamSource(mediaStreamRef.current);
              processorRef.current = audioContextRef.current.createScriptProcessor(2048, 1, 1);
              
              processorRef.current.onaudioprocess = (e) => {
                const inputData = e.inputBuffer.getChannelData(0);
                const outputData = e.outputBuffer.getChannelData(0);
                
                // Silence output to prevent echo feedback loop
                for (let i = 0; i < outputData.length; i++) {
                  outputData[i] = 0;
                }

                const l = inputData.length;
                let sum = 0;
                for (let i = 0; i < l; i++) {
                  sum += inputData[i] * inputData[i];
                }
                const rms = Math.sqrt(sum / l);

                // Low-bandwidth & slow WiFi optimization: gate quiet frames while preserving live stream
                if (rms < 0.004) {
                  silenceFrameCountRef.current = (silenceFrameCountRef.current || 0) + 1;
                  // Send heartbeat silence frame every 12 frames (~1.5s) to keep websocket active
                  if (silenceFrameCountRef.current % 12 !== 0) {
                    return;
                  }
                } else {
                  silenceFrameCountRef.current = 0;
                }

                const buffer = new ArrayBuffer(l * 2);
                const view = new DataView(buffer);
                
                for (let i = 0; i < l; i++) {
                  const s = Math.max(-1, Math.min(1, inputData[i]));
                  view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
                }
                
                const bytes = new Uint8Array(buffer);
                let binary = '';
                for (let i = 0; i < bytes.length; i++) {
                  binary += String.fromCharCode(bytes[i]);
                }
                const base64Data = btoa(binary);

                if (activeLiveSessionRef.current) {
                  try {
                    activeLiveSessionRef.current.sendRealtimeInput({
                      audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
                    });
                  } catch (e) {
                    // Ignore transient stream frame drops
                  }
                }
              };

              sourceRef.current.connect(processorRef.current);
              processorRef.current.connect(audioContextRef.current.destination);
            }
          },
          onmessage: async (message: any) => {
            const serverContent = message.serverContent;
            if (serverContent) {
              if (serverContent.modelTurn) {
                const base64Audio = serverContent.modelTurn.parts?.[0]?.inlineData?.data;
                if (base64Audio) {
                  playAudioChunk(base64Audio);
                }
                
                // Fallback for old API style text parts
                const textPart = serverContent.modelTurn.parts?.find((p: any) => p.text);
                if (textPart && textPart.text) {
                  setChatHistory(prev => [...prev, {
                    id: Date.now().toString() + '-ai-live',
                    role: 'ai',
                    text: textPart.text,
                    timestamp: Date.now()
                  }]);
                }
              }
              
              if (serverContent.interrupted) {
                nextPlayTimeRef.current = 0;
                setIsSpeaking(false);
                scheduledSourcesRef.current.forEach(source => {
                  try {
                    source.stop();
                    source.disconnect();
                  } catch (e) {}
                });
                scheduledSourcesRef.current = [];
              }
            }
            if (message.toolCall) {
              const functionCalls = message.toolCall.functionCalls;
              const toolResponses: any[] = [];
              
              for (const call of functionCalls) {
                let result = { status: "success" };
                
                if (call.name === 'openWebApp') {
                  const args = call.args as { url: string };
                  if (args.url) requestOpenUrl(args.url);
                } else if (call.name === 'addTask') {
                  const args = call.args as { title: string, reminderTime?: string };
                  if (args.title) {
                    const rTime = args.reminderTime ? new Date(args.reminderTime).getTime() : undefined;
                    setTasks(prev => [...prev, { id: Date.now().toString(), title: args.title, completed: false, reminderTime: rTime, notified: false }]);
                    setToastMessage(`Added task: ${args.title}`);
                    setTimeout(() => setToastMessage(null), 3000);
                  }
                } else if (call.name === 'completeTask') {
                  const args = call.args as { title: string };
                  if (args.title) {
                    setTasks(prev => prev.map(t => 
                      t.title.toLowerCase().includes(args.title.toLowerCase()) || args.title.toLowerCase().includes(t.title.toLowerCase())
                        ? { ...t, completed: true } 
                        : t
                    ));
                    setToastMessage(`Completed task: ${args.title}`);
                    setTimeout(() => setToastMessage(null), 3000);
                  }
                } else if (call.name === 'takeNote') {
                  const args = call.args as { text: string };
                  if (args.text) {
                    setNotes(prev => [{ id: Date.now().toString(), text: args.text, date: Date.now() }, ...prev]);
                    setToastMessage(`Note saved!`);
                    setTimeout(() => setToastMessage(null), 3000);
                  }
                } else if (call.name === 'openTaskSidebar') {
                  setShowTasks(true);
                  setShowNotes(false);
                } else if (call.name === 'openNotesSidebar') {
                  setShowNotes(true);
                  setShowTasks(false);
                } else if (call.name === 'recognizeGesture') {
                  const args = call.args as { gesture: string };
                  if (args.gesture) {
                    triggerGesture(args.gesture);
                  }
                }
                
                toolResponses.push({
                  id: call.id,
                  name: call.name,
                  response: result
                });
              }
              
              if (activeLiveSessionRef.current) {
                try {
                  activeLiveSessionRef.current.sendToolResponse({ functionResponses: toolResponses });
                } catch (e) {
                  console.error(e);
                }
              }
            }
          },
          onerror: (err) => {
            console.error("Live API Error:", err);
            stopLiveSession();
            startDictation();
          },
          onclose: () => {
            stopLiveSession();
          }
        }
      });

      sessionRef.current = sessionPromise;
      sessionPromise
        .then(session => {
          activeLiveSessionRef.current = session;
        })
        .catch(err => {
          console.warn("Live websocket fallback to Speech Dictation mode:", err);
          stopLiveSession();
          startDictation();
        });

    } catch (err: any) {
      console.error("Failed to start session:", err);
      
      let errorMessage = err.message || "Failed to access microphone.";
      
      if (err.name === 'NotAllowedError' || errorMessage.toLowerCase().includes('permission denied')) {
        errorMessage = "Permission denied. Please allow microphone access in your browser.";
        setError(errorMessage);
        setIsConnecting(false);
      } else if (err.name === 'NotFoundError') {
        errorMessage = "No microphone found. Please connect a microphone and try again.";
        setError(errorMessage);
        setIsConnecting(false);
      } else {
        setIsConnecting(false);
        startDictation();
      }
    }
  };

  const playAudioChunk = async (base64Audio: string) => {
    try {
      if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      }
      const binaryString = atob(base64Audio);
      const len = binaryString.length;
      const sampleCount = Math.floor(len / 2);
      if (sampleCount === 0) return;

      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      
      // PCM 24000Hz 16-bit little-endian
      const view = new DataView(bytes.buffer, bytes.byteOffset, sampleCount * 2);
      const float32Array = new Float32Array(sampleCount);
      for (let i = 0; i < sampleCount; i++) {
        const int16 = view.getInt16(i * 2, true);
        float32Array[i] = int16 / 32768.0;
      }

      scheduleAudioChunk(float32Array);
    } catch (e) {
      console.error("Error decoding audio chunk", e);
    }
  };

  const scheduleAudioChunk = (chunk: Float32Array) => {
    const audioCtx = audioContextRef.current;
    if (!audioCtx) return;

    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    setIsSpeaking(true);
    if (speakingTimeoutRef.current) {
      clearTimeout(speakingTimeoutRef.current);
      speakingTimeoutRef.current = null;
    }

    const audioBuffer = audioCtx.createBuffer(1, chunk.length, 24000);
    audioBuffer.getChannelData(0).set(chunk);

    const source = audioCtx.createBufferSource();
    source.buffer = audioBuffer;
    
    if (gainNodeRef.current) {
      source.connect(gainNodeRef.current);
    } else {
      source.connect(audioCtx.destination);
    }

    const currentTime = audioCtx.currentTime;
    if (nextPlayTimeRef.current < currentTime) {
      nextPlayTimeRef.current = currentTime + 0.08; // 80ms smooth jitter buffer
    }

    source.start(nextPlayTimeRef.current);
    nextPlayTimeRef.current += audioBuffer.duration;
    
    scheduledSourcesRef.current.push(source);

    source.onended = () => {
      scheduledSourcesRef.current = scheduledSourcesRef.current.filter(s => s !== source);
      if (scheduledSourcesRef.current.length === 0) {
        speakingTimeoutRef.current = setTimeout(() => {
          setIsSpeaking(false);
        }, 180);
      }
    };
  };

  const stopLiveSession = () => {
    if (activeLiveSessionRef.current) {
      try {
        activeLiveSessionRef.current.close();
      } catch (e) {}
      activeLiveSessionRef.current = null;
    }
    if (sessionRef.current) {
      sessionRef.current.then((session: any) => session.close()).catch(() => {});
      sessionRef.current = null;
    }
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    if (sourceRef.current) {
      sourceRef.current.disconnect();
      sourceRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(t => t.stop());
      mediaStreamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    setIsConnected(false);
    setIsConnecting(false);
    setIsSpeaking(false);
    if (speakingTimeoutRef.current) {
      clearTimeout(speakingTimeoutRef.current);
      speakingTimeoutRef.current = null;
    }
    if (isCameraOn) {
      stopCamera();
    }
    nextPlayTimeRef.current = 0;
    scheduledSourcesRef.current = [];
  };

  const stopCamera = () => {
    if (visionIntervalRef.current) {
      clearInterval(visionIntervalRef.current);
      visionIntervalRef.current = null;
    }
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach(t => t.stop());
      cameraStreamRef.current = null;
    }
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(t => t.stop());
      screenStreamRef.current = null;
    }
    setIsCameraOn(false);
    setIsScreenSharing(false);
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      cameraStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      if (!canvasRef.current) {
        canvasRef.current = document.createElement('canvas');
      }
      setIsCameraOn(true);
      
      if (!visionIntervalRef.current) {
        visionIntervalRef.current = setInterval(() => {
          if (!isConnected || !sessionRef.current || !canvasRef.current) return;
          const canvas = canvasRef.current;
          
          let activeVideo: HTMLVideoElement | null = null;
          if (screenStreamRef.current && screenVideoRef.current && screenVideoRef.current.videoWidth > 0) {
            activeVideo = screenVideoRef.current;
          } else if (cameraStreamRef.current && videoRef.current && videoRef.current.videoWidth > 0) {
            activeVideo = videoRef.current;
          }

          if (activeVideo) {
            // Scale down drastically for CPU optimization and bandwidth
            const MAX_DIMENSION = 512;
            let width = activeVideo.videoWidth;
            let height = activeVideo.videoHeight;
            
            if (width > height && width > MAX_DIMENSION) {
              height = Math.round((height * MAX_DIMENSION) / width);
              width = MAX_DIMENSION;
            } else if (height > MAX_DIMENSION) {
              width = Math.round((width * MAX_DIMENSION) / height);
              height = MAX_DIMENSION;
            }

            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(activeVideo, 0, 0, width, height);
              const base64Data = canvas.toDataURL('image/jpeg', 0.3).split(',')[1];
              sessionRef.current.then((session: any) => {
                session.sendRealtimeInput({ video: { mimeType: "image/jpeg", data: base64Data } }).catch((err: any) => console.error("Vision send error", err));
              });
            }
          }
        }, 2000);
      }
    } catch (err) {
      console.error("Failed to start camera", err);
      setToastMessage("Failed to access camera.");
    }
  };

  const toggleCamera = () => {
    if (isCameraOn) {
      stopCamera(); // Stops all vision streams
    } else {
      startCamera();
    }
  };

  const toggleScreenShare = async () => {
    if (isScreenSharing) {
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach(t => t.stop());
        screenStreamRef.current = null;
      }
      setIsScreenSharing(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({ 
          video: {
            width: { ideal: 1280, max: 1920 },
            height: { ideal: 720, max: 1080 }
          }
        });
        screenStreamRef.current = stream;
        if (screenVideoRef.current) {
          screenVideoRef.current.srcObject = stream;
        }
        if (!canvasRef.current) {
          canvasRef.current = document.createElement('canvas');
        }
        setIsScreenSharing(true);
        
        stream.getVideoTracks()[0].onended = () => {
           if (screenStreamRef.current) {
             screenStreamRef.current.getTracks().forEach(t => t.stop());
             screenStreamRef.current = null;
           }
           setIsScreenSharing(false);
        };
        
        if (!visionIntervalRef.current) {
          visionIntervalRef.current = setInterval(() => {
            if (!isConnected || !sessionRef.current || !canvasRef.current) return;
            const canvas = canvasRef.current;
            
            let activeVideo: HTMLVideoElement | null = null;
            if (screenStreamRef.current && screenVideoRef.current && screenVideoRef.current.videoWidth > 0) {
              activeVideo = screenVideoRef.current;
            } else if (cameraStreamRef.current && videoRef.current && videoRef.current.videoWidth > 0) {
              activeVideo = videoRef.current;
            }

            if (activeVideo) {
              // Scale down drastically for CPU optimization and bandwidth
              const MAX_DIMENSION = 512;
              let width = activeVideo.videoWidth;
              let height = activeVideo.videoHeight;
              
              if (width > height && width > MAX_DIMENSION) {
                height = Math.round((height * MAX_DIMENSION) / width);
                width = MAX_DIMENSION;
              } else if (height > MAX_DIMENSION) {
                width = Math.round((width * MAX_DIMENSION) / height);
                height = MAX_DIMENSION;
              }

              canvas.width = width;
              canvas.height = height;
              const ctx = canvas.getContext('2d');
              if (ctx) {
                ctx.drawImage(activeVideo, 0, 0, width, height);
                const base64Data = canvas.toDataURL('image/jpeg', 0.3).split(',')[1];
                sessionRef.current.then((session: any) => {
                  session.sendRealtimeInput({ video: { mimeType: "image/jpeg", data: base64Data } }).catch((err: any) => console.error("Vision send error", err));
                });
              }
            }
          }, 2000);
        }
        
      } catch (err) {
        console.error("Screen share failed", err);
      }
    }
  };

  const handleMicButtonClick = (initialText?: string) => {
    if (isSpeaking) {
      stopTTS();
    } else if (isConnected) {
      stopLiveSession();
    } else if (isDictating) {
      stopDictation();
    } else {
      if (isCameraOn || isScreenSharing) {
        startLiveSession();
      } else {
        startDictation(initialText);
      }
    }
  };
  handleMicButtonClickRef.current = handleMicButtonClick;

  useEffect(() => {
    return () => {
      stopLiveSession();
    };
  }, []);

  return (
    <div className="flex flex-col items-center justify-center w-full min-h-[80vh] space-y-8 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(59,130,246,0.15),transparent_50%)] pointer-events-none -z-10" />
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none -z-10" />
      
      <video ref={videoRef} autoPlay playsInline muted className="hidden" />
      <video ref={screenVideoRef} autoPlay playsInline muted className="hidden" />

      {/* Picture-in-Picture Feedback for Vision */}
      {(isCameraOn || isScreenSharing) && (
        <div className="absolute top-4 left-4 z-50 flex flex-col gap-2">
          {isCameraOn && (
            <div className="w-48 h-36 bg-[#1a1a1a] rounded-xl overflow-hidden border-2 border-teal-500/50 shadow-2xl relative shadow-[0_0_20px_rgba(20,184,166,0.3)] flex items-center justify-center">
              <span className="absolute text-xs text-white/50 z-0 tracking-widest uppercase">Webcam</span>
              
              {/* Fake HUD Crosshairs for JARVIS effect */}
              <div className="absolute inset-0 pointer-events-none z-30">
                <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-teal-500/50" />
                <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-teal-500/50" />
                <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-teal-500/50" />
                <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-teal-500/50" />
              </div>

              <video 
                autoPlay 
                playsInline 
                muted 
                className="absolute inset-0 w-full h-full object-cover z-10"
                ref={(node) => {
                  if (node && videoRef.current && videoRef.current.srcObject) {
                    node.srcObject = videoRef.current.srcObject;
                  }
                }} 
              />
              
              {/* Gesture Overlay */}
              {recognizedGesture && (
                <div className="absolute inset-0 flex items-center justify-center z-40 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300">
                  <div className="flex flex-col items-center animate-bounce">
                    <span className="text-4xl drop-shadow-lg">
                      {recognizedGesture.includes('thumbs_up') ? '👍' :
                       recognizedGesture.includes('thumbs_down') ? '👎' :
                       recognizedGesture.includes('peace') ? '✌️' :
                       recognizedGesture.includes('wave') ? '👋' :
                       recognizedGesture.includes('rock') ? '🤘' :
                       recognizedGesture.includes('ok') ? '👌' :
                       recognizedGesture.includes('heart') ? '🫶' :
                       recognizedGesture.includes('point') ? '☝️' :
                       recognizedGesture.includes('fist') ? '✊' :
                       recognizedGesture.includes('open') ? '🖐️' : '✋'}
                    </span>
                    <span className="text-white text-[10px] font-bold mt-1 uppercase tracking-wider bg-black/60 px-2 py-0.5 rounded">
                      {recognizedGesture.replace('_', ' ')}
                    </span>
                  </div>
                </div>
              )}

              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between z-20">
                <span className="text-[10px] font-bold bg-teal-500 text-white px-2 py-0.5 rounded shadow">REC</span>
              </div>
            </div>
          )}
          {isScreenSharing && (
            <div className="w-48 h-36 bg-[#1a1a1a] rounded-xl overflow-hidden border-2 border-indigo-500/50 shadow-2xl relative shadow-[0_0_20px_rgba(99,102,241,0.3)] flex items-center justify-center">
              <span className="absolute text-xs text-white/50 z-0 tracking-widest uppercase">Screen</span>
              <video 
                autoPlay 
                playsInline 
                muted 
                className="absolute inset-0 w-full h-full object-contain z-10"
                ref={(node) => {
                  if (node && screenVideoRef.current && screenVideoRef.current.srcObject) {
                    node.srcObject = screenVideoRef.current.srcObject;
                  }
                }} 
              />
               <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between z-20">
                <span className="text-[10px] font-bold bg-indigo-500 text-white px-2 py-0.5 rounded shadow">SHARE</span>
              </div>
            </div>
          )}
        </div>
      )}
      
      {/* Weather & Clock Widget */}
      <div className="absolute top-4 right-4 flex flex-col items-end text-right bg-[#0a0a0a]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-4 shadow-[0_0_30px_rgba(0,0,0,0.5)] z-50">
        <div className="text-[#aaaaaa] text-sm font-medium mb-1">
          {userProfile ? `Good ${currentTime.getHours() < 12 ? 'Morning' : currentTime.getHours() < 18 ? 'Afternoon' : 'Evening'}, ${userProfile.fullName.split(' ')[0]}` : 'Welcome'}
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-white font-semibold text-xl">
            <Clock className="w-5 h-5 text-blue-400" />
            {currentTime.toLocaleTimeString([], { 
              hour: '2-digit', 
              minute: '2-digit',
              hour12: userProfile?.preferences?.timeFormat === '12h' 
            })}
          </div>
          {weather && (
            <div className="flex items-center gap-1.5 text-white font-semibold text-xl border-l border-[#444444] pl-3">
              <span>{weather.condition}</span>
              <span>{Math.round(weather.temp)}°C</span>
            </div>
          )}
        </div>
        
        <div className="mt-3 w-full flex items-center justify-between border-t border-[#444444] pt-3">
          <span className="text-xs text-[#888888] font-medium uppercase tracking-wider">AI Voice Model</span>
          <button
            onClick={() => setActiveVoice(activeVoice === 'Charon' ? 'Fenrir' : activeVoice === 'Fenrir' ? 'Kore' : 'Charon')}
            className={`flex items-center gap-1 px-2 py-1 rounded text-xs font-semibold transition-colors border ${
              activeVoice === 'Charon' ? 'bg-slate-900/40 text-slate-400 border-slate-500/30' :
              activeVoice === 'Fenrir' 
                ? 'bg-blue-900/40 text-blue-400 border-blue-500/30' 
                : 'bg-purple-900/40 text-purple-400 border-purple-500/30'
            }`}
            title="Toggle Voice: Charon (Deep), Fenrir (Mid), Kore (Female). Changes apply on next connect."
          >
            <User className="w-3 h-3" />
            {activeVoice === 'Charon' ? 'JARVIS (Deep)' : activeVoice === 'Fenrir' ? 'JARVIS (Mid)' : 'FRIDAY'}
          </button>
        </div>
      </div>

      {/* Onboarding Modal */}
      {showOnboarding && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] p-4">
          <div className="bg-[#1a1a1a] border border-[#333333] rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h2 className="text-2xl font-bold text-white mb-2">Welcome to MUKE</h2>
            <p className="text-[#aaaaaa] text-sm mb-6">
              To personalize your experience, please provide your name and email. 
              <br/><br/>
              <span className="text-yellow-500 font-medium">Security Note:</span> We will <b>never</b> ask for your Gmail password. Asking for email passwords is a major security risk.
            </p>
            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#888888] mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={onboardName}
                  onChange={e => setOnboardName(e.target.value)}
                  className="w-full bg-[#222222] border border-[#444444] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500"
                  placeholder="e.g. John Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#888888] mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={onboardEmail}
                  onChange={e => setOnboardEmail(e.target.value)}
                  className="w-full bg-[#222222] border border-[#444444] rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500"
                  placeholder="e.g. john@gmail.com"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg transition-colors mt-4"
              >
                Save & Continue
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Top Left Buttons */}
      <div className="absolute top-4 left-4 flex flex-col gap-2.5 z-50">
        {/* 🌅 Daily Morning Briefing Button */}
        <button
          onClick={() => triggerDailyBriefing()}
          disabled={isBriefingLoading}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-full transition-all shadow-lg ${
            isBriefingLoading
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
              : 'bg-gradient-to-r from-amber-600/90 to-orange-600/90 hover:from-amber-500 hover:to-orange-500 text-white shadow-[0_0_15px_rgba(245,158,11,0.3)]'
          }`}
          title="🌅 Daily Morning Briefing: Local time, live weather forecast, pending tasks & energizing quotes"
        >
          <Sun className={`w-4 h-4 text-amber-200 ${isBriefingLoading ? 'animate-spin' : ''}`} />
          <span className="font-medium text-xs">{isBriefingLoading ? "Briefing..." : "Daily Briefing"}</span>
        </button>

        {/* 👁️ Look At This / Vision Assistant Button */}
        <button
          onClick={() => setShowVisionModal(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-teal-600/90 to-cyan-600/90 hover:from-teal-500 hover:to-cyan-500 text-white px-3.5 py-2 rounded-full transition-all shadow-lg shadow-[0_0_15px_rgba(20,184,166,0.3)]"
          title="👁️ Look At This: AI camera & screen vision to debug code, solve math problems, or identify objects"
        >
          <Eye className="w-4 h-4 text-cyan-200" />
          <span className="font-medium text-xs">Look At This</span>
        </button>

        <button
          onClick={() => setShowTasks(!showTasks)}
          className="flex items-center gap-2 bg-[#222222] hover:bg-[#333333] text-white px-3.5 py-2 rounded-full transition-colors shadow-lg text-xs"
        >
          <CheckSquare className="w-4 h-4" />
          <span className="font-medium">Tasks</span>
        </button>
        <button
          onClick={() => setShowNotes(!showNotes)}
          className="flex items-center gap-2 bg-[#222222] hover:bg-[#333333] text-white px-3.5 py-2 rounded-full transition-colors shadow-lg text-xs"
        >
          <BookOpen className="w-4 h-4" />
          <span className="font-medium">Notes</span>
        </button>
        <button
          onClick={() => setShowAgiModal(true)}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-full transition-all shadow-lg text-xs ${
            agiAutonomousActive 
              ? 'bg-gradient-to-r from-purple-900/90 to-indigo-900/90 border border-purple-500/50 text-white shadow-[0_0_20px_rgba(168,85,247,0.4)]' 
              : 'bg-[#222222] hover:bg-[#333333] text-[#888888] hover:text-white'
          }`}
          title="Autonomous AGI: Automatically chats with you without instructions"
        >
          <Brain className={`w-4 h-4 ${agiAutonomousActive ? 'text-purple-400 animate-pulse' : ''}`} />
          <span className="font-medium">AGI Auto-Chat</span>
          {agiAutonomousActive && (
            <span className="text-[10px] font-mono bg-purple-500/30 text-purple-200 px-1.5 py-0.5 rounded-full border border-purple-400/30">
              {isAgiThinking ? '...' : `${agiCountdown}s`}
            </span>
          )}
        </button>
        <button
          onClick={() => setShowSettings(!showSettings)}
          className="flex items-center gap-2 bg-[#222222] hover:bg-[#333333] text-white px-3.5 py-2 rounded-full transition-colors shadow-lg text-xs"
        >
          <Settings className="w-4 h-4" />
          <span className="font-medium">Settings</span>
        </button>
        <button
          onClick={() => setShowInfo(!showInfo)}
          className="flex items-center gap-2 bg-[#222222] hover:bg-[#333333] text-white px-3.5 py-2 rounded-full transition-colors shadow-lg text-xs"
        >
          <Info className="w-4 h-4" />
          <span className="font-medium">Boundaries</span>
        </button>
      </div>

      {/* Autonomous AGI Engine Cockpit Modal */}
      {showAgiModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-[100] p-4">
          <div className="bg-[#121216] border border-purple-500/30 rounded-2xl w-full max-w-lg shadow-[0_0_50px_rgba(168,85,247,0.25)] overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-purple-500/20 bg-gradient-to-r from-purple-950/60 to-indigo-950/40">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 shadow-[0_0_15px_rgba(168,85,247,0.3)]">
                  <Brain className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white flex items-center gap-2">
                    MUKE Autonomous AGI Engine
                    <span className="text-[10px] font-mono uppercase bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full border border-purple-500/30">
                      Self-Initiating
                    </span>
                  </h2>
                  <p className="text-xs text-[#999]">Automatically initiates chats with you without any instructions</p>
                </div>
              </div>
              <button 
                onClick={() => setShowAgiModal(false)} 
                className="w-7 h-7 rounded-full bg-white/5 hover:bg-white/10 text-[#888] hover:text-white flex items-center justify-center text-sm transition-colors"
              >
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-5 custom-scrollbar text-left text-sm">
              {/* Status Banner */}
              <div className={`p-4 rounded-xl border flex items-center justify-between transition-all ${
                agiAutonomousActive 
                  ? 'bg-purple-950/30 border-purple-500/30 text-purple-200' 
                  : 'bg-[#181818] border-white/10 text-[#777]'
              }`}>
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${agiAutonomousActive ? 'bg-purple-400 animate-ping' : 'bg-[#555]'}`} />
                  <div>
                    <p className="text-xs font-semibold text-white">
                      {agiAutonomousActive ? "Autonomous Mind Active & Observing" : "Autonomous Mind Paused"}
                    </p>
                    <p className="text-[11px] text-[#aaa]">
                      {agiAutonomousActive 
                        ? (isAgiThinking ? "Formulating spontaneous idea..." : `Next spontaneous conversation in ${agiCountdown} seconds`)
                        : "Turn on below to let MUKE chat with you automatically"}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => triggerAutonomousAgiThought(true)}
                  className="bg-purple-600 hover:bg-purple-500 active:scale-95 text-white px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shadow-md flex items-center gap-1.5"
                  title="Force AGI to speak now"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>Speak Now</span>
                </button>
              </div>

              {/* Master Toggle */}
              <div className="flex items-center justify-between bg-[#18181c] p-4 rounded-xl border border-white/5">
                <div>
                  <h3 className="text-sm font-semibold text-white flex items-center gap-1.5">
                    <Radio className="w-4 h-4 text-purple-400" /> Auto-Initiate Conversation
                  </h3>
                  <p className="text-xs text-[#888] mt-0.5">
                    AGI will periodically start conversations, check in on your day, and share ideas without any prompting.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setAgiAutonomousActive(!agiAutonomousActive)}
                  className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    agiAutonomousActive ? 'bg-purple-600' : 'bg-[#333]'
                  }`}
                >
                  <span
                    className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition duration-200 ease-in-out ${
                      agiAutonomousActive ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Voice Vocalization Toggle */}
              <div className="flex items-center justify-between bg-[#18181c] p-4 rounded-xl border border-white/5">
                <div>
                  <h3 className="text-sm font-semibold text-white flex items-center gap-1.5">
                    <Volume2 className="w-4 h-4 text-blue-400" /> Speak Spontaneous Thoughts Aloud
                  </h3>
                  <p className="text-xs text-[#888] mt-0.5">
                    Uses neural speech synthesis to read thoughts aloud so you hear the AGI chatting with you.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setAgiAutoVoice(!agiAutoVoice)}
                  className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    agiAutoVoice ? 'bg-blue-600' : 'bg-[#333]'
                  }`}
                >
                  <span
                    className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition duration-200 ease-in-out ${
                      agiAutoVoice ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Autonomous Cadence Selector */}
              <div>
                <label className="block text-xs font-semibold text-[#aaa] uppercase tracking-wider mb-2">
                  Conversation Cadence (Interval)
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { label: '15s', desc: 'Fast', sec: 15 },
                    { label: '25s', desc: 'Active', sec: 25 },
                    { label: '45s', desc: 'Balanced', sec: 45 },
                    { label: '90s', desc: 'Relaxed', sec: 90 }
                  ].map(cadence => (
                    <button
                      key={cadence.sec}
                      type="button"
                      onClick={() => {
                        setAgiIntervalSeconds(cadence.sec);
                        setAgiCountdown(cadence.sec);
                      }}
                      className={`p-2.5 rounded-xl border text-center transition-all ${
                        agiIntervalSeconds === cadence.sec
                          ? 'bg-purple-600/20 border-purple-500 text-purple-200 shadow-[0_0_15px_rgba(168,85,247,0.2)]'
                          : 'bg-[#18181c] border-white/5 text-[#888] hover:text-white hover:bg-[#202026]'
                      }`}
                    >
                      <div className="font-bold text-sm text-white">{cadence.label}</div>
                      <div className="text-[10px] text-[#aaa]">{cadence.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Persona Selector */}
              <div>
                <label className="block text-xs font-semibold text-[#aaa] uppercase tracking-wider mb-2">
                  Autonomous Personality & Style
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  {[
                    { 
                      id: 'companion', 
                      title: '🌟 Warm Companion', 
                      desc: 'Friendly check-ins, asking about your day, supportive conversation.' 
                    },
                    { 
                      id: 'intellect', 
                      title: '💡 Deep Intellect', 
                      desc: 'Ponders quantum physics, AGI breakthroughs, and consciousness.' 
                    },
                    { 
                      id: 'productivity', 
                      title: '🎯 Productivity Wingman', 
                      desc: 'Proactively checks your tasks, motivation, and focus rhythm.' 
                    },
                    { 
                      id: 'curious', 
                      title: '⚡ Curious Spark', 
                      desc: 'Spontaneous thought experiments and unexpected dilemmas.' 
                    }
                  ].map(p => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setAgiPersona(p.id as any)}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        agiPersona === p.id 
                          ? 'bg-purple-600/20 border-purple-500/80 text-white shadow-[0_0_20px_rgba(168,85,247,0.25)]' 
                          : 'bg-[#18181c] border-white/5 text-[#888] hover:text-white hover:bg-[#202026]'
                      }`}
                    >
                      <div className="font-semibold text-xs text-white mb-1">{p.title}</div>
                      <div className="text-[11px] text-[#aaa] leading-snug">{p.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="p-4 bg-[#141418] border-t border-white/5 flex gap-3">
              <button
                type="button"
                onClick={() => {
                  triggerAutonomousAgiThought(true);
                  setShowAgiModal(false);
                }}
                className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 active:scale-[0.99] text-white font-semibold py-2.5 rounded-xl text-xs transition-all shadow-lg shadow-purple-500/20 flex items-center justify-center gap-2"
              >
                <Zap className="w-4 h-4" />
                <span>Spark AGI Conversation Right Now</span>
              </button>
              <button
                type="button"
                onClick={() => setShowAgiModal(false)}
                className="px-4 py-2.5 rounded-xl bg-[#222] hover:bg-[#333] text-white text-xs font-medium transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Info/Boundaries Modal */}
      {showInfo && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] p-4">
          <div className="bg-[#1a1a1a] border border-[#333333] rounded-2xl p-6 w-full max-w-lg shadow-2xl relative max-h-[85vh] overflow-y-auto custom-scrollbar">
            <button onClick={() => setShowInfo(false)} className="absolute top-4 right-4 text-[#888] hover:text-white">
              ✕
            </button>
            <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
              <Info className="w-6 h-6 text-blue-500" /> Capabilities & Boundaries
            </h2>
            <p className="text-[#aaaaaa] text-sm mb-6">Understand what your AI Assistant can and cannot do.</p>
            
            <div className="space-y-6 text-sm text-[#cccccc]">
              <div>
                <h3 className="font-bold text-white text-base mb-1">🌍 Modifying Other Websites</h3>
                <p>The AI can generate direct links and open new tabs (like Spotify or YouTube) for you, but browser security architecture prevents the script from natively injecting controls into other random tabs you have open (e.g., the AI can't pause the video if YouTube is playing in another tab).</p>
              </div>

              <div>
                <h3 className="font-bold text-white text-base mb-1">🖱️ Simulating Keyboard/Mouse Input</h3>
                <p>We cannot create macros that move your actual mouse cursor or type text into other applications. This application runs inside a web browser sandbox.</p>
              </div>

              <div>
                <h3 className="font-bold text-white text-base mb-1">💻 Native Operating System Control</h3>
                <p>The AI cannot change your device's brightness, turn off Wi-Fi, open local desktop applications (unless they support custom URI links), or shut down your computer. Web apps are heavily isolated from the host OS.</p>
              </div>

              <div>
                <h3 className="font-bold text-white text-base mb-1">😴 Background Listening (When Closed)</h3>
                <p>If you close the browser tab or minimize the browser on a mobile device, the app goes to sleep. We cannot run a continuous 24/7 background process that listens for a wake word (like "Hey Siri") while the app is closed.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Compact Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-white/5 bg-[#181818]">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400">
                  <Sliders className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-white">Settings</h2>
                  <p className="text-xs text-[#888888]">Customize profile & voice</p>
                </div>
              </div>
              <button 
                onClick={() => setShowSettings(false)} 
                className="w-7 h-7 rounded-full bg-white/5 hover:bg-white/10 text-[#888] hover:text-white flex items-center justify-center text-sm transition-colors"
              >
                ✕
              </button>
            </div>

            {/* Compact Tabs */}
            <div className="flex border-b border-white/5 bg-[#121212] px-4 pt-2 gap-2">
              <button
                type="button"
                onClick={() => setSettingsTab('profile')}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium border-b-2 transition-colors ${
                  settingsTab === 'profile' 
                    ? 'border-blue-500 text-blue-400' 
                    : 'border-transparent text-[#777777] hover:text-[#aaaaaa]'
                }`}
              >
                <User className="w-3.5 h-3.5" /> Profile
              </button>
              <button
                type="button"
                onClick={() => setSettingsTab('voice')}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium border-b-2 transition-colors ${
                  settingsTab === 'voice' 
                    ? 'border-blue-500 text-blue-400' 
                    : 'border-transparent text-[#777777] hover:text-[#aaaaaa]'
                }`}
              >
                <Volume2 className="w-3.5 h-3.5" /> Audio & Voice
              </button>
              <button
                type="button"
                onClick={() => setSettingsTab('prefs')}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium border-b-2 transition-colors ${
                  settingsTab === 'prefs' 
                    ? 'border-blue-500 text-blue-400' 
                    : 'border-transparent text-[#777777] hover:text-[#aaaaaa]'
                }`}
              >
                <Settings className="w-3.5 h-3.5" /> Display & Sound
              </button>
              <button
                type="button"
                onClick={() => setSettingsTab('agi')}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium border-b-2 transition-colors ${
                  settingsTab === 'agi' 
                    ? 'border-purple-500 text-purple-400' 
                    : 'border-transparent text-[#777777] hover:text-[#aaaaaa]'
                }`}
              >
                <Brain className="w-3.5 h-3.5" /> AGI Auto
              </button>
            </div>
            
            <form onSubmit={handleSaveSettings} className="flex-1 overflow-y-auto p-5 space-y-4 text-left custom-scrollbar">
              {settingsTab === 'profile' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Full Name</label>
                    <input
                      type="text"
                      required
                      value={settingsName}
                      onChange={e => setSettingsName(e.target.value)}
                      placeholder="Your Name"
                      className="w-full bg-[#1e1e1e] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-[#555] focus:outline-none focus:border-blue-500 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Email Address</label>
                    <input
                      type="email"
                      required
                      value={settingsEmail}
                      onChange={e => setSettingsEmail(e.target.value)}
                      placeholder="user@example.com"
                      className="w-full bg-[#1e1e1e] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-[#555] focus:outline-none focus:border-blue-500 transition-colors"
                    />
                  </div>
                </div>
              )}

              {settingsTab === 'voice' && (
                <div className="space-y-3.5">
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs font-medium text-[#aaaaaa]">AI Voice Language (Strict Response Language)</label>
                      <span className="text-xs font-mono text-blue-400 bg-blue-500/10 px-1.5 py-0.5 rounded uppercase">
                        {settingsAiLanguage === 'hi' ? 'Hindi (हिन्दी)' : settingsAiLanguage === 'ur' ? 'Urdu (اردو)' : 'English'}
                      </span>
                    </div>
                    <select
                      value={settingsAiLanguage}
                      onChange={e => setSettingsAiLanguage(e.target.value as 'en' | 'hi' | 'ur')}
                      className="w-full bg-[#1e1e1e] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                    >
                      <option value="en">English (AI only talks & replies in English)</option>
                      <option value="hi">Hindi - हिन्दी (AI only talks & replies in Hindi)</option>
                      <option value="ur">Urdu - اردو (AI only talks & replies in Urdu)</option>
                    </select>
                    <p className="text-[11px] text-[#777] mt-1">
                      Restricts the AI to exclusively speak and respond in your selected language.
                    </p>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs font-medium text-[#aaaaaa]">TTS & Master Volume</label>
                      <span className="text-xs font-mono text-blue-400 bg-blue-500/10 px-1.5 py-0.5 rounded">
                        {Math.round(settingsMasterVolume * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0" max="1" step="0.05"
                      value={settingsMasterVolume}
                      onChange={e => setSettingsMasterVolume(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-[#222] rounded-lg appearance-none cursor-pointer accent-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Native Speech Voice</label>
                    <select 
                      value={settingsTtsVoice}
                      onChange={e => setSettingsTtsVoice(e.target.value)}
                      className="w-full bg-[#1e1e1e] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 appearance-none"
                    >
                      <option value="">Jarvis AI Default (Recommended)</option>
                      {availableVoices.map((voice, idx) => (
                        <option key={idx} value={voice.name}>
                          {voice.name} ({voice.lang})
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div className="bg-[#1a1a1a] p-2.5 rounded-lg border border-white/5">
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-xs font-medium text-[#888]">Pitch</label>
                        <span className="text-[11px] font-mono text-blue-400">{settingsTtsPitch.toFixed(1)}</span>
                      </div>
                      <input
                        type="range"
                        min="0.4" max="1.6" step="0.1"
                        value={settingsTtsPitch}
                        onChange={e => setSettingsTtsPitch(parseFloat(e.target.value))}
                        className="w-full h-1.5 bg-[#262626] rounded-lg appearance-none cursor-pointer accent-blue-500"
                      />
                    </div>
                    <div className="bg-[#1a1a1a] p-2.5 rounded-lg border border-white/5">
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-xs font-medium text-[#888]">Rate</label>
                        <span className="text-[11px] font-mono text-blue-400">{settingsTtsRate.toFixed(1)}x</span>
                      </div>
                      <input
                        type="range"
                        min="0.6" max="1.8" step="0.1"
                        value={settingsTtsRate}
                        onChange={e => setSettingsTtsRate(parseFloat(e.target.value))}
                        className="w-full h-1.5 bg-[#262626] rounded-lg appearance-none cursor-pointer accent-blue-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {settingsTab === 'prefs' && (
                <div className="space-y-3.5">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Clock Display</label>
                      <select 
                        value={settingsTimeFormat}
                        onChange={e => setSettingsTimeFormat(e.target.value as '12h' | '24h')}
                        className="w-full bg-[#1e1e1e] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 appearance-none"
                      >
                        <option value="12h">12-Hour (AM/PM)</option>
                        <option value="24h">24-Hour (Military)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Waveform Style</label>
                      <select 
                        value={settingsWaveformColor}
                        onChange={e => setSettingsWaveformColor(e.target.value as 'blue' | 'purple' | 'green' | 'teal')}
                        className="w-full bg-[#1e1e1e] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 appearance-none capitalize"
                      >
                        <option value="blue">Cyan Blue</option>
                        <option value="purple">Cosmic Purple</option>
                        <option value="green">Neon Green</option>
                        <option value="teal">Cyber Teal</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 pt-1 bg-[#1a1a1a] p-2.5 rounded-lg border border-white/5">
                    <input
                      type="checkbox"
                      id="sfxToggle"
                      checked={settingsSfxEnabled}
                      onChange={e => setSettingsSfxEnabled(e.target.checked)}
                      className="w-4 h-4 text-blue-500 bg-[#222] border-white/10 rounded focus:ring-blue-500 cursor-pointer"
                    />
                    <label htmlFor="sfxToggle" className="text-xs font-medium text-[#ccc] cursor-pointer">
                      Audio Notification Chimes
                    </label>
                  </div>
                </div>
              )}

              {settingsTab === 'agi' && (
                <div className="space-y-3.5">
                  <div className="flex items-center justify-between bg-[#1a1a1a] p-3 rounded-lg border border-white/5">
                    <div>
                      <label className="block text-xs font-semibold text-white">Autonomous AGI Chat</label>
                      <p className="text-[11px] text-[#888]">Initiates conversations automatically without any instructions</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={agiAutonomousActive}
                      onChange={e => setAgiAutonomousActive(e.target.checked)}
                      className="w-4 h-4 text-purple-600 bg-[#222] border-white/10 rounded cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between bg-[#1a1a1a] p-3 rounded-lg border border-white/5">
                    <div>
                      <label className="block text-xs font-semibold text-white">Voice Vocalization</label>
                      <p className="text-[11px] text-[#888]">Speaks spontaneous thoughts aloud using TTS</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={agiAutoVoice}
                      onChange={e => setAgiAutoVoice(e.target.checked)}
                      className="w-4 h-4 text-blue-600 bg-[#222] border-white/10 rounded cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Cadence / Frequency</label>
                    <select
                      value={agiIntervalSeconds}
                      onChange={e => {
                        const sec = parseInt(e.target.value);
                        setAgiIntervalSeconds(sec);
                        setAgiCountdown(sec);
                      }}
                      className="w-full bg-[#1e1e1e] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                    >
                      <option value={15}>Fast (Every 15s - lively dialogue)</option>
                      <option value={25}>Active (Every 25s - recommended)</option>
                      <option value={45}>Balanced (Every 45s)</option>
                      <option value={90}>Relaxed (Every 90s)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#aaaaaa] mb-1">Personality / Tone</label>
                    <select
                      value={agiPersona}
                      onChange={e => setAgiPersona(e.target.value as any)}
                      className="w-full bg-[#1e1e1e] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                    >
                      <option value="companion">Warm Companion (Friendly check-ins)</option>
                      <option value="intellect">Deep Intellect (AI & science breakthroughs)</option>
                      <option value="productivity">Productivity Wingman (Tasks & momentum)</option>
                      <option value="curious">Curious Spark (Thought experiments)</option>
                    </select>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      triggerAutonomousAgiThought(true);
                      setShowSettings(false);
                    }}
                    className="w-full bg-purple-600 hover:bg-purple-500 active:scale-[0.99] text-white py-2 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1.5 shadow-md shadow-purple-500/20"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Spark Autonomous Chat Right Now</span>
                  </button>
                </div>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-500 active:scale-[0.99] text-white font-medium py-2 rounded-xl text-xs transition-all shadow-lg shadow-blue-500/20"
                >
                  Save Settings
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Task Sidebar/Dropdown */}
      {showTasks && (
        <div className="absolute top-32 left-4 w-80 bg-[#0a0a0a]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-[0_0_30px_rgba(0,0,0,0.5)] z-40 text-left transition-all">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-white font-bold text-lg tracking-wide">Tasks Pipeline</h2>
            <ListTodo className="w-5 h-5 text-blue-400" />
          </div>
          
          <form onSubmit={handleManualAddTask} className="mb-5 space-y-3">
            <div className="flex flex-col gap-2">
              <input
                type="text"
                value={newTaskTitle}
                onChange={e => setNewTaskTitle(e.target.value)}
                placeholder="What needs to be done?"
                className="w-full bg-[#111111]/80 border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/50 transition-all placeholder-[#555]"
              />
              <div className="flex gap-2">
                <input
                  type="datetime-local"
                  value={newTaskReminder}
                  onChange={e => setNewTaskReminder(e.target.value)}
                  className="flex-1 bg-[#111111]/80 border border-white/10 rounded-lg px-3 py-2 text-[#cccccc] text-xs focus:outline-none focus:border-blue-500/50"
                  title="Optional Reminder"
                />
                <button type="submit" disabled={!newTaskTitle.trim()} className="bg-blue-600/90 hover:bg-blue-500 disabled:opacity-50 text-white px-4 py-2 rounded-lg text-sm font-medium transition-all shadow-[0_0_15px_rgba(37,99,235,0.3)]">
                  Add
                </button>
              </div>
            </div>
          </form>

          {tasks.length === 0 ? (
            <div className="text-center py-8 bg-[#111]/40 rounded-xl border border-white/5">
              <CheckSquare className="w-8 h-8 text-[#444] mx-auto mb-2" />
              <p className="text-[#666666] text-sm">No active tasks</p>
            </div>
          ) : (
            <ul className="space-y-2 max-h-[50vh] overflow-y-auto pr-2 custom-scrollbar">
              {tasks.map(t => (
                <li key={t.id} className={`flex items-start gap-3 bg-[#111111]/60 border border-white/5 hover:border-white/10 rounded-xl p-3 relative group transition-all ${t.completed ? 'opacity-60' : ''}`}>
                  <button onClick={() => {
                        setTasks(prev => prev.map(task => task.id === t.id ? { ...task, completed: !task.completed } : task));
                      }} className="mt-1 flex-shrink-0">
                    {t.completed ? <CheckSquare className="w-4 h-4 text-emerald-500" /> : <div className="w-4 h-4 rounded border-2 border-[#555] group-hover:border-blue-400 transition-colors" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <span className={`block text-sm font-medium ${t.completed ? "line-through text-[#777]" : "text-[#eaeaea]"}`}>
                      {t.title}
                    </span>
                    {t.reminderTime && (
                      <span className={`text-[10px] mt-1 font-mono uppercase tracking-wider flex items-center gap-1 ${t.completed ? "text-[#555]" : "text-blue-400/80"}`}>
                        <Clock className="w-3 h-3" /> {new Date(t.reminderTime).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                      </span>
                    )}
                  </div>
                  <button 
                    onClick={() => removeTask(t.id)}
                    className="p-1.5 text-[#555] hover:text-red-400 hover:bg-red-400/10 rounded-md transition-all opacity-0 group-hover:opacity-100 absolute right-2 top-2"
                    title="Delete task"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {/* Notes Sidebar/Dropdown */}
      {showNotes && (
        <div className="absolute top-32 left-4 w-80 bg-[#0a0a0a]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-[0_0_30px_rgba(0,0,0,0.5)] z-40 text-left transition-all">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-white font-bold text-lg tracking-wide">Brain Dump</h2>
            <BookOpen className="w-5 h-5 text-purple-400" />
          </div>
          
          <form onSubmit={handleManualAddNote} className="mb-5">
            <div className="flex gap-2">
              <input
                type="text"
                value={newNoteText}
                onChange={e => setNewNoteText(e.target.value)}
                placeholder="Log a thought..."
                className="flex-1 bg-[#111111]/80 border border-white/10 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-purple-500/50 focus:ring-1 focus:ring-purple-500/50 transition-all placeholder-[#555]"
              />
              <button type="submit" disabled={!newNoteText.trim()} className="bg-purple-600/90 hover:bg-purple-500 disabled:opacity-50 text-white px-4 py-2 rounded-lg text-sm font-medium transition-all shadow-[0_0_15px_rgba(147,51,234,0.3)]">
                Log
              </button>
            </div>
          </form>

          {notes.length === 0 ? (
            <div className="text-center py-8 bg-[#111]/40 rounded-xl border border-white/5">
              <BookOpen className="w-8 h-8 text-[#444] mx-auto mb-2" />
              <p className="text-[#666666] text-sm">No logs recorded</p>
            </div>
          ) : (
            <ul className="space-y-3 max-h-[50vh] overflow-y-auto pr-2 custom-scrollbar">
              {notes.map(n => (
                <li key={n.id} className="bg-[#111111]/60 border border-white/5 hover:border-white/10 rounded-xl p-4 text-sm relative group transition-all">
                  <p className="text-[#dddddd] mb-3 leading-relaxed pr-6">{n.text}</p>
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/5">
                    <span className="text-[10px] font-mono text-[#666666] uppercase tracking-wider">
                      {new Date(n.date).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                    </span>
                  </div>
                  <button 
                    onClick={() => removeNote(n.id)}
                    className="absolute top-3 right-3 p-1.5 text-[#555] hover:text-red-400 hover:bg-red-400/10 rounded-md transition-all opacity-0 group-hover:opacity-100"
                    title="Delete note"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      <div className="text-center space-y-3 pt-12">
        <h1 className="text-4xl font-bold tracking-tight text-white">MUKE</h1>
        <p className="text-[#888888] text-sm">Powered by ASAD ARIS</p>
      </div>

      {/* Dynamic Voice Visualizer */}
      <div className="relative flex items-center justify-center w-80 h-80 my-8">
        {(isConnected || isSpeaking || isDictating) && (
          <div className="absolute inset-0 z-0 pointer-events-none">
            {isSpeaking ? (
              <div className="absolute inset-0 flex items-center justify-center gap-1.5 opacity-90">
                {[...Array(12)].map((_, i) => (
                  <div 
                    key={i}
                    className={`w-2 rounded-full shadow-[0_0_15px_currentColor] animate-audio-bar ${
                      userProfile?.preferences?.waveformColor === 'teal' ? 'bg-teal-500 text-teal-500' :
                      userProfile?.preferences?.waveformColor === 'green' ? 'bg-green-500 text-green-500' :
                      userProfile?.preferences?.waveformColor === 'purple' ? 'bg-purple-500 text-purple-500' :
                      'bg-blue-500 text-blue-500'
                    }`}
                    style={{
                      height: '40px',
                      animationDelay: `${i * 0.05}s`
                    }}
                  />
                ))}
              </div>
            ) : isDictating ? (
              // Listening pulse animation reacting to user voice volume
              <>
                <div 
                  className="absolute inset-0 rounded-full border border-red-500/40 bg-red-500/10 transition-transform duration-75 ease-out animate-[ping_2s_cubic-bezier(0,0,0.2,1)_infinite]" 
                  style={{ transform: `scale(${0.75 + audioLevel * 0.45})` }}
                />
                <div 
                  className="absolute inset-0 rounded-full border border-red-500/20 bg-red-500/5 transition-transform duration-100 ease-out delay-150 animate-[ping_2.5s_cubic-bezier(0,0,0.2,1)_infinite]" 
                  style={{ transform: `scale(${0.5 + audioLevel * 0.35})` }}
                />
              </>
            ) : (
              // Idle state circles
              <>
                <div className={`absolute inset-0 rounded-full border border-blue-500/20 bg-blue-500/5 transition-all duration-[3000ms] ease-out scale-50 opacity-100 animate-[ping_3s_cubic-bezier(0,0,0.2,1)_infinite]`} />
                <div className={`absolute inset-0 rounded-full border border-purple-500/20 bg-purple-500/5 transition-all duration-[2500ms] delay-300 ease-out scale-50 opacity-100 animate-[ping_2.5s_cubic-bezier(0,0,0.2,1)_infinite]`} />
                <div className={`absolute inset-0 rounded-full border border-cyan-500/20 bg-cyan-500/5 transition-all duration-[2000ms] delay-700 ease-out scale-50 opacity-100 animate-[ping_2s_cubic-bezier(0,0,0.2,1)_infinite]`} />
              </>
            )}
          </div>
        )}
        
        {isDictating && (
          <div className="absolute -top-7 bg-[#161616]/95 border border-red-500/50 text-red-200 text-xs px-4 py-1.5 rounded-full shadow-2xl backdrop-blur-md animate-in fade-in zoom-in-95 duration-200 max-w-[300px] truncate text-center z-20 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping inline-block" />
            <span className="truncate">{commandText ? `"${commandText}"` : "Listening to your voice..."}</span>
          </div>
        )}
        
        <div className="absolute flex gap-6 z-10 bottom-[-60px]">
          <button
            onClick={() => handleMicButtonClick()}
            disabled={isConnecting}
            className={`relative w-28 h-28 rounded-full flex items-center justify-center transition-all duration-500 hover:scale-110 active:scale-95 ${
              isConnected || isDictating 
                ? 'bg-[#050505] border-2 border-blue-500/50 shadow-[0_0_50px_rgba(59,130,246,0.5),inset_0_0_30px_rgba(59,130,246,0.3)] text-blue-400' 
                : isSpeaking
                ? 'bg-[#050505] border-2 border-purple-500/50 shadow-[0_0_50px_rgba(168,85,247,0.5),inset_0_0_30px_rgba(168,85,247,0.3)] text-purple-400'
                : 'bg-[#0a0a0a]/80 backdrop-blur-xl border border-white/10 text-[#888] hover:text-white'
            }`}
            title={
              isSpeaking
                ? "Tap to pause speaking"
                : isConnected || isDictating
                ? "Stop voice listening"
                : "Tap to speak to MUKE"
            }
          >
            {isConnecting ? (
              <Activity className="w-12 h-12 text-blue-400 animate-pulse" />
            ) : isSpeaking ? (
              <Volume2 className="w-12 h-12 text-purple-400 animate-pulse drop-shadow-[0_0_15px_rgba(168,85,247,1)]" />
            ) : isDictating ? (
              <Mic className="w-12 h-12 text-red-400 animate-pulse drop-shadow-[0_0_15px_rgba(239,68,68,1)]" />
            ) : isConnected ? (
              <Mic className="w-12 h-12 text-blue-400 drop-shadow-[0_0_15px_rgba(59,130,246,1)]" />
            ) : (
              <Mic className="w-12 h-12" />
            )}
          </button>
          
          <div className="relative">
            <button
              onClick={() => setVisionMenuOpen(!visionMenuOpen)}
              className={`relative w-28 h-28 rounded-full flex items-center justify-center transition-all duration-500 hover:scale-110 active:scale-95 z-10 ${
                isCameraOn || isScreenSharing ? 'bg-[#050505] border-2 border-teal-500/50 shadow-[0_0_50px_rgba(20,184,166,0.5),inset_0_0_30px_rgba(20,184,166,0.3)] text-teal-400' : 'bg-[#0a0a0a]/80 backdrop-blur-xl text-[#888] hover:text-white border border-white/10'
              }`}
              title="AI Vision Options"
            >
              {isCameraOn || isScreenSharing ? <Camera className="w-12 h-12 text-teal-400 animate-pulse drop-shadow-[0_0_15px_rgba(20,184,166,1)]" /> : <CameraOff className="w-12 h-12" />}
            </button>

            {visionMenuOpen && (
              <div className="absolute bottom-[110px] left-1/2 -translate-x-1/2 flex flex-col gap-2 bg-[#1a1a1a] p-2 rounded-xl border border-[#333333] shadow-2xl z-50 min-w-[160px]">
                <button
                  onClick={() => {
                    setVisionMenuOpen(false);
                    toggleCamera();
                  }}
                  className={`flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                    isCameraOn ? 'bg-teal-500/20 text-teal-400' : 'hover:bg-[#2a2a2a] text-white'
                  }`}
                >
                  {isCameraOn ? <CameraOff className="w-4 h-4" /> : <Camera className="w-4 h-4" />}
                  {isCameraOn ? 'Stop Camera' : 'Web Camera'}
                </button>
                <div className="h-[1px] bg-[#333333] w-full" />
                <button
                  onClick={() => {
                    setVisionMenuOpen(false);
                    toggleScreenShare();
                  }}
                  className={`flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                    isScreenSharing ? 'bg-indigo-500/20 text-indigo-400' : 'hover:bg-[#2a2a2a] text-white'
                  }`}
                >
                  {isScreenSharing ? <MonitorOff className="w-4 h-4" /> : <MonitorUp className="w-4 h-4" />}
                  {isScreenSharing ? 'Stop Screen' : 'Desktop Screen'}
                </button>
                <div className="h-[1px] bg-[#333333] w-full" />
                <button
                  onClick={() => {
                    setVisionMenuOpen(false);
                    setShowVisionModal(true);
                  }}
                  className="flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-medium transition-colors hover:bg-[#2a2a2a] text-cyan-400"
                >
                  <Eye className="w-4 h-4 text-cyan-400" />
                  <span>Look At This (Inspect)</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="text-center mt-12 min-h-[44px] flex flex-col items-center justify-center">
        <p className="text-sm transition-all font-medium flex items-center justify-center gap-2">
          {isAgiThinking ? (
            <span className="text-purple-400 flex items-center gap-1.5 animate-pulse">
              <Brain className="w-4 h-4 animate-pulse text-purple-400" /> MUKE is formulating a spontaneous thought...
            </span>
          ) : isCommanding ? (
            <span className="text-blue-400 flex items-center gap-1.5 animate-pulse">
              <RefreshCw className="w-4 h-4 animate-spin text-blue-400" /> MUKE is analyzing & answering...
            </span>
          ) : isSpeaking ? (
            <span className="text-purple-400 flex items-center gap-1.5 animate-pulse">
              <Volume2 className="w-4 h-4 text-purple-400" /> MUKE is speaking... (Tap Mic to pause)
            </span>
          ) : isDictating ? (
            <span className="text-red-400 flex items-center gap-1.5 animate-pulse">
              <Mic className="w-4 h-4 text-red-400" /> 🎤 Listening to your voice... (Speak now)
            </span>
          ) : isConnecting ? (
            <span className="text-yellow-400 flex items-center gap-1.5 animate-pulse">
              <Activity className="w-4 h-4 text-yellow-400" /> Connecting audio stream...
            </span>
          ) : isConnected ? (
            <span className="text-teal-400 flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-teal-400 animate-pulse" />
              {isCameraOn || isScreenSharing ? 'Live AI Vision & Audio Active' : 'Live Voice Session Active • Tap Mic to end'}
            </span>
          ) : agiAutonomousActive ? (
            <span className="text-purple-300 flex items-center gap-1.5">
              <Brain className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
              AGI Autonomous Active • Auto-chatting in {agiCountdown}s
            </span>
          ) : (
            <span className="text-[#888888]">
              Tap Mic to speak, Camera or Screen for AI Vision
            </span>
          )}
        </p>
        {error && <p className="text-red-500 text-xs mt-1.5">{error}</p>}
      </div>

      <div className="w-full max-w-md pt-8">
        <form onSubmit={(e) => handleCommandSubmit(e)} className="relative">
          <div className="relative flex items-center">
            <input
              type="text"
              value={commandText}
              onChange={(e) => setCommandText(e.target.value)}
              placeholder={isDictating ? "Listening..." : "Type or dictate a prompt..."}
              disabled={isCommanding}
              className="w-full bg-[#161616] border border-white/10 rounded-xl py-3 pl-4 pr-24 text-sm text-white placeholder-[#666666] focus:outline-none focus:border-blue-500/60 focus:ring-1 focus:ring-blue-500/20 disabled:opacity-50 transition-all shadow-inner"
            />
            <div className="absolute right-2 flex items-center gap-1">
              <button
                type="button"
                onClick={() => startDictation()}
                className={`p-1.5 transition-all rounded-lg ${
                  isDictating 
                    ? 'text-red-400 bg-red-500/20 ring-2 ring-red-500/40 animate-pulse' 
                    : 'text-[#888888] hover:text-white hover:bg-white/5'
                }`}
                title={isDictating ? "Stop listening" : "Dictate with voice"}
              >
                <Mic className="w-4 h-4" />
              </button>
              <button 
                type="submit" 
                disabled={isCommanding || !commandText.trim()}
                className="bg-blue-600 hover:bg-blue-500 disabled:bg-[#2a2a2a] text-white rounded-lg px-3 py-1.5 text-xs font-medium transition-all disabled:opacity-40 flex items-center gap-1"
              >
                {isCommanding ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <>
                    <span>Send</span>
                    <CornerDownLeft className="w-3 h-3 opacity-70" />
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
        
        {/* Quick Launch Buttons */}
        <div className="flex flex-wrap justify-center gap-2 mt-4">
          {[
            { name: 'YouTube', url: 'https://youtube.com', icon: '📺' },
            { name: 'Spotify', url: 'https://open.spotify.com', icon: '🎵' },
            { name: 'Gmail', url: 'https://mail.google.com', icon: '📧' },
            { name: 'Google', url: 'https://google.com', icon: '🔍' },
            { name: 'X / Twitter', url: 'https://x.com', icon: '🐦' },
            { name: 'Facebook', url: 'https://facebook.com', icon: '📘' },
            { name: 'Netflix', url: 'https://netflix.com', icon: '🍿' },
            { name: 'ChatGPT', url: 'https://chatgpt.com', icon: '🤖' }
          ].map(app => (
            <button
              key={app.name}
              onClick={() => requestOpenUrl(app.url, app.name)}
              className="flex items-center gap-1.5 bg-[#141414] hover:bg-[#222222] text-[#aaaaaa] hover:text-white px-2.5 py-1.5 rounded-lg text-xs transition-colors border border-white/5"
            >
              <span>{app.icon}</span>
              {app.name}
            </button>
          ))}
        </div>

        {/* Enhanced Chat History */}
        {chatHistory.length > 0 && (
          <div className="mt-6 bg-[#111111]/90 backdrop-blur-xl border border-white/10 rounded-2xl p-4 shadow-[0_10px_30px_rgba(0,0,0,0.5)] flex flex-col gap-3 relative animate-in fade-in duration-300">
            {/* Chat Log Header */}
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/5 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-blue-500" />
                <h3 className="text-white text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
                  Chat Log <span className="text-[10px] text-[#777] font-normal font-mono">({chatHistory.length})</span>
                </h3>
              </div>

              <div className="flex items-center gap-1.5">
                {/* Search Bar */}
                <div className="relative flex items-center">
                  <Search className="w-3 h-3 text-[#666] absolute left-2 pointer-events-none" />
                  <input
                    type="text"
                    value={chatSearchQuery}
                    onChange={(e) => setChatSearchQuery(e.target.value)}
                    placeholder="Search..."
                    className="bg-[#181818] border border-white/10 rounded-lg pl-6 pr-2 py-1 text-[11px] text-white placeholder-[#555] focus:outline-none focus:border-blue-500/50 w-24 sm:w-32 transition-all"
                  />
                  {chatSearchQuery && (
                    <button 
                      onClick={() => setChatSearchQuery('')} 
                      className="absolute right-1 text-[#666] hover:text-white text-[10px] px-1"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* Export Button */}
                <button 
                  type="button"
                  onClick={() => {
                    const transcript = chatHistory.map(m => `[${new Date(m.timestamp).toLocaleTimeString()}] ${m.role === 'user' ? (userProfile?.fullName || 'User') : 'MUKE'}:\n${m.text}\n`).join('\n---\n\n');
                    const blob = new Blob([transcript], { type: 'text/plain;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `muke-chat-${new Date().toISOString().slice(0, 10)}.txt`;
                    a.click();
                    URL.revokeObjectURL(url);
                    setToastMessage("Transcript downloaded");
                    setTimeout(() => setToastMessage(null), 2500);
                  }}
                  title="Export chat transcript"
                  className="p-1.5 text-[#888] hover:text-white hover:bg-white/5 rounded-lg text-xs transition-colors border border-white/5"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>

                {/* Clear Button */}
                <button 
                  type="button"
                  onClick={() => {
                    setChatHistory([]);
                    setToastMessage("Chat history cleared");
                    setTimeout(() => setToastMessage(null), 2000);
                  }}
                  title="Clear chat history"
                  className="text-[11px] text-red-400 hover:text-red-300 transition-colors bg-red-500/10 hover:bg-red-500/20 px-2.5 py-1 rounded-lg border border-red-500/20 flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Clear</span>
                </button>
              </div>
            </div>

            {/* Message List */}
            <div className="max-h-72 overflow-y-auto custom-scrollbar flex flex-col gap-3 pr-1">
              {(chatSearchQuery.trim() 
                ? chatHistory.filter(m => m.text.toLowerCase().includes(chatSearchQuery.toLowerCase()))
                : chatHistory
              ).map(msg => (
                <div key={msg.id} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} group`}>
                  {/* Sender & Timestamp */}
                  <div className="flex items-center gap-1.5 mb-1 px-1 text-[10px] text-[#666]">
                    <span className="font-medium text-[#888]">
                      {msg.role === 'user' ? (userProfile?.fullName ? userProfile.fullName.split(' ')[0] : 'You') : 'MUKE'}
                    </span>
                    <span>•</span>
                    <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    {msg.isAgiAutonomous && (
                      <span className="ml-1 text-[9px] bg-purple-500/20 text-purple-300 border border-purple-500/40 px-1.5 py-0.2 rounded font-mono uppercase tracking-wider flex items-center gap-1 shadow-[0_0_10px_rgba(168,85,247,0.25)]">
                        <Brain className="w-2.5 h-2.5 text-purple-400 animate-pulse" /> Autonomous
                      </span>
                    )}
                  </div>

                  {/* Message Bubble */}
                  <div className={`max-w-[88%] rounded-xl px-3.5 py-2.5 text-xs relative ${
                    msg.role === 'user' 
                      ? 'bg-blue-600 text-white rounded-tr-none shadow-md shadow-blue-600/10' 
                      : msg.isDailyBriefing
                      ? 'bg-gradient-to-b from-[#24180d] to-[#141212] text-[#f7eee4] rounded-tl-none border border-amber-500/40 shadow-[0_4px_25px_rgba(245,158,11,0.2)]'
                      : msg.isVisionAnalysis
                      ? 'bg-gradient-to-b from-[#0d1e24] to-[#101416] text-[#e2f3f7] rounded-tl-none border border-teal-500/40 shadow-[0_4px_25px_rgba(20,184,166,0.2)]'
                      : msg.isAgiAutonomous
                      ? 'bg-gradient-to-b from-[#1c122b] to-[#121217] text-[#e8e4f4] rounded-tl-none border border-purple-500/40 shadow-[0_4px_25px_rgba(168,85,247,0.2)]'
                      : 'bg-[#1a1a1a] text-[#dedede] rounded-tl-none border border-white/10 shadow-md'
                  }`}>
                    {/* Autonomous Header */}
                    {msg.isAgiAutonomous && (
                      <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-purple-500/25 text-[10px] text-purple-300 font-semibold tracking-wide">
                        <span className="flex items-center gap-1">
                          <Brain className="w-3 h-3 text-purple-400" />
                          <span>Spontaneous Thought • {msg.agiPersona ? msg.agiPersona.toUpperCase() : 'COMPANION'}</span>
                        </span>
                        <span className="text-[9px] font-mono text-purple-400/80 bg-purple-500/10 px-1.5 py-0.2 rounded">Autonomous</span>
                      </div>
                    )}

                    {/* 🌅 Daily Briefing Header */}
                    {msg.isDailyBriefing && (
                      <div className="pb-2 mb-2 border-b border-amber-500/30 text-[11px] text-amber-300">
                        <div className="flex items-center justify-between font-bold mb-1.5">
                          <span className="flex items-center gap-1.5 text-amber-300">
                            <Sun className="w-4 h-4 text-amber-400 animate-spin-slow" />
                            <span>🌅 Daily Morning Briefing</span>
                          </span>
                          <span className="text-[9px] font-mono uppercase bg-amber-500/20 text-amber-200 px-2 py-0.5 rounded-full border border-amber-500/30">
                            Active Routine
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-1.5 text-[10px]">
                          {msg.briefingTime && (
                            <span className="bg-black/40 px-2 py-0.5 rounded border border-amber-500/20 text-amber-200/90 flex items-center gap-1">
                              <Clock className="w-2.5 h-2.5" /> {msg.briefingTime}
                            </span>
                          )}
                          {msg.briefingWeather && (
                            <span className="bg-black/40 px-2 py-0.5 rounded border border-amber-500/20 text-amber-200/90 flex items-center gap-1">
                              <Cloud className="w-2.5 h-2.5" /> {msg.briefingWeather}
                            </span>
                          )}
                          {typeof msg.briefingTasksCount === 'number' && (
                            <span className="bg-black/40 px-2 py-0.5 rounded border border-amber-500/20 text-amber-200/90 flex items-center gap-1">
                              <CheckSquare className="w-2.5 h-2.5" /> {msg.briefingTasksCount} Tasks Pending
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* 👁️ Vision Analysis Header */}
                    {msg.isVisionAnalysis && msg.role === 'ai' && (
                      <div className="flex items-center justify-between pb-1.5 mb-2 border-b border-teal-500/30 text-[11px] text-teal-300 font-semibold tracking-wide">
                        <span className="flex items-center gap-1.5 text-teal-300">
                          <Eye className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                          <span>👁️ Vision Intelligence Inspector</span>
                        </span>
                        <span className="text-[9px] font-mono uppercase bg-teal-500/20 text-cyan-200 px-2 py-0.5 rounded-full border border-teal-500/30">
                          {msg.visionSource === 'screen' ? '🖥️ Desktop Screen' : msg.visionSource === 'camera' ? '📸 Camera Snapshot' : '📁 Image'}
                        </span>
                      </div>
                    )}

                    {/* Image Snapshot Thumbnail Preview */}
                    {msg.visionSnapshot && (
                      <div 
                        onClick={() => setPreviewEnlargedImage(msg.visionSnapshot!)}
                        className="relative my-2 rounded-lg overflow-hidden border border-teal-500/40 group/img cursor-pointer max-w-sm shadow-md transition-all hover:border-cyan-400"
                        title="Click to view full image"
                      >
                        <img 
                          src={msg.visionSnapshot} 
                          alt="Vision snapshot" 
                          className="w-full max-h-44 object-cover object-top transition-transform duration-300 group-hover/img:scale-105" 
                        />
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center gap-1.5 text-[11px] text-white font-medium backdrop-blur-xs">
                          <Maximize2 className="w-3.5 h-3.5 text-cyan-300" />
                          <span>Enlarge Snapshot</span>
                        </div>
                      </div>
                    )}

                    {msg.role === 'user' ? (
                      <p className="whitespace-pre-wrap leading-relaxed select-text">{msg.text}</p>
                    ) : !msg.text ? (
                      <div className="flex items-center gap-2 py-1 text-purple-400">
                        <div className="flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                          <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                          <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                        </div>
                        <span className="text-[11px] text-[#888] font-medium animate-pulse">
                          {msg.isDailyBriefing ? "Preparing morning briefing..." : msg.isVisionAnalysis ? "Analyzing image with Gemini Vision..." : msg.isAgiAutonomous ? "Formulating spontaneous idea..." : "Responding fast..."}
                        </span>
                      </div>
                    ) : (
                      <div className="markdown-body leading-relaxed select-text text-left">
                        <Markdown>{msg.text}</Markdown>
                      </div>
                    )}

                    {/* 🌅 Daily Briefing Quick Action Buttons */}
                    {msg.isDailyBriefing && msg.text && (
                      <div className="mt-3 pt-2.5 border-t border-amber-500/25 flex flex-wrap gap-2">
                        <button
                          type="button"
                          onClick={() => requestOpenUrl('https://www.youtube.com/results?search_query=morning+lofi+chill+focus+music', 'YouTube Morning Lofi Music')}
                          className="flex items-center gap-1.5 bg-amber-500/15 hover:bg-amber-500/25 text-amber-200 border border-amber-500/30 px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all"
                        >
                          <span>🎵 Morning Lofi Music</span>
                          <ExternalLink className="w-2.5 h-2.5 opacity-70" />
                        </button>
                        <button
                          type="button"
                          onClick={() => requestOpenUrl('https://www.youtube.com/results?search_query=latest+news+today+live', 'YouTube Live News')}
                          className="flex items-center gap-1.5 bg-orange-500/15 hover:bg-orange-500/25 text-orange-200 border border-orange-500/30 px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all"
                        >
                          <span>📰 Stream Latest News</span>
                          <ExternalLink className="w-2.5 h-2.5 opacity-70" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowTasks(true)}
                          className="flex items-center gap-1.5 bg-blue-500/15 hover:bg-blue-500/25 text-blue-200 border border-blue-500/30 px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all"
                        >
                          <CheckSquare className="w-2.5 h-2.5" />
                          <span>View Tasks ({tasks.filter(t => !t.completed).length})</span>
                        </button>
                      </div>
                    )}

                    {/* Action Bar for Message */}
                    {msg.text && (
                      <div className="flex items-center gap-1 mt-2 pt-1.5 border-t border-white/10 justify-end opacity-70 group-hover:opacity-100 transition-opacity">
                        {/* Copy Action */}
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(msg.text);
                            setCopiedMsgId(msg.id);
                            setToastMessage("Copied to clipboard");
                            setTimeout(() => {
                              setCopiedMsgId(null);
                              setToastMessage(null);
                            }, 1500);
                          }}
                          className="p-1 text-[#aaa] hover:text-white rounded hover:bg-white/10 transition-colors flex items-center gap-1 text-[10px]"
                          title="Copy text"
                        >
                          {copiedMsgId === msg.id ? (
                            <>
                              <Check className="w-3 h-3 text-green-400" />
                              <span className="text-green-400">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>

                        {/* TTS Speak Action for AI messages */}
                        {msg.role === 'ai' && (
                          <button
                            type="button"
                            onClick={() => speakWithSciReyVoice(msg.text, msg.id)}
                            className={`p-1 rounded transition-colors flex items-center gap-1 text-[10px] ${
                              playingMsgId === msg.id && isSpeaking
                                ? 'text-blue-400 bg-blue-500/20'
                                : 'text-[#aaa] hover:text-white hover:bg-white/10'
                            }`}
                            title={playingMsgId === msg.id && isSpeaking ? "Stop speaking" : "Speak aloud"}
                          >
                            {playingMsgId === msg.id && isSpeaking ? (
                              <>
                                <VolumeX className="w-3 h-3 text-blue-400 animate-pulse" />
                                <span className="text-blue-400">Stop</span>
                              </>
                            ) : (
                              <>
                                <Volume2 className="w-3 h-3" />
                                <span>Listen</span>
                              </>
                            )}
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
          </div>
        )}

        <p className="text-[#555555] text-[11px] text-center mt-5">
          MUKE powered by ASSAD • Press Mic or type to interact
        </p>
      </div>

      {toastMessage && (
        <div className="fixed bottom-8 bg-[#222222] text-white px-4 py-2 rounded-full text-sm shadow-lg animate-bounce z-[100]">
          {toastMessage}
        </div>
      )}

      {/* Confirmation Modal */}
      {confirmOpenUrl && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[110] p-4">
          <div className="bg-[#1a1a1a] border border-[#333333] rounded-2xl p-6 w-full max-w-sm shadow-2xl text-center">
            <h3 className="text-xl font-bold text-white mb-2">Open Website?</h3>
            <p className="text-[#aaaaaa] text-sm mb-6">
              Are you sure you want to open <span className="text-white font-medium">{confirmOpenUrl.name}</span>?
            </p>
            <div className="flex gap-3 justify-center">
              <button 
                onClick={() => setConfirmOpenUrl(null)} 
                className="px-4 py-2 rounded-lg bg-[#333333] hover:bg-[#444444] text-white transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => {
                  window.open(confirmOpenUrl.url, '_blank', 'noopener,noreferrer');
                  setToastMessage(`Opening ${confirmOpenUrl.name}...`);
                  setTimeout(() => setToastMessage(null), 3000);
                  setConfirmOpenUrl(null);
                }} 
                className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors"
              >
                Open
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
