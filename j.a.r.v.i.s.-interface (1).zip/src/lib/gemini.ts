import { GoogleGenAI, Type, Modality, ThinkingLevel } from '@google/genai';

// Initialize the Gemini client
export const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export type ChatMode = 'fast' | 'pro' | 'think' | 'search' | 'maps' | 'image';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  imageUrl?: string;
  isThinking?: boolean;
}

export async function generateChatResponse(
  messages: ChatMessage[],
  mode: ChatMode,
  onStream?: (text: string) => void
): Promise<{ text: string; imageUrl?: string }> {
  const history = messages.map(m => ({
    role: m.role === 'user' ? 'user' : 'model',
    parts: [{ text: m.text }]
  }));
  
  const lastMessage = history.pop()?.parts[0].text || '';

  if (mode === 'image') {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-image-preview',
      contents: {
        parts: [{ text: lastMessage }],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: "1K"
        }
      }
    });
    
    let imageUrl: string | undefined;
    let textResponse = "Image generated.";
    
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        imageUrl = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      } else if (part.text) {
        textResponse = part.text;
      }
    }
    
    return { text: textResponse, imageUrl };
  }

  let modelName = 'gemini-2.5-flash';
  let config: any = {
    systemInstruction: "You are J.A.R.V.I.S., a highly advanced AI assistant. If the user asks you to open a website, app, or link, you MUST include the exact URL or custom URI scheme at the very end of your response in this exact format: [OPEN_URL: https://example.com] or [OPEN_URL: spotify://] or [OPEN_URL: calculator://]. Use common URI schemes for desktop apps (e.g., vscode://, ms-settings:, mailto:). Always be helpful and write whatever the user asks you to write."
  };

  switch (mode) {
    case 'fast':
      modelName = 'gemini-2.5-flash';
      break;
    case 'think':
      modelName = 'gemini-2.5-pro';
      config.thinkingConfig = { thinkingLevel: ThinkingLevel.HIGH };
      break;
    case 'search':
      modelName = 'gemini-2.5-flash';
      config.tools = [{ googleSearch: {} }];
      config.systemInstruction = "You are J.A.R.V.I.S. Provide fast, accurate, and direct answers using Google Search. If the user asks you to open a website, app, or link, you MUST include the exact URL or custom URI scheme at the very end of your response in this exact format: [OPEN_URL: https://example.com] or [OPEN_URL: spotify://]. Use common URI schemes for desktop apps.";
      break;
    case 'maps':
      modelName = 'gemini-2.5-flash';
      config.tools = [{ googleMaps: {} }];
      // Try to get user location
      try {
        const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject);
        });
        config.toolConfig = {
          retrievalConfig: {
            latLng: {
              latitude: pos.coords.latitude,
              longitude: pos.coords.longitude
            }
          }
        };
      } catch (e) {
        console.warn("Could not get geolocation for maps grounding", e);
      }
      break;
    case 'pro':
    default:
      modelName = 'gemini-2.5-flash';
      break;
  }

  const chat = ai.chats.create({
    model: modelName,
    config,
    history: history as any
  });

  if (onStream) {
    const stream = await chat.sendMessageStream({ message: lastMessage });
    let fullText = '';
    let groundingChunks: any[] = [];
    
    for await (const chunk of stream) {
      const c = chunk as any;
      if (c.text) {
        fullText += c.text;
        onStream(fullText);
      }
      if (c.candidates?.[0]?.groundingMetadata?.groundingChunks) {
        groundingChunks = c.candidates[0].groundingMetadata.groundingChunks;
      }
    }
    
    if (groundingChunks && groundingChunks.length > 0) {
      fullText += '\n\n**Sources:**\n';
      groundingChunks.forEach((chunk: any) => {
        if (chunk.web?.uri) {
          fullText += `- [${chunk.web.title || chunk.web.uri}](${chunk.web.uri})\n`;
        } else if (chunk.maps?.uri) {
          fullText += `- [${chunk.maps.title || 'Google Maps'}](${chunk.maps.uri})\n`;
        }
      });
      onStream(fullText);
    }
    
    return { text: fullText };
  } else {
    const response = await chat.sendMessage({ message: lastMessage });
    
    let text = response.text || '';
    
    // Append grounding chunks if available
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks && chunks.length > 0) {
      text += '\n\n**Sources:**\n';
      chunks.forEach((chunk: any) => {
        if (chunk.web?.uri) {
          text += `- [${chunk.web.title || chunk.web.uri}](${chunk.web.uri})\n`;
        } else if (chunk.maps?.uri) {
          text += `- [${chunk.maps.title || 'Google Maps'}](${chunk.maps.uri})\n`;
        }
      });
    }
    
    return { text };
  }
}

function pcmToWav(pcmBase64: string, sampleRate: number = 24000): string {
  const binaryString = atob(pcmBase64);
  const len = binaryString.length;
  const pcmData = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    pcmData[i] = binaryString.charCodeAt(i);
  }

  const wavHeader = new ArrayBuffer(44);
  const view = new DataView(wavHeader);

  const writeString = (view: DataView, offset: number, string: string) => {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  };

  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + pcmData.length, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(view, 36, 'data');
  view.setUint32(40, pcmData.length, true);

  const wavBytes = new Uint8Array(44 + pcmData.length);
  wavBytes.set(new Uint8Array(wavHeader), 0);
  wavBytes.set(pcmData, 44);

  let binary = '';
  for (let i = 0; i < wavBytes.byteLength; i++) {
    binary += String.fromCharCode(wavBytes[i]);
  }
  return `data:audio/wav;base64,${btoa(binary)}`;
}

export async function generateSpeech(text: string): Promise<string | null> {
  const elevenLabsKey = (typeof process !== 'undefined' && process.env?.ELEVENLABS_API_KEY) || 
                        (import.meta as any).env?.VITE_ELEVENLABS_API_KEY || '';
  
  if (elevenLabsKey && elevenLabsKey.trim().length > 5) {
    try {
      const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/ibbx9zDYGvLgtYzRbqqG/stream`, {
        method: 'POST',
        headers: {
          'xi-api-key': elevenLabsKey.trim(),
          'Content-Type': 'application/json',
          'Accept': 'audio/mpeg'
        },
        body: JSON.stringify({
          text,
          model_id: 'eleven_flash_v2_5',
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75
          }
        }),
      }).catch(() => null);
      
      if (response && response.ok) {
        const blob = await response.blob().catch(() => null);
        if (blob) return URL.createObjectURL(blob);
      }
    } catch {
      // Gracefully fall through to native / Gemini TTS
    }
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Zephyr' },
          },
        },
      },
    }).catch(() => null);

    const base64Audio = response?.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      return pcmToWav(base64Audio, 24000);
    }
  } catch (e) {
    console.debug("TTS generation skipped", e);
  }
  return null;
}
